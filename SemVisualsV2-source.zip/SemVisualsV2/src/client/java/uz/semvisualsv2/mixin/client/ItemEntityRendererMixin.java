package uz.semvisualsv2.mixin.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.ItemEntityRenderer;
import net.minecraft.client.renderer.entity.state.ItemClusterRenderState;
import net.minecraft.client.renderer.entity.state.ItemEntityRenderState;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.phys.AABB;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import uz.semvisualsv2.module.Mixed;

@Mixin(ItemEntityRenderer.class)
public abstract class ItemEntityRendererMixin {
    @Inject(method = "submitMultipleFromCount(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;ILnet/minecraft/client/renderer/entity/state/ItemClusterRenderState;Lnet/minecraft/util/RandomSource;Lnet/minecraft/world/phys/AABB;)V", at = @At("HEAD"))
    private static void sem$flatPre(PoseStack poseStack, SubmitNodeCollector collector, int light,
                                    ItemClusterRenderState state, RandomSource random, AABB box, CallbackInfo ci) {
        Mixed.ItemPhysics.pre(poseStack);
    }

    @Inject(method = "submitMultipleFromCount(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;ILnet/minecraft/client/renderer/entity/state/ItemClusterRenderState;Lnet/minecraft/util/RandomSource;Lnet/minecraft/world/phys/AABB;)V", at = @At("RETURN"))
    private static void sem$flatPost(PoseStack poseStack, SubmitNodeCollector collector, int light,
                                     ItemClusterRenderState state, RandomSource random, AABB box, CallbackInfo ci) {
        Mixed.ItemPhysics.post(poseStack);
    }

    @Inject(method = "extractRenderState(Lnet/minecraft/world/entity/item/ItemEntity;"
            + "Lnet/minecraft/client/renderer/entity/state/ItemEntityRenderState;F)V", at = @At("RETURN"))
    private void sem$freezeBob(ItemEntity entity, ItemEntityRenderState state, float partialTick, CallbackInfo ci) {
        Mixed.ItemPhysics.freeze(state);
    }
}
