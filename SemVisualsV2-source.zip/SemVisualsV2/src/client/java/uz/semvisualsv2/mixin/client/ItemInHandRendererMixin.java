package uz.semvisualsv2.mixin.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import uz.semvisualsv2.module.Mixed;

@Mixin(ItemInHandRenderer.class)
public abstract class ItemInHandRendererMixin {
    @Inject(method = "renderArmWithItem", at = @At("HEAD"))
    private void sem$handPre(AbstractClientPlayer player, float partialTick, float pitch, InteractionHand hand,
                             float swingProgress, ItemStack stack, float equipProgress, PoseStack poseStack,
                             SubmitNodeCollector collector, int light, CallbackInfo ci) {
        Mixed.CustomHand.pre(poseStack, hand);
    }

    @Inject(method = "renderArmWithItem", at = @At("RETURN"))
    private void sem$handPost(AbstractClientPlayer player, float partialTick, float pitch, InteractionHand hand,
                              float swingProgress, ItemStack stack, float equipProgress, PoseStack poseStack,
                              SubmitNodeCollector collector, int light, CallbackInfo ci) {
        Mixed.CustomHand.post(poseStack);
    }
}
