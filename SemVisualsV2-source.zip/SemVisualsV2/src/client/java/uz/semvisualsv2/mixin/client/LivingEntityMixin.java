package uz.semvisualsv2.mixin.client;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.minecraft.world.entity.Entity;
import uz.semvisualsv2.module.Cosmetics;
import uz.semvisualsv2.module.Mixed;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    @Inject(method = "isPickable", at = @At("HEAD"), cancellable = true)
    private void sem$petNotPickable(CallbackInfoReturnable<Boolean> cir) {
        if (Cosmetics.isCosmetic((Entity) (Object) this)) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "getCurrentSwingDuration", at = @At("RETURN"), cancellable = true)
    private void sem$swingDuration(CallbackInfoReturnable<Integer> cir) {
        if ((Object) this == Minecraft.getInstance().player) {
            cir.setReturnValue(Mixed.Animations.scale(cir.getReturnValue()));
        }
    }
}
