package uz.semvisualsv2.mixin.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.object.equipment.ElytraModel;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.layers.EquipmentLayerRenderer;
import net.minecraft.client.renderer.entity.layers.WingsLayer;
import net.minecraft.client.renderer.entity.state.HumanoidRenderState;
import net.minecraft.client.resources.model.EquipmentClientInfo;
import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.equipment.Equippable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import uz.semvisualsv2.module.Cosmetics;

/** Draws the Wings cosmetic with the vanilla elytra model, even when you wear no elytra. */
@Mixin(WingsLayer.class)
public abstract class WingsLayerMixin<S extends HumanoidRenderState, M extends EntityModel<S>> {
    @Shadow
    @Final
    private ElytraModel elytraModel;

    @Shadow
    @Final
    private ElytraModel elytraBabyModel;

    @Shadow
    @Final
    private EquipmentLayerRenderer equipmentRenderer;

    @Shadow
    private static Identifier getPlayerElytraTexture(HumanoidRenderState state) {
        throw new AssertionError();
    }

    @Inject(method = "submit(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;"
            + "ILnet/minecraft/client/renderer/entity/state/HumanoidRenderState;FF)V",
            at = @At("HEAD"), cancellable = true)
    private void sem$cosmeticWings(PoseStack poseStack, SubmitNodeCollector collector, int light,
                                   HumanoidRenderState state, float yRot, float xRot, CallbackInfo ci) {
        if (!Cosmetics.wingsFor(state) || state.chestEquipment.is(Items.ELYTRA)) {
            return;
        }
        ItemStack elytra = new ItemStack(Items.ELYTRA);
        Equippable equippable = elytra.get(DataComponents.EQUIPPABLE);
        if (equippable == null || equippable.assetId().isEmpty()) {
            return;
        }
        ElytraModel model = state.isBaby ? this.elytraBabyModel : this.elytraModel;
        poseStack.pushPose();
        poseStack.translate(0.0f, 0.0f, 0.125f);
        this.equipmentRenderer.renderLayers(EquipmentClientInfo.LayerType.WINGS, equippable.assetId().get(), model,
                state, elytra, poseStack, collector, light, getPlayerElytraTexture(state), state.outlineColor, 0);
        poseStack.popPose();
        ci.cancel();
    }
}
