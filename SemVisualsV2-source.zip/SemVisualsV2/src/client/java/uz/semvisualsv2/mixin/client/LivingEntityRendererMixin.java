package uz.semvisualsv2.mixin.client;

import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import uz.semvisualsv2.module.Cosmetics;

/** Lets your own pets (and the Studio preview animal) use a texture you painted. */
@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {
    @Inject(method = "getRenderType", at = @At("RETURN"), cancellable = true)
    private void sem$petTexture(LivingEntityRenderState state, boolean visible, boolean translucent, boolean glowing,
                                CallbackInfoReturnable<RenderType> cir) {
        Identifier custom = Cosmetics.petTexture(state);
        if (custom != null && cir.getReturnValue() != null) {
            cir.setReturnValue(translucent ? RenderTypes.entityTranslucent(custom) : RenderTypes.entityCutoutNoCull(custom));
        }
    }
}
