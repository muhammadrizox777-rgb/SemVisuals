package uz.semvisualsv2.mixin.client;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import uz.semvisualsv2.module.Cosmetics;
import uz.semvisualsv2.module.Mixed;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "isPickable", at = @At("HEAD"), cancellable = true)
    private void sem$petNotPickable(CallbackInfoReturnable<Boolean> cir) {
        if (Cosmetics.isCosmetic((Entity) (Object) this)) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "turn", at = @At("HEAD"), cancellable = true)
    private void sem$freeLookTurn(double yRot, double xRot, CallbackInfo ci) {
        if ((Object) this == Minecraft.getInstance().player && Mixed.FreeLook.turn(yRot, xRot)) {
            ci.cancel();
        }
    }
}
