package uz.semvisualsv2.mixin.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.entity.player.PlayerSkin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import uz.semvisualsv2.module.Cosmetics;

@Mixin(AbstractClientPlayer.class)
public abstract class AbstractClientPlayerMixin {
    @Inject(method = "getSkin", at = @At("RETURN"), cancellable = true)
    private void sem$cosmeticSkin(CallbackInfoReturnable<PlayerSkin> cir) {
        if ((Object) this == Minecraft.getInstance().player) {
            cir.setReturnValue(Cosmetics.patch(cir.getReturnValue()));
        }
    }
}
