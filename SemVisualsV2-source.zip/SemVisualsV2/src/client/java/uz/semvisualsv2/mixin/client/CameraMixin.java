package uz.semvisualsv2.mixin.client;

import net.minecraft.client.Camera;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import uz.semvisualsv2.module.Mixed;

@Mixin(Camera.class)
public abstract class CameraMixin {
    @Inject(method = "setup", at = @At("HEAD"))
    private void sem$cameraPre(Level level, Entity entity, boolean detached, boolean mirror, float partialTick, CallbackInfo ci) {
        Mixed.FreeLook.cameraPre(entity);
    }

    @Inject(method = "setup", at = @At("RETURN"))
    private void sem$cameraPost(Level level, Entity entity, boolean detached, boolean mirror, float partialTick, CallbackInfo ci) {
        Mixed.FreeLook.cameraPost(entity);
    }
}
