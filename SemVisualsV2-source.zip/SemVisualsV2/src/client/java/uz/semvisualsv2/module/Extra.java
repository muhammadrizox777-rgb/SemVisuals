package uz.semvisualsv2.module;

import net.minecraft.client.CloudStatus;
import net.minecraft.client.DeltaTracker;
import net.minecraft.server.level.ParticleStatus;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;
import uz.semvisualsv2.core.Category;
import uz.semvisualsv2.core.Events;
import uz.semvisualsv2.core.Lang;
import uz.semvisualsv2.core.Module;
import uz.semvisualsv2.core.ModuleManager;
import uz.semvisualsv2.core.Setting;
import uz.semvisualsv2.core.Theme;

import java.util.EnumMap;
import java.util.Map;

/** Second batch: display-only and settings-only modules. */
public final class Extra {
    private Extra() {
    }

    public static void registerAll() {
        ModuleManager.register(new HitRange());
        ModuleManager.register(new MaceHelper());
        ModuleManager.register(new Nimb());
        ModuleManager.register(new BodyGlow());
        ModuleManager.register(new Optimization());
        ModuleManager.register(new SoundController());
    }

    /** Draws the 3-block hit radius on the ground around you and (optionally) other players. */
    public static final class HitRange extends Module {
        private final Setting.Num radius = add(new Setting.Num("Radius", 3.0, 1.0, 6.0, 0.1));
        private final Setting.Bool own = add(new Setting.Bool("Own circle", true));
        private final Setting.Bool others = add(new Setting.Bool("Other players", false));
        private final Setting.Num points = add(new Setting.Num("Points", 56, 24, 120, 4));
        private final Setting.Color inRange = add(new Setting.Color("Target in range", 0xFF6FD98A));
        private final Setting.Color idle = add(new Setting.Color("No target", 0xFFFFFFFF));

        public HitRange() {
            super("HitRange", "Shows your hit radius on the ground", Category.VISUALS);
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            if (mc.player == null || mc.level == null) {
                return;
            }
            if (own.get()) {
                boolean target = false;
                for (Player p : mc.level.players()) {
                    if (p != mc.player && !p.isSpectator() && p.distanceTo(mc.player) <= radius.get()) {
                        target = true;
                    }
                }
                circle(g, mc.player.position(), target ? inRange.get() : idle.get());
            }
            if (others.get()) {
                for (Player p : mc.level.players()) {
                    if (p != mc.player && !p.isSpectator() && p.distanceTo(mc.player) < 24) {
                        circle(g, p.position(), p.distanceTo(mc.player) <= radius.get() ? inRange.get() : 0x88FFFFFF);
                    }
                }
            }
        }

        private void circle(GuiGraphics g, Vec3 center, int color) {
            int n = points.asInt();
            double r = radius.get();
            for (int i = 0; i < n; i++) {
                double a = i * Math.PI * 2 / n;
                double[] p = uz.semvisualsv2.core.Util.project(center.add(Math.cos(a) * r, 0.03, Math.sin(a) * r));
                if (p[2] > 0.05) {
                    int x = (int) p[0], y = (int) p[1];
                    g.fill(x, y, x + 2, y + 2, color | 0xFF000000);
                }
            }
        }
    }

    /** Informational: fall distance and the mace smash bonus you would deal now. */
    public static final class MaceHelper extends Module {
        private final Setting.Bool hotbar = add(new Setting.Bool("Hotbar highlight", true));
        private final Setting.Bool message = add(new Setting.Bool("Message on hit", true));

        public MaceHelper() {
            super("MaceHelper", "Shows mace fall distance and smash bonus", Category.UTILITIES, true, 6, 300);
        }

        private static double bonus(double fall) {
            if (fall <= 1.5) {
                return 0;
            }
            if (fall <= 3) {
                return 4 * fall;
            }
            if (fall <= 8) {
                return 12 + 2 * (fall - 3);
            }
            return 22 + (fall - 8);
        }

        private boolean holding() {
            return mc.player != null && mc.player.getMainHandItem().is(Items.MACE);
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            if (mc.player == null) {
                return;
            }
            if (hotbar.get()) {
                for (int i = 0; i < 9; i++) {
                    if (mc.player.getInventory().getItem(i).is(Items.MACE)) {
                        int x = mc.getWindow().getGuiScaledWidth() / 2 - 90 + i * 20;
                        int y = mc.getWindow().getGuiScaledHeight() - 3;
                        g.fill(x, y - 1, x + 20, y + 1, Theme.accent());
                    }
                }
            }
            if (!holding()) {
                size(90, 28);
                return;
            }
            double fall = mc.player.fallDistance;
            double bonus = bonus(fall);
            size(130, 28);
            Theme.panel(g, hudX, hudY, hudW, hudH);
            Theme.text(g, Lang.f("Fall %.1f blocks", fall), hudX + 7, hudY + 3, Theme.TEXT);
            Theme.text(g, Lang.f("Smash bonus +%.1f", bonus), hudX + 7, hudY + 14, bonus > 0 ? Theme.GOOD : Theme.MUTED);
        }

        @Override
        public void onAttack(LivingEntity target) {
            if (message.get() && holding() && mc.player.fallDistance > 1.5) {
                Events.toast("Mace", Lang.f("Hit from %.1f blocks (+%.1f)", mc.player.fallDistance, bonus(mc.player.fallDistance)), true);
            }
        }
    }

    public static final class Nimb extends Module {
        private final Setting.Num height = add(new Setting.Num("Height", 0.9, 0.0, 2.0, 0.05));
        private final Setting.Num radius = add(new Setting.Num("Radius", 0.6, 0.3, 1.2, 0.05));
        private int tick;

        public Nimb() {
            super("Nimb", "A glowing ring around your body (third person)", Category.VISUALS);
        }

        @Override
        public void onTick() {
            if (mc.player == null || mc.level == null || mc.options.getCameraType().isFirstPerson()) {
                return;
            }
            tick++;
            for (int k = 0; k < 4; k++) {
                double a = tick * 0.25 + k * Math.PI / 2;
                mc.level.addParticle(ParticleTypes.END_ROD, mc.player.getX() + Math.cos(a) * radius.get(),
                        mc.player.getY() + height.get(), mc.player.getZ() + Math.sin(a) * radius.get(), 0, 0, 0);
            }
        }
    }

    /**
     * The vanilla glow outline is synced from the server, so a client mod cannot switch it on.
     * This is a soft aura of glow particles around your own model instead (third person).
     */
    public static final class BodyGlow extends Module {
        private static final java.util.Random RANDOM = new java.util.Random();

        public BodyGlow() {
            super("BodyGlow", "Glowing particles around your own player model (third person)", Category.VISUALS);
        }

        @Override
        public void onTick() {
            if (mc.player == null || mc.level == null || mc.options.getCameraType().isFirstPerson()) {
                return;
            }
            for (int i = 0; i < 2; i++) {
                mc.level.addParticle(ParticleTypes.GLOW,
                        mc.player.getX() + (RANDOM.nextDouble() - 0.5) * 0.9,
                        mc.player.getY() + RANDOM.nextDouble() * mc.player.getBbHeight(),
                        mc.player.getZ() + (RANDOM.nextDouble() - 0.5) * 0.9, 0, 0.005, 0);
            }
        }
    }

    public static final class Optimization extends Module {
        private final Setting.Bool particles = add(new Setting.Bool("Minimal particles", true));
        private final Setting.Bool clouds = add(new Setting.Bool("Clouds off", true));
        private final Setting.Num entities = add(new Setting.Num("Entity distance %", 70, 50, 100, 5));
        private ParticleStatus oldParticles;
        private CloudStatus oldClouds;
        private Double oldEntities;

        public Optimization() {
            super("Optimization", "Lowers a few video settings for more FPS", Category.UTILITIES);
        }

        @Override
        public void onEnable() {
            oldParticles = mc.options.particles().get();
            oldClouds = mc.options.cloudStatus().get();
            oldEntities = mc.options.entityDistanceScaling().get();
        }

        @Override
        public void onTick() {
            if (particles.get()) {
                mc.options.particles().set(ParticleStatus.MINIMAL);
            }
            if (clouds.get()) {
                mc.options.cloudStatus().set(CloudStatus.OFF);
            }
            mc.options.entityDistanceScaling().set(Math.max(0.5, entities.get() / 100.0));
        }

        @Override
        public void onDisable() {
            if (oldParticles != null) {
                mc.options.particles().set(oldParticles);
                mc.options.cloudStatus().set(oldClouds);
                mc.options.entityDistanceScaling().set(oldEntities);
            }
        }
    }

    public static final class SoundController extends Module {
        private final Map<SoundSource, Setting.Num> sliders = new EnumMap<>(SoundSource.class);
        private final Map<SoundSource, Double> saved = new EnumMap<>(SoundSource.class);

        public SoundController() {
            super("SoundController", "Per-category volume overrides", Category.UTILITIES);
            for (SoundSource s : new SoundSource[]{SoundSource.MUSIC, SoundSource.RECORDS, SoundSource.WEATHER,
                    SoundSource.BLOCKS, SoundSource.HOSTILE, SoundSource.NEUTRAL, SoundSource.PLAYERS, SoundSource.AMBIENT}) {
                String label = s.name().charAt(0) + s.name().substring(1).toLowerCase();
                sliders.put(s, add(new Setting.Num(label + " %", 100, 0, 100, 5)));
            }
        }

        @Override
        public void onEnable() {
            for (SoundSource s : sliders.keySet()) {
                saved.put(s, mc.options.getSoundSourceOptionInstance(s).get());
            }
        }

        @Override
        public void onTick() {
            for (Map.Entry<SoundSource, Setting.Num> e : sliders.entrySet()) {
                mc.options.getSoundSourceOptionInstance(e.getKey()).set(e.getValue().get() / 100.0);
            }
        }

        @Override
        public void onDisable() {
            for (Map.Entry<SoundSource, Double> e : saved.entrySet()) {
                mc.options.getSoundSourceOptionInstance(e.getKey()).set(e.getValue());
            }
        }
    }
}
