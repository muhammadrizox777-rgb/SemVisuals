package uz.semvisualsv2.module;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Util;
import uz.semvisualsv2.core.Events;
import uz.semvisualsv2.core.ModuleManager;

import javax.imageio.ImageIO;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

/**
 * Your own images. Drop a PNG or JPG into config/semvisualsv2/capes or config/semvisualsv2/wings and it shows up in the
 * Cosmetics tab. A normal cape/elytra texture (2:1) is used as it is; any other picture is fitted onto the cape or wing.
 * Everything is read from your computer and never uploaded anywhere.
 */
public final class CustomTextures {
    /** Custom textures are stored on a canvas 4x bigger than the built-in 256x128 ones. */
    public static final int CANVAS_W = 1024, CANVAS_H = 512;

    private record Loaded(Identifier id, long modified) {
    }

    private static final Map<String, Loaded> CACHE = new HashMap<>();
    private static final Set<String> FAILED = new HashSet<>();

    private CustomTextures() {
    }

    public static Path dir(String kind) {
        return ModuleManager.dir().resolve(kind);
    }

    public static List<String> list(String kind) {
        List<String> names = new ArrayList<>();
        try {
            Files.createDirectories(dir(kind));
            try (Stream<Path> files = Files.list(dir(kind))) {
                files.map(p -> p.getFileName().toString()).filter(n -> {
                    String l = n.toLowerCase(Locale.ROOT);
                    return l.endsWith(".png") || l.endsWith(".jpg") || l.endsWith(".jpeg");
                }).sorted().forEach(names::add);
            }
        } catch (IOException ignored) {
        }
        return names;
    }

    public static void openFolder(String kind) {
        try {
            Files.createDirectories(dir(kind));
            Util.getPlatform().openPath(dir(kind));
        } catch (IOException ignored) {
        }
    }

    public static void refresh() {
        for (Loaded l : CACHE.values()) {
            Minecraft.getInstance().getTextureManager().release(l.id());
        }
        CACHE.clear();
        FAILED.clear();
    }

    /** The registered texture for a file, or null if it cannot be read. Must be called on the render thread. */
    public static Identifier texture(String kind, String file) {
        if (file == null || file.isBlank()) {
            return null;
        }
        String key = kind + "/" + file;
        File f = dir(kind).resolve(file).toFile();
        if (!f.isFile()) {
            return null;
        }
        long modified = f.lastModified();
        Loaded cached = CACHE.get(key);
        if (cached != null && cached.modified() == modified) {
            return cached.id();
        }
        if (FAILED.contains(key + modified)) {
            return null;
        }
        try {
            BufferedImage source = ImageIO.read(f);
            if (source == null) {
                throw new IOException("unsupported image");
            }
            BufferedImage canvas = kind.equals("capes") ? buildCape(source) : buildWings(source);
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            ImageIO.write(canvas, "png", bytes);
            NativeImage image = NativeImage.read(bytes.toByteArray());
            Minecraft mc = Minecraft.getInstance();
            if (cached != null) {
                mc.getTextureManager().release(cached.id());
            }
            Identifier id = Identifier.fromNamespaceAndPath(Cosmetics.NAMESPACE,
                    "custom/" + kind + "/" + Integer.toHexString((file + modified).hashCode()));
            mc.getTextureManager().register(id, new DynamicTexture(() -> "semvisualsv2 " + key, image));
            CACHE.put(key, new Loaded(id, modified));
            return id;
        } catch (Exception e) {
            FAILED.add(key + modified);
            Events.toast("Cosmetics", "Could not read this image", false);
            return null;
        }
    }

    // ------------------------------------------------------------------ image fitting

    private static BufferedImage canvas() {
        return new BufferedImage(CANVAS_W, CANVAS_H, BufferedImage.TYPE_INT_ARGB);
    }

    private static Graphics2D g2(BufferedImage img) {
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        return g;
    }

    private static boolean isStandardLayout(BufferedImage src) {
        return src.getWidth() >= 64 && src.getWidth() == src.getHeight() * 2;
    }

    /** Draws src scaled to cover the target rectangle (centered crop). */
    private static void cover(Graphics2D g, BufferedImage src, int x, int y, int w, int h) {
        double s = Math.max((double) w / src.getWidth(), (double) h / src.getHeight());
        int sw = (int) Math.ceil(src.getWidth() * s), sh = (int) Math.ceil(src.getHeight() * s);
        g.setClip(x, y, w, h);
        g.drawImage(src, x + (w - sw) / 2, y + (h - sh) / 2, sw, sh, null);
        g.setClip(null);
    }

    private static Color average(BufferedImage src) {
        long r = 0, gr = 0, b = 0;
        int n = 0;
        for (int y = 0; y < src.getHeight(); y += Math.max(1, src.getHeight() / 16)) {
            for (int x = 0; x < src.getWidth(); x += Math.max(1, src.getWidth() / 16)) {
                int p = src.getRGB(x, y);
                if (((p >> 24) & 0xFF) > 20) {
                    r += (p >> 16) & 0xFF;
                    gr += (p >> 8) & 0xFF;
                    b += p & 0xFF;
                    n++;
                }
            }
        }
        return n == 0 ? new Color(60, 60, 80) : new Color((int) (r / n), (int) (gr / n), (int) (b / n));
    }

    private static BufferedImage buildCape(BufferedImage src) {
        BufferedImage out = canvas();
        Graphics2D g = g2(out);
        if (isStandardLayout(src)) {
            g.drawImage(src, 0, 0, CANVAS_W, CANVAS_H, null);
            g.dispose();
            return out;
        }
        int k = 16; // one cape pixel on this canvas
        Color avg = average(src);
        Color edge = avg.darker();
        g.setColor(edge);
        g.fillRect(0, k, k, 16 * k);                 // side
        g.fillRect(11 * k, k, k, 16 * k);            // other side
        g.fillRect(k, 0, 10 * k, k);                 // top
        g.fillRect(11 * k, 0, 10 * k, k);            // bottom
        cover(g, src, k, k, 10 * k, 16 * k);         // outside of the cape: your picture
        g.setColor(avg.darker().darker());
        g.fillRect(12 * k, k, 10 * k, 16 * k);       // inside of the cape
        g.dispose();
        return out;
    }

    private static BufferedImage buildWings(BufferedImage src) {
        BufferedImage out = canvas();
        Graphics2D g = g2(out);
        if (isStandardLayout(src)) {
            g.drawImage(src, 0, 0, CANVAS_W, CANVAS_H, null);
            g.dispose();
            return out;
        }
        int k = 16;
        // one wing face is 10x20 wing pixels at (24, 2); the other face at (36, 2)
        BufferedImage face = new BufferedImage(10 * k, 20 * k, BufferedImage.TYPE_INT_ARGB);
        Graphics2D fg = g2(face);
        cover(fg, src, 0, 0, 10 * k, 20 * k);
        fg.dispose();
        g.drawImage(face, 24 * k, 2 * k, null);
        g.drawImage(face, 36 * k + 10 * k, 2 * k, -10 * k, 20 * k, null);
        g.dispose();
        return out;
    }
}
