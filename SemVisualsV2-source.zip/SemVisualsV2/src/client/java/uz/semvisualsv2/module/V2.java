package uz.semvisualsv2.module;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;
import uz.semvisualsv2.core.Category;
import uz.semvisualsv2.core.Lang;
import uz.semvisualsv2.core.Module;
import uz.semvisualsv2.core.ModuleManager;
import uz.semvisualsv2.core.Setting;
import uz.semvisualsv2.core.Theme;
import uz.semvisualsv2.core.Util;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Random;

/** New in V2: aim and combat read-outs (display only), plus a few HUD widgets. None of them act for you. */
public final class V2 {
    private V2() {
    }

    public static void registerAll() {
        ModuleManager.register(new OptimalAim());
        ModuleManager.register(new HitMarker());
        ModuleManager.register(new DamageNumbers());
        ModuleManager.register(new CpsCounter());
        ModuleManager.register(new KeyStrokes());
        ModuleManager.register(new Speedometer());
        ModuleManager.register(new ComboCounter());
        ModuleManager.register(new ReachDisplay());
        ModuleManager.register(new Compass());
        ModuleManager.register(new FpsGraph());
    }

    // ------------------------------------------------------------------ OptimalAim

    /**
     * Shows where to aim a projectile at the entity you are targeting, taking the target's movement and the
     * arrow or throwable's speed and drop into account. It only draws a marker; it never aims or shoots for you.
     */
    public static final class OptimalAim extends Module {
        private final Setting.Mode part = add(new Setting.Mode("Aim at", "Chest", "Head", "Chest", "Feet"));
        private final Setting.Color color = add(new Setting.Color("Color", 0xFF6FD98A));
        private final Setting.Bool showMelee = add(new Setting.Bool("Show without projectile", true));
        private final Setting.Bool label = add(new Setting.Bool("Show distance", true));

        public OptimalAim() {
            super("OptimalAim", "Marks the best point to aim a projectile at your target", Category.VISUALS);
        }

        /** {speed, gravity} of what you are holding, or null if it is not a projectile. */
        private static double[] projectile() {
            ItemStack held = mc.player.getMainHandItem();
            if (held.is(Items.ENDER_PEARL) || held.is(Items.SNOWBALL) || held.is(Items.EGG)) {
                return new double[]{1.5, 0.03};
            }
            if (held.is(Items.SPLASH_POTION) || held.is(Items.LINGERING_POTION)) {
                return new double[]{0.5, 0.05};
            }
            if (held.is(Items.BOW) && mc.player.isUsingItem()) {
                float f = mc.player.getTicksUsingItem() / 20f;
                f = Math.min(1f, (f * f + f * 2f) / 3f);
                return f < 0.1f ? null : new double[]{f * 3.0, 0.05};
            }
            if (held.is(Items.CROSSBOW)) {
                return new double[]{3.15, 0.05};
            }
            if (held.is(Items.TRIDENT) && mc.player.isUsingItem()) {
                return new double[]{2.5, 0.05};
            }
            return null;
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            LivingEntity target = Util.target();
            if (target == null || mc.player == null) {
                return;
            }
            double frac = switch (part.get()) {
                case "Head" -> 0.92;
                case "Feet" -> 0.1;
                default -> 0.62;
            };
            Vec3 base = target.position().add(0, target.getBbHeight() * frac, 0);
            double[] proj = projectile();
            Vec3 aim = base;
            if (proj == null) {
                if (!showMelee.get()) {
                    return;
                }
            } else {
                Vec3 eye = mc.player.getEyePosition();
                Vec3 vel = target.position().subtract(new Vec3(target.xo, target.yo, target.zo));
                double t = eye.distanceTo(base) / proj[0];
                for (int i = 0; i < 4; i++) {
                    t = eye.distanceTo(base.add(vel.scale(t))) / proj[0];
                }
                aim = base.add(vel.scale(t)).add(0, 0.5 * proj[1] * t * t, 0);
            }
            double[] p = Util.project(aim);
            if (p[2] <= 0.05) {
                return;
            }
            int x = (int) p[0], y = (int) p[1], c = color.get() | 0xFF000000;
            int r = proj == null ? 4 : 6;
            g.fill(x - r, y - 1, x - 2, y + 1, c);
            g.fill(x + 2, y - 1, x + r, y + 1, c);
            g.fill(x - 1, y - r, x + 1, y - 2, c);
            g.fill(x - 1, y + 2, x + 1, y + r, c);
            g.fill(x - 1, y - 1, x + 1, y + 1, 0xFFFFFFFF);
            if (label.get()) {
                String s = (int) mc.player.distanceTo(target) + "m";
                Theme.text(g, s, x - Theme.width(s) / 2, y + r + 3, Theme.TEXT);
            }
        }
    }

    // ------------------------------------------------------------------ HitMarker

    public static final class HitMarker extends Module {
        private final Setting.Color color = add(new Setting.Color("Color", 0xFFFFFFFF));
        private final Setting.Num size = add(new Setting.Num("Size", 7, 3, 14, 1));
        private long last;

        public HitMarker() {
            super("HitMarker", "An X on the crosshair when you hit something", Category.VISUALS);
        }

        @Override
        public void onAttack(LivingEntity target) {
            last = System.currentTimeMillis();
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            long age = System.currentTimeMillis() - last;
            if (age > 320) {
                return;
            }
            int a = (int) (255 * (1f - age / 320f));
            int c = Theme.withAlpha(color.get(), Math.max(20, a));
            int cx = mc.getWindow().getGuiScaledWidth() / 2, cy = mc.getWindow().getGuiScaledHeight() / 2;
            int s = size.asInt();
            for (int i = 3; i < s; i++) {
                g.fill(cx + i, cy + i, cx + i + 2, cy + i + 2, c);
                g.fill(cx - i - 1, cy + i, cx - i + 1, cy + i + 2, c);
                g.fill(cx + i, cy - i - 1, cx + i + 2, cy - i + 1, c);
                g.fill(cx - i - 1, cy - i - 1, cx - i + 1, cy - i + 1, c);
            }
        }
    }

    // ------------------------------------------------------------------ DamageNumbers

    public static final class DamageNumbers extends Module {
        private record Popup(Vec3 pos, String text, long time, int color) {
        }

        private static final Random RANDOM = new Random();
        private final Setting.Num seconds = add(new Setting.Num("Duration (s)", 1.2, 0.5, 3.0, 0.1));
        private final List<Popup> popups = new ArrayList<>();
        private LivingEntity tracked;
        private float trackedHealth;
        private long attackedAt;

        public DamageNumbers() {
            super("DamageNumbers", "Floating damage numbers over what you hit", Category.VISUALS);
        }

        @Override
        public void onAttack(LivingEntity target) {
            tracked = target;
            trackedHealth = target.getHealth();
            attackedAt = System.currentTimeMillis();
        }

        @Override
        public void onTick() {
            if (tracked == null) {
                return;
            }
            float now = tracked.getHealth();
            if (trackedHealth - now > 0.05f) {
                float dmg = trackedHealth - now;
                popups.add(new Popup(tracked.position().add((RANDOM.nextDouble() - 0.5) * 0.6,
                        tracked.getBbHeight() + 0.2, (RANDOM.nextDouble() - 0.5) * 0.6),
                        String.format("-%.1f", dmg), System.currentTimeMillis(), dmg >= 6 ? 0xFFFF5555 : 0xFFFFFFFF));
            }
            trackedHealth = now;
            if (System.currentTimeMillis() - attackedAt > 2500 || tracked.isRemoved()) {
                tracked = null;
            }
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            long now = System.currentTimeMillis();
            long life = (long) (seconds.get() * 1000);
            popups.removeIf(p -> now - p.time() > life);
            for (Popup p : popups) {
                float age = (now - p.time()) / (float) life;
                double[] s = Util.project(p.pos().add(0, age * 0.9, 0));
                if (s[2] <= 0.05) {
                    continue;
                }
                int alpha = (int) (255 * (1f - Math.max(0f, age - 0.5f) / 0.5f));
                Theme.text(g, p.text(), (int) s[0] - Theme.width(p.text()) / 2, (int) s[1], Theme.withAlpha(p.color(), Math.max(20, alpha)));
            }
        }
    }

    // ------------------------------------------------------------------ CpsCounter

    public static final class CpsCounter extends Module {
        private final Deque<Long> left = new ArrayDeque<>();
        private final Deque<Long> right = new ArrayDeque<>();
        private boolean wasLeft, wasRight;

        public CpsCounter() {
            super("CpsCounter", "Clicks per second", Category.HUD, true, 6, 400);
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            long now = System.currentTimeMillis();
            boolean l = mc.mouseHandler.isLeftPressed(), r = mc.mouseHandler.isRightPressed();
            if (l && !wasLeft) {
                left.add(now);
            }
            if (r && !wasRight) {
                right.add(now);
            }
            wasLeft = l;
            wasRight = r;
            while (!left.isEmpty() && now - left.peekFirst() > 1000) {
                left.pollFirst();
            }
            while (!right.isEmpty() && now - right.peekFirst() > 1000) {
                right.pollFirst();
            }
            String text = "CPS  " + left.size() + "  |  " + right.size();
            size(Theme.width(text) + 14, 16);
            Theme.panel(g, hudX, hudY, hudW, hudH);
            Theme.text(g, text, hudX + 7, hudY + 4, Theme.TEXT);
        }
    }

    // ------------------------------------------------------------------ KeyStrokes

    public static final class KeyStrokes extends Module {
        public KeyStrokes() {
            super("KeyStrokes", "Shows the movement keys and mouse buttons you press", Category.HUD, true, 300, 280);
        }

        private void key(GuiGraphics g, int x, int y, int w, String label, boolean down) {
            g.fill(x, y, x + w, y + 20, down ? Theme.withAlpha(Theme.accent(), 0xDD) : 0xAA0D1220);
            g.fill(x, y + 19, x + w, y + 20, down ? 0xFFFFFFFF : Theme.LINE);
            Theme.text(g, label, x + (w - Theme.width(label)) / 2, y + 6, down ? 0xFF0D1220 : Theme.TEXT);
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            size(66, 70);
            int x = hudX, y = hudY;
            key(g, x + 22, y, 20, "W", mc.options.keyUp.isDown());
            key(g, x, y + 22, 20, "A", mc.options.keyLeft.isDown());
            key(g, x + 22, y + 22, 20, "S", mc.options.keyDown.isDown());
            key(g, x + 44, y + 22, 20, "D", mc.options.keyRight.isDown());
            key(g, x, y + 44, 31, "LMB", mc.mouseHandler.isLeftPressed());
            key(g, x + 33, y + 44, 31, "RMB", mc.mouseHandler.isRightPressed());
        }
    }

    // ------------------------------------------------------------------ Speedometer

    public static final class Speedometer extends Module {
        private Vec3 last;
        private double speed;

        public Speedometer() {
            super("Speedometer", "Your speed in blocks per second", Category.HUD, true, 6, 430);
        }

        @Override
        public void onTick() {
            if (mc.player == null) {
                return;
            }
            Vec3 now = mc.player.position();
            if (last != null) {
                double d = Math.hypot(now.x - last.x, now.z - last.z) * 20.0;
                speed += (d - speed) * 0.35;
            }
            last = now;
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            String text = String.format("%.2f b/s", speed);
            size(Math.max(80, Theme.width(text) + 14), 26);
            Theme.panel(g, hudX, hudY, hudW, hudH);
            Theme.text(g, text, hudX + 7, hudY + 3, Theme.TEXT);
            int bar = (int) ((hudW - 12) * Math.min(1.0, speed / 12.0));
            g.fill(hudX + 6, hudY + 17, hudX + hudW - 6, hudY + 20, 0xFF20283A);
            g.fill(hudX + 6, hudY + 17, hudX + 6 + bar, hudY + 20, Theme.accent());
        }
    }

    // ------------------------------------------------------------------ ComboCounter

    public static final class ComboCounter extends Module {
        private final Setting.Num timeout = add(new Setting.Num("Reset after (s)", 2.5, 1, 6, 0.5));
        private int combo, best;
        private long last;

        public ComboCounter() {
            super("ComboCounter", "Counts your hits in a row", Category.HUD, true, 6, 460);
        }

        @Override
        public void onAttack(LivingEntity target) {
            combo++;
            best = Math.max(best, combo);
            last = System.currentTimeMillis();
        }

        @Override
        public void onTick() {
            if (mc.player != null && mc.player.hurtTime > 0) {
                combo = 0;
            }
            if (combo > 0 && System.currentTimeMillis() - last > timeout.get() * 1000) {
                combo = 0;
            }
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            String a = "Combo  " + combo, b = Lang.f("Best %d", best);
            size(Math.max(Theme.width(a), Theme.width(b)) + 14, 28);
            Theme.panel(g, hudX, hudY, hudW, hudH);
            Theme.text(g, a, hudX + 7, hudY + 3, combo > 0 ? Theme.GOOD : Theme.TEXT);
            Theme.text(g, b, hudX + 7, hudY + 15, Theme.MUTED);
        }
    }

    // ------------------------------------------------------------------ ReachDisplay

    public static final class ReachDisplay extends Module {
        private double reach = -1;
        private long last;

        public ReachDisplay() {
            super("ReachDisplay", "Distance of your last hit", Category.HUD, true, 6, 490);
        }

        @Override
        public void onAttack(LivingEntity target) {
            if (mc.player != null) {
                reach = Math.sqrt(target.getBoundingBox().distanceToSqr(mc.player.getEyePosition()));
                last = System.currentTimeMillis();
            }
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            boolean fresh = reach >= 0 && System.currentTimeMillis() - last < 4000;
            String text = fresh ? Lang.f("Reach: %.2f blocks", reach) : Lang.t("No hits yet");
            size(Theme.width(text) + 14, 16);
            Theme.panel(g, hudX, hudY, hudW, hudH);
            Theme.text(g, text, hudX + 7, hudY + 4, fresh ? Theme.TEXT : Theme.MUTED);
        }
    }

    // ------------------------------------------------------------------ Compass

    public static final class Compass extends Module {
        private static final String[] DIRS = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};

        public Compass() {
            super("Compass", "A heading strip with north, east, south and west", Category.HUD, true, 220, 4);
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            if (mc.player == null) {
                return;
            }
            int w = 200;
            size(w, 22);
            g.fill(hudX, hudY, hudX + w, hudY + 22, 0xAA0D1220);
            g.fill(hudX, hudY + 21, hudX + w, hudY + 22, Theme.accent());
            double heading = ((mc.player.getYRot() + 180) % 360 + 360) % 360;
            g.enableScissor(hudX, hudY, hudX + w, hudY + 22);
            for (int deg = (int) heading - 70; deg <= heading + 70; deg++) {
                if (deg % 15 != 0) {
                    continue;
                }
                int x = hudX + w / 2 + (int) ((deg - heading) * (w / 140.0));
                int norm = ((deg % 360) + 360) % 360;
                if (norm % 45 == 0) {
                    String s = Lang.t(DIRS[norm / 45]);
                    Theme.text(g, s, x - Theme.width(s) / 2, hudY + 3, norm % 90 == 0 ? Theme.TEXT : Theme.MUTED);
                } else {
                    g.fill(x, hudY + 9, x + 1, hudY + 14, Theme.MUTED);
                }
            }
            g.disableScissor();
            g.fill(hudX + w / 2, hudY + 14, hudX + w / 2 + 1, hudY + 21, Theme.GOOD);
            String h = Integer.toString((int) heading);
            Theme.text(g, h, hudX + w / 2 - Theme.width(h) / 2, hudY + 13, Theme.accent());
        }
    }

    // ------------------------------------------------------------------ FpsGraph

    public static final class FpsGraph extends Module {
        private final float[] frames = new float[60];
        private int index;
        private long lastNanos;

        public FpsGraph() {
            super("FpsGraph", "A small frame-time graph", Category.HUD, true, 6, 520);
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            long now = System.nanoTime();
            if (lastNanos != 0) {
                frames[index] = (now - lastNanos) / 1.0E6f;
                index = (index + 1) % frames.length;
            }
            lastNanos = now;
            float sum = 0, worst = 0;
            for (float f : frames) {
                sum += f;
                worst = Math.max(worst, f);
            }
            int avg = sum <= 0 ? 0 : (int) (1000f / (sum / frames.length));
            size(132, 50);
            Theme.panel(g, hudX, hudY, hudW, hudH);
            Theme.text(g, "FPS " + avg + "  |  " + (worst <= 0 ? 0 : (int) (1000f / worst)) + " min", hudX + 7, hudY + 3, Theme.TEXT);
            for (int i = 0; i < frames.length; i++) {
                float f = frames[(index + i) % frames.length];
                int h = (int) Math.min(26, f / 33f * 26);
                int c = f < 17f ? Theme.GOOD : (f < 33f ? 0xFFE6C84A : Theme.BAD);
                g.fill(hudX + 6 + i * 2, hudY + 44 - h, hudX + 8 + i * 2, hudY + 44, c);
            }
        }
    }
}
