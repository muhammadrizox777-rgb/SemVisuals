package uz.semvisualsv2.module;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import uz.semvisualsv2.core.Category;
import uz.semvisualsv2.core.Friends;
import uz.semvisualsv2.core.Lang;
import uz.semvisualsv2.core.Markers;
import uz.semvisualsv2.core.Module;
import uz.semvisualsv2.core.ModuleManager;
import uz.semvisualsv2.core.Setting;
import uz.semvisualsv2.core.Theme;
import uz.semvisualsv2.core.Util;

/** Third batch: world overlays, movable vanilla HUD parts, GPS and friend protection. */
public final class More {
    private More() {
    }

    public static void registerAll() {
        ModuleManager.register(new BlockOverlay());
        ModuleManager.register(new HitboxCustomizer());
        ModuleManager.register(new SelfNametag());
        ModuleManager.register(new Atmosphere());
        ModuleManager.register(new ScoreboardHud());
        ModuleManager.register(new BossbarHud());
        ModuleManager.register(new GpsCommand());
        ModuleManager.register(new PvpSafe());
    }

    public static final class BlockOverlay extends Module {
        private final Setting.Color color = add(new Setting.Color("Color", 0xFF9B7BFF));

        public BlockOverlay() {
            super("BlockOverlay", "Colored outline on the block you look at", Category.VISUALS);
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            if (mc.level != null && mc.hitResult instanceof BlockHitResult hit && hit.getType() == HitResult.Type.BLOCK) {
                Util.drawBox(g, new AABB(hit.getBlockPos()).inflate(0.002), color.get());
            }
        }
    }

    /** Draws hitboxes only for entities you can actually see (line of sight). */
    public static final class HitboxCustomizer extends Module {
        private final Setting.Bool playersOnly = add(new Setting.Bool("Players only", true));
        private final Setting.Num range = add(new Setting.Num("Range", 16, 4, 48, 1));
        private final Setting.Color playerColor = add(new Setting.Color("Player color", 0xFFFFFFFF));
        private final Setting.Color mobColor = add(new Setting.Color("Mob color", 0xFFE86A6A));

        public HitboxCustomizer() {
            super("HitboxCustomizer", "Colored hitboxes for visible entities", Category.VISUALS);
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            if (mc.player == null || mc.level == null) {
                return;
            }
            for (Entity e : mc.level.entitiesForRendering()) {
                if (e == mc.player || Cosmetics.isCosmetic(e) || !(e instanceof LivingEntity living) || e.distanceTo(mc.player) > range.get()) {
                    continue;
                }
                boolean player = e instanceof Player;
                if (playersOnly.get() && !player) {
                    continue;
                }
                if (!mc.player.hasLineOfSight(living)) {
                    continue;
                }
                Util.drawBox(g, e.getBoundingBox(), player ? playerColor.get() : mobColor.get());
            }
        }
    }

    public static final class SelfNametag extends Module {
        public SelfNametag() {
            super("SelfNametag", "Shows your own nametag in third person", Category.VISUALS);
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            if (mc.player == null || mc.options.getCameraType().isFirstPerson()) {
                return;
            }
            double[] p = Util.project(mc.player.position().add(0, mc.player.getBbHeight() + 0.45, 0));
            if (p[2] <= 0.05) {
                return;
            }
            String text = mc.player.getName().getString() + "  " + Math.round(mc.player.getHealth());
            int w = Theme.width(text);
            int x = (int) p[0] - w / 2, y = (int) p[1] - 10;
            g.fill(x - 3, y - 2, x + w + 3, y + 10, 0x99000000);
            g.fill(x - 3, y + 10, x + w + 3, y + 11, Theme.accent());
            Theme.text(g, text, x, y, Theme.TEXT);
        }
    }

    /** Screen tint and vignette. A true sky/fog change would need a mixin, so this is an overlay. */
    public static final class Atmosphere extends Module {
        private final Setting.Color tint = add(new Setting.Color("Tint", 0xFF203878));
        private final Setting.Num strength = add(new Setting.Num("Strength %", 12, 0, 60, 1));
        private final Setting.Bool vignette = add(new Setting.Bool("Vignette", true));

        public Atmosphere() {
            super("Atmosphere", "Screen tint and vignette", Category.VISUALS);
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            int w = mc.getWindow().getGuiScaledWidth(), h = mc.getWindow().getGuiScaledHeight();
            int a = (int) (strength.get() * 2.55);
            if (a > 0) {
                g.fill(0, 0, w, h, Theme.withAlpha(tint.get(), a));
            }
            if (vignette.get()) {
                for (int i = 0; i < 14; i++) {
                    int alpha = 90 - i * 6;
                    int c = Theme.withAlpha(0xFF000000, Math.max(0, alpha));
                    g.fill(0, i * 3, w, i * 3 + 3, c);
                    g.fill(0, h - i * 3 - 3, w, h - i * 3, c);
                    g.fill(i * 3, 0, i * 3 + 3, h, c);
                    g.fill(w - i * 3 - 3, 0, w - i * 3, h, c);
                }
            }
        }
    }

    /** Base for vanilla HUD parts that you can drag around in the HUD editor. */
    public abstract static class MoveHud extends Module {
        public int dx, dy;
        private final int boxW, boxH;

        protected MoveHud(String name, String description, int boxW, int boxH) {
            super(name, description, Category.HUD, true, -1, -1);
            this.boxW = boxW;
            this.boxH = boxH;
        }

        protected abstract int defaultX();

        protected abstract int defaultY();

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            if (hudX < 0 || hudY < 0) {
                hudX = defaultX();
                hudY = defaultY();
            }
            size(boxW, boxH);
            dx = hudX - defaultX();
            dy = hudY - defaultY();
        }
    }

    public static final class ScoreboardHud extends MoveHud {
        public ScoreboardHud() {
            super("ScoreboardHud", "Move the vanilla scoreboard", 100, 70);
        }

        @Override
        protected int defaultX() {
            return mc.getWindow().getGuiScaledWidth() - 100;
        }

        @Override
        protected int defaultY() {
            return mc.getWindow().getGuiScaledHeight() / 2 - 35;
        }
    }

    public static final class BossbarHud extends MoveHud {
        public BossbarHud() {
            super("BossbarHud", "Move the vanilla boss bars", 182, 30);
        }

        @Override
        protected int defaultX() {
            return mc.getWindow().getGuiScaledWidth() / 2 - 91;
        }

        @Override
        protected int defaultY() {
            return 12;
        }
    }

    /** Arrow and distance to the nearest saved marker in this dimension. */
    public static final class GpsCommand extends Module {
        public GpsCommand() {
            super("GpsCommand", "Direction and distance to your nearest marker", Category.UTILITIES, true, 6, 330);
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            if (mc.player == null) {
                return;
            }
            Markers.Marker best = null;
            double bestDist = Double.MAX_VALUE;
            String dim = Util.dimensionName();
            for (Markers.Marker m : Markers.LIST) {
                if (m.dimension().equals(dim)) {
                    double d = Math.hypot(m.x() - mc.player.getX(), m.z() - mc.player.getZ());
                    if (d < bestDist) {
                        bestDist = d;
                        best = m;
                    }
                }
            }
            size(130, 28);
            Theme.panel(g, hudX, hudY, hudW, hudH);
            if (best == null) {
                Theme.text(g, "No markers here", hudX + 7, hudY + 9, Theme.MUTED);
                return;
            }
            double target = Math.toDegrees(Math.atan2(-(best.x() - mc.player.getX()), best.z() - mc.player.getZ()));
            double rel = ((target - mc.player.getYRot()) % 360 + 540) % 360 - 180;
            String[] arrows = {"^", "/", ">", "\\", "v", "/", "<", "\\"};
            String[] names = {"ahead", "ahead right", "right", "back right", "behind", "back left", "left", "ahead left"};
            int idx = (int) Math.round(((rel + 360) % 360) / 45.0) % 8;
            Theme.text(g, best.name() + "  " + (int) bestDist + "m", hudX + 7, hudY + 3, Theme.TEXT);
            Theme.text(g, arrows[idx] + "  " + Lang.t(names[idx]), hudX + 7, hudY + 14, Theme.accent());
        }
    }

    /** Stops you from hitting players on your friends list by accident. */
    public static final class PvpSafe extends Module {
        public PvpSafe() {
            super("PvpSafe", "Blocks attacks on friends", Category.UTILITIES);
        }

        @Override
        public boolean blocksAttack(Entity target) {
            if (target instanceof Player p && Friends.isFriend(p.getName().getString())) {
                Events_warn();
                return true;
            }
            return false;
        }

        private void Events_warn() {
            uz.semvisualsv2.core.Events.log(Lang.t("PvpSafe blocked an attack on a friend"));
        }
    }
}
