package uz.semvisualsv2.module;

import net.minecraft.resources.Identifier;

/**
 * What the Studio screen is currently editing. While the Studio is open these textures replace the real ones on your
 * player (cape, wings, skin) and on the preview animal, so you see every pixel you paint on the model right away.
 */
public final class Studio {
    public static Identifier capeId, wingsId, skinId, petId;
    /** Entity id used by the preview animal in the Studio. */
    public static final int PET_PREVIEW_ID = Cosmetics.PET_ID_BASE - 60;

    private Studio() {
    }

    public static void clear() {
        capeId = wingsId = skinId = petId = null;
    }
}
