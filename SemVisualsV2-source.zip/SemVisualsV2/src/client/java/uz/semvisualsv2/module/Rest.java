package uz.semvisualsv2.module;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import uz.semvisualsv2.core.Category;
import uz.semvisualsv2.core.Events;
import uz.semvisualsv2.core.Module;
import uz.semvisualsv2.core.ModuleManager;
import uz.semvisualsv2.core.Setting;
import uz.semvisualsv2.core.Theme;
import uz.semvisualsv2.core.Util;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Fourth batch: trajectory preview, item change popups, healing item counter and two inventory helpers. */
public final class Rest {
    private Rest() {
    }

    public static void registerAll() {
        ModuleManager.register(new Predictions());
        ModuleManager.register(new ItemHighlighter());
        ModuleManager.register(new HealingHelper());
        ModuleManager.register(new ElytraSwap());
        ModuleManager.register(new ChestSorter());
    }

    /** Shows where a thrown item, arrow or trident you are holding would land. */
    public static final class Predictions extends Module {
        private final Setting.Color color = add(new Setting.Color("Color", 0xFF9B7BFF));
        private final Setting.Num steps = add(new Setting.Num("Max steps", 80, 20, 160, 5));

        public Predictions() {
            super("Predictions", "Trajectory preview for throwables and bows", Category.UTILITIES);
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            if (mc.player == null || mc.level == null) {
                return;
            }
            ItemStack held = mc.player.getMainHandItem();
            double speed;
            double gravity;
            if (held.is(Items.ENDER_PEARL) || held.is(Items.SNOWBALL) || held.is(Items.EGG)) {
                speed = 1.5;
                gravity = 0.03;
            } else if (held.is(Items.SPLASH_POTION) || held.is(Items.LINGERING_POTION)) {
                speed = 0.5;
                gravity = 0.05;
            } else if (held.is(Items.EXPERIENCE_BOTTLE)) {
                speed = 0.7;
                gravity = 0.07;
            } else if (held.is(Items.BOW) && mc.player.isUsingItem()) {
                float f = mc.player.getTicksUsingItem() / 20f;
                f = Math.min(1f, (f * f + f * 2f) / 3f);
                if (f < 0.1f) {
                    return;
                }
                speed = f * 3.0;
                gravity = 0.05;
            } else if (held.is(Items.TRIDENT) && mc.player.isUsingItem()) {
                speed = 2.5;
                gravity = 0.05;
            } else {
                return;
            }
            Vec3 pos = mc.player.getEyePosition().add(0, -0.1, 0);
            Vec3 vel = mc.player.getLookAngle().scale(speed);
            int max = steps.asInt();
            int c = color.get() | 0xFF000000;
            for (int i = 0; i < max; i++) {
                Vec3 next = pos.add(vel);
                var hit = mc.level.clip(new ClipContext(pos, next, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, mc.player));
                boolean end = hit.getType() != HitResult.Type.MISS;
                Vec3 point = end ? hit.getLocation() : next;
                double[] p = Util.project(point);
                if (p[2] > 0.05) {
                    int x = (int) p[0], y = (int) p[1];
                    if (end) {
                        g.fill(x - 3, y - 3, x + 4, y + 4, 0xAA000000);
                        g.fill(x - 2, y - 2, x + 3, y + 3, c);
                    } else if (i % 2 == 0) {
                        g.fill(x, y, x + 2, y + 2, c);
                    }
                }
                if (end) {
                    break;
                }
                pos = next;
                vel = vel.scale(0.99).add(0, -gravity, 0);
            }
        }
    }

    /** Floating +N / -N text above the hotbar when your item counts change. */
    public static final class ItemHighlighter extends Module {
        private record Popup(String text, boolean positive, long time) {
        }

        private final Setting.Num seconds = add(new Setting.Num("Duration (s)", 2.5, 1, 6, 0.5));
        private final List<Popup> popups = new ArrayList<>();
        private final Map<Item, Integer> last = new HashMap<>();
        private boolean primed;

        public ItemHighlighter() {
            super("ItemHighlighter", "Shows +N / -N when item counts change", Category.UTILITIES);
        }

        @Override
        public void onEnable() {
            primed = false;
        }

        @Override
        public void onTick() {
            if (mc.player == null || mc.player.tickCount % 4 != 0) {
                return;
            }
            Map<Item, Integer> now = new HashMap<>();
            var inv = mc.player.getInventory();
            for (int i = 0; i < inv.getContainerSize(); i++) {
                ItemStack s = inv.getItem(i);
                if (!s.isEmpty()) {
                    now.merge(s.getItem(), s.getCount(), Integer::sum);
                }
            }
            if (primed && mc.screen == null) {
                for (Item item : now.keySet()) {
                    add(item, now.get(item) - last.getOrDefault(item, 0));
                }
                for (Item item : last.keySet()) {
                    if (!now.containsKey(item)) {
                        add(item, -last.get(item));
                    }
                }
            }
            last.clear();
            last.putAll(now);
            primed = true;
        }

        private void add(Item item, int diff) {
            if (diff != 0) {
                popups.add(new Popup((diff > 0 ? "+" : "") + diff + " " + new ItemStack(item).getHoverName().getString(),
                        diff > 0, System.currentTimeMillis()));
            }
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            long now = System.currentTimeMillis();
            long life = (long) (seconds.get() * 1000);
            popups.removeIf(p -> now - p.time() > life);
            int cx = mc.getWindow().getGuiScaledWidth() / 2;
            int base = mc.getWindow().getGuiScaledHeight() - 62;
            for (int i = 0; i < popups.size() && i < 6; i++) {
                Popup p = popups.get(popups.size() - 1 - i);
                float age = (now - p.time()) / (float) life;
                int alpha = (int) (255 * (1f - Math.max(0f, age - 0.6f) / 0.4f));
                int color = Theme.withAlpha(p.positive() ? Theme.GOOD : Theme.BAD, Math.max(10, alpha));
                Theme.text(g, p.text(), cx - Theme.width(p.text()) / 2, base - i * 11 - (int) (age * 6), color);
            }
        }
    }

    /** Counts of golden apples and totems, as a small HUD box. */
    public static final class HealingHelper extends Module {
        public HealingHelper() {
            super("HealingHelper", "Counts golden apples, enchanted apples and totems", Category.UTILITIES, true, 6, 360);
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            if (mc.player == null) {
                return;
            }
            Item[] items = {Items.GOLDEN_APPLE, Items.ENCHANTED_GOLDEN_APPLE, Items.TOTEM_OF_UNDYING};
            int[] counts = new int[items.length];
            var inv = mc.player.getInventory();
            for (int i = 0; i < inv.getContainerSize(); i++) {
                ItemStack s = inv.getItem(i);
                for (int k = 0; k < items.length; k++) {
                    if (s.is(items[k])) {
                        counts[k] += s.getCount();
                    }
                }
            }
            size(items.length * 34 + 6, 24);
            Theme.panel(g, hudX, hudY, hudW, hudH);
            for (int k = 0; k < items.length; k++) {
                int x = hudX + 6 + k * 34;
                g.renderItem(new ItemStack(items[k]), x, hudY + 4);
                Theme.text(g, Integer.toString(counts[k]), x + 17, hudY + 12, counts[k] == 0 ? Theme.BAD : Theme.TEXT);
            }
        }
    }

    /** Press a key to swap between your chestplate and an elytra from the inventory. */
    public static final class ElytraSwap extends Module {
        private final Setting.Key swapKey = add(new Setting.Key("Swap key", -1));
        private boolean wasDown;

        public ElytraSwap() {
            super("ElytraSwap", "Swap chestplate and elytra with one key", Category.UTILITIES);
        }

        @Override
        public void onTick() {
            if (mc.player == null || mc.gameMode == null || mc.screen != null || swapKey.get() < 0) {
                wasDown = false;
                return;
            }
            boolean down = InputConstants.isKeyDown(mc.getWindow(), swapKey.get());
            if (down && !wasDown) {
                swap();
            }
            wasDown = down;
        }

        private void swap() {
            var menu = mc.player.inventoryMenu;
            boolean wearingElytra = menu.getSlot(6).getItem().is(Items.ELYTRA);
            int found = -1;
            for (int i = 9; i <= 44; i++) {
                ItemStack s = menu.getSlot(i).getItem();
                if (wearingElytra ? s.is(ItemTags.CHEST_ARMOR) : s.is(Items.ELYTRA)) {
                    found = i;
                    break;
                }
            }
            if (found < 0) {
                Events.toast("ElytraSwap", wearingElytra ? "No chestplate in inventory" : "No elytra in inventory", false);
                return;
            }
            int id = menu.containerId;
            mc.gameMode.handleInventoryMouseClick(id, found, 0, ClickType.PICKUP, mc.player);
            mc.gameMode.handleInventoryMouseClick(id, 6, 0, ClickType.PICKUP, mc.player);
            if (!menu.getCarried().isEmpty()) {
                mc.gameMode.handleInventoryMouseClick(id, found, 0, ClickType.PICKUP, mc.player);
            }
        }
    }

    /** Sorts and merges the stacks of an open chest or barrel with one key. */
    public static final class ChestSorter extends Module {
        private final Setting.Key sortKey = add(new Setting.Key("Sort key", 82)); // R
        private final Setting.Mode mode = add(new Setting.Mode("Mode", "Merge and sort", "Merge and sort", "Sort only", "Merge only"));
        private final Setting.Num clicksPerTick = add(new Setting.Num("Clicks per tick", 3, 1, 8, 1));
        private final List<Integer> queue = new ArrayList<>();
        private int queueContainer = -1;
        private boolean wasDown;

        public ChestSorter() {
            super("ChestSorter", "Sorts the chest you have open", Category.UTILITIES);
        }

        @Override
        public void onTick() {
            if (mc.player == null || mc.gameMode == null) {
                return;
            }
            if (!(mc.player.containerMenu instanceof ChestMenu menu)) {
                queue.clear();
                wasDown = false;
                return;
            }
            if (!queue.isEmpty() && queueContainer == menu.containerId) {
                for (int i = 0; i < clicksPerTick.asInt() && !queue.isEmpty(); i++) {
                    mc.gameMode.handleInventoryMouseClick(menu.containerId, queue.remove(0), 0, ClickType.PICKUP, mc.player);
                }
                return;
            }
            boolean down = mc.screen != null && sortKey.get() > 0 && InputConstants.isKeyDown(mc.getWindow(), sortKey.get());
            if (down && !wasDown && menu.getCarried().isEmpty()) {
                plan(menu);
            }
            wasDown = down;
        }

        private static boolean same(ItemStack a, ItemStack b) {
            if (a.isEmpty() || b.isEmpty()) {
                return a.isEmpty() && b.isEmpty();
            }
            return ItemStack.isSameItemSameComponents(a, b) && a.getCount() == b.getCount();
        }

        private void plan(ChestMenu menu) {
            int n = menu.getRowCount() * 9;
            List<ItemStack> sim = new ArrayList<>();
            for (int i = 0; i < n; i++) {
                sim.add(menu.getSlot(i).getItem().copy());
            }
            queue.clear();
            queueContainer = menu.containerId;

            if (!mode.is("Sort only")) {
                for (int i = 0; i < n; i++) {
                    for (int j = i + 1; j < n; j++) {
                        ItemStack a = sim.get(i), b = sim.get(j);
                        if (a.isEmpty() || b.isEmpty() || !ItemStack.isSameItemSameComponents(a, b)
                                || a.getCount() >= a.getMaxStackSize()) {
                            continue;
                        }
                        int move = Math.min(a.getMaxStackSize() - a.getCount(), b.getCount());
                        queue.add(j);
                        queue.add(i);
                        a.grow(move);
                        b.shrink(move);
                        if (!b.isEmpty()) {
                            queue.add(j);
                        }
                    }
                }
            }
            if (!mode.is("Merge only")) {
                List<ItemStack> target = new ArrayList<>();
                for (ItemStack s : sim) {
                    if (!s.isEmpty()) {
                        target.add(s.copy());
                    }
                }
                target.sort(Comparator
                        .comparing((ItemStack s) -> BuiltInRegistries.ITEM.getKey(s.getItem()).toString())
                        .thenComparing(Comparator.comparingInt(ItemStack::getCount).reversed()));
                while (target.size() < n) {
                    target.add(ItemStack.EMPTY);
                }
                for (int i = 0; i < n; i++) {
                    if (same(sim.get(i), target.get(i))) {
                        continue;
                    }
                    int j = -1;
                    for (int k = i + 1; k < n; k++) {
                        if (same(sim.get(k), target.get(i))) {
                            j = k;
                            break;
                        }
                    }
                    if (j < 0) {
                        continue;
                    }
                    if (!sim.get(i).isEmpty()) {
                        queue.add(i);
                        queue.add(j);
                        queue.add(i);
                    } else {
                        queue.add(j);
                        queue.add(i);
                    }
                    ItemStack tmp = sim.get(i);
                    sim.set(i, sim.get(j));
                    sim.set(j, tmp);
                }
            }
        }
    }
}
