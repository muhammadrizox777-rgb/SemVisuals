package uz.semvisualsv2.module;

import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.entity.state.HumanoidRenderState;
import net.minecraft.core.ClientAsset;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.parrot.Parrot;
import net.minecraft.world.entity.player.PlayerSkin;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import uz.semvisualsv2.core.Category;
import uz.semvisualsv2.core.Module;
import uz.semvisualsv2.core.ModuleManager;
import uz.semvisualsv2.core.Setting;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

/**
 * Cosmetics. They are drawn only on your own screen: nothing is sent to the server and other players do not see them.
 * Capes and wings change the textures of your own player model, pets are client-side entities that follow you,
 * and shoulder birds use the vanilla parrot-on-shoulder rendering.
 */
public final class Cosmetics {
    public static final String NAMESPACE = "semvisualsv2";
    public static final String[] CAPES = {"Aurora", "Ember", "Ocean", "Forest", "Midnight", "Royal", "Neon Grid", "Sakura",
            "Sunset", "Lava", "Galaxy", "Candy", "Ice", "Gold", "Matrix", "Hearts", "Rainbow", "Camo", "Checker", "Scales"};
    public static final String[] WINGS = {"Angel", "Dragon", "Butterfly", "Neon", "Crystal", "Fairy", "Raven", "Phoenix",
            "Silver", "Rose", "Storm", "Nature", "Void", "Frost", "Toxic", "Monarch", "Morpho", "Amethyst", "Emerald", "Solar"};
    public static final String[] PETS = {"Cat", "Wolf", "Fox", "Rabbit", "Chicken", "Pig", "Sheep", "Cow", "Horse", "Goat",
            "Llama", "Polar Bear", "Armadillo", "Axolotl", "Frog", "Panda", "Turtle", "Bee", "Allay", "Parrot"};
    private static final String[] CAPE_MODES = withCustom(CAPES);
    private static final String[] WING_MODES = withCustom(WINGS);
    public static final String[] BIRDS = {"Red-blue", "Blue", "Green", "Yellow-blue", "Gray"};

    /** Client-side pets get negative entity ids so they can never clash with real entities. */
    public static final int PET_ID_BASE = -80000;

    private Cosmetics() {
    }

    private static String[] withCustom(String[] names) {
        String[] all = java.util.Arrays.copyOf(names, names.length + 1);
        all[names.length] = "Custom";
        return all;
    }

    public static void registerAll() {
        ModuleManager.register(new Cape());
        ModuleManager.register(new Wings());
        ModuleManager.register(new Pet());
        ModuleManager.register(new ShoulderBird());
    }

    public static boolean isCosmetic(Entity entity) {
        return entity != null && entity.getId() <= PET_ID_BASE && entity.getId() > PET_ID_BASE - 100;
    }

    public static String slug(String name) {
        return name.toLowerCase(Locale.ROOT).replace(" ", "");
    }

    // ------------------------------------------------------------------ skin patch (cape + wings)

    public static PlayerSkin patch(PlayerSkin skin) {
        Cape cape = ModuleManager.get(Cape.class);
        Wings wings = ModuleManager.get(Wings.class);
        boolean capeOn = cape != null && cape.isEnabled();
        boolean wingsOn = wings != null && wings.isEnabled();
        if (!capeOn && !wingsOn) {
            return skin;
        }
        ClientAsset.Texture capeTexture = capeOn ? chosen("cape", "capes", cape.style, cape.customFile, skin.cape()) : skin.cape();
        ClientAsset.Texture elytraTexture = wingsOn ? chosen("wings", "wings", wings.style, wings.customFile, skin.elytra()) : skin.elytra();
        return new PlayerSkin(skin.body(), capeTexture, elytraTexture, skin.model(), skin.secure());
    }

    /** A built-in texture, or one of your own images when the style is "Custom". */
    private static ClientAsset.Texture chosen(String folder, String customKind, Setting.Mode style, Setting.Text file,
                                              ClientAsset.Texture fallback) {
        if (style.is("Custom")) {
            Identifier id = CustomTextures.texture(customKind, file.get());
            return id == null ? fallback : new ClientAsset.ResourceTexture(id, id);
        }
        return texture(folder, slug(style.get()));
    }

    private static ClientAsset.Texture texture(String folder, String name) {
        return new ClientAsset.ResourceTexture(
                Identifier.fromNamespaceAndPath(NAMESPACE, folder + "/" + name),
                Identifier.fromNamespaceAndPath(NAMESPACE, "textures/" + folder + "/" + name + ".png"));
    }

    /** True when this render state is your own player and the Wings cosmetic is on. */
    public static boolean wingsFor(HumanoidRenderState state) {
        Wings wings = ModuleManager.get(Wings.class);
        return wings != null && wings.isEnabled() && state instanceof AvatarRenderState avatar
                && Module.mc().player != null && avatar.id == Module.mc().player.getId();
    }

    // ------------------------------------------------------------------ modules

    public static final class Cape extends Module {
        public final Setting.Mode style = add(new Setting.Mode("Style", CAPES[0], CAPE_MODES));
        public final Setting.Text customFile = add(new Setting.Text("Custom file", ""));
        { customFile.visible = () -> false; }

        public Cape() {
            super("Cape", "Wear a cape on your own player model", Category.COSMETICS);
        }
    }

    public static final class Wings extends Module {
        public final Setting.Mode style = add(new Setting.Mode("Style", WINGS[0], WING_MODES));
        public final Setting.Text customFile = add(new Setting.Text("Custom file", ""));
        { customFile.visible = () -> false; }

        public Wings() {
            super("Wings", "Wings on your back (shown on top of armor, replaces nothing)", Category.COSMETICS);
        }
    }

    public static final class ShoulderBird extends Module {
        public final Setting.Mode style = add(new Setting.Mode("Style", BIRDS[0], BIRDS));
        public final Setting.Mode side = add(new Setting.Mode("Side", "Right shoulder", "Right shoulder", "Left shoulder", "Both shoulders"));

        public ShoulderBird() {
            super("ShoulderBird", "A parrot sitting on your shoulder", Category.COSMETICS);
        }

        private Parrot.Variant variant() {
            return switch (style.get()) {
                case "Blue" -> Parrot.Variant.BLUE;
                case "Green" -> Parrot.Variant.GREEN;
                case "Yellow-blue" -> Parrot.Variant.YELLOW_BLUE;
                case "Gray" -> Parrot.Variant.GRAY;
                default -> Parrot.Variant.RED_BLUE;
            };
        }

        @Override
        public void onTick() {
            if (mc.player == null) {
                return;
            }
            Optional<Parrot.Variant> bird = Optional.of(variant());
            mc.player.setShoulderParrotLeft(side.is("Right shoulder") ? Optional.empty() : bird);
            mc.player.setShoulderParrotRight(side.is("Left shoulder") ? Optional.empty() : bird);
        }

        @Override
        public void onDisable() {
            if (mc.player != null) {
                mc.player.setShoulderParrotLeft(Optional.empty());
                mc.player.setShoulderParrotRight(Optional.empty());
            }
        }
    }

    /** Client-side animals that follow you. They are never sent to the server and cannot be hit or clicked. */
    public static final class Pet extends Module {
        public final Setting.Mode type = add(new Setting.Mode("Animal", PETS[0], PETS));
        private final Setting.Num count = add(new Setting.Num("Count", 1, 1, 3, 1));
        private final Setting.Num distance = add(new Setting.Num("Distance", 1.6, 0.8, 4.0, 0.1));
        private final Setting.Bool baby = add(new Setting.Bool("Baby", false));
        private final List<Entity> pets = new ArrayList<>();
        private Level spawnedIn;
        private String spawnedType = "";
        private boolean spawnedBaby;
        private int spawnedCount;

        public Pet() {
            super("Pet", "An animal that follows you around", Category.COSMETICS);
        }

        private static EntityType<?> entityType(String name) {
            return switch (name) {
                case "Wolf" -> EntityType.WOLF;
                case "Fox" -> EntityType.FOX;
                case "Rabbit" -> EntityType.RABBIT;
                case "Chicken" -> EntityType.CHICKEN;
                case "Pig" -> EntityType.PIG;
                case "Sheep" -> EntityType.SHEEP;
                case "Cow" -> EntityType.COW;
                case "Horse" -> EntityType.HORSE;
                case "Goat" -> EntityType.GOAT;
                case "Llama" -> EntityType.LLAMA;
                case "Polar Bear" -> EntityType.POLAR_BEAR;
                case "Armadillo" -> EntityType.ARMADILLO;
                case "Axolotl" -> EntityType.AXOLOTL;
                case "Frog" -> EntityType.FROG;
                case "Panda" -> EntityType.PANDA;
                case "Turtle" -> EntityType.TURTLE;
                case "Bee" -> EntityType.BEE;
                case "Allay" -> EntityType.ALLAY;
                case "Parrot" -> EntityType.PARROT;
                default -> EntityType.CAT;
            };
        }

        private boolean flying() {
            return type.is("Bee") || type.is("Allay") || type.is("Parrot");
        }

        private void clear() {
            if (spawnedIn == mc.level && mc.level != null) {
                for (Entity e : pets) {
                    mc.level.removeEntity(e.getId(), Entity.RemovalReason.DISCARDED);
                }
            }
            pets.clear();
        }

        private void spawn() {
            spawnedIn = mc.level;
            spawnedType = type.get();
            spawnedBaby = baby.get();
            spawnedCount = count.asInt();
            for (int i = 0; i < count.asInt(); i++) {
                Entity pet = entityType(spawnedType).create(mc.level, EntitySpawnReason.COMMAND);
                if (pet == null) {
                    continue;
                }
                pet.setId(PET_ID_BASE - i);
                pet.setSilent(true);
                pet.setInvulnerable(true);
                pet.setNoGravity(true);
                pet.noPhysics = true;
                if (spawnedBaby && pet instanceof AgeableMob mob) {
                    mob.setBaby(true);
                }
                pet.setPos(mc.player.position());
                pet.setOldPosAndRot();
                mc.level.addEntity(pet);
                pets.add(pet);
            }
        }

        @Override
        public void onTick() {
            if (mc.level == null || mc.player == null) {
                return;
            }
            if (spawnedIn != mc.level || !type.get().equals(spawnedType) || baby.get() != spawnedBaby
                    || spawnedCount != count.asInt()) {
                clear();
                spawn();
            }
            double yaw = Math.toRadians(mc.player.getYRot());
            Vec3 forward = new Vec3(-Math.sin(yaw), 0, Math.cos(yaw));
            Vec3 right = new Vec3(-Math.cos(yaw), 0, -Math.sin(yaw));
            for (int i = 0; i < pets.size(); i++) {
                Entity pet = pets.get(i);
                double side = (i % 2 == 0 ? 1 : -1) * distance.get();
                double back = -0.3 - (i / 2) * 1.0;
                double hover = flying() ? 1.3 + Math.sin((mc.player.tickCount + i * 20) * 0.12) * 0.12 : 0;
                Vec3 target = mc.player.position().add(right.scale(side)).add(forward.scale(back)).add(0, hover, 0);
                Vec3 current = pet.position();
                Vec3 next = current.distanceToSqr(target) > 144 ? target : current.lerp(target, 0.2);
                Vec3 move = next.subtract(current);
                boolean moving = move.horizontalDistanceSqr() > 1.0E-4;
                float wanted = moving ? (float) Math.toDegrees(Math.atan2(-move.x, move.z)) : mc.player.getYRot();
                float yawNow = Mth.rotLerp(0.3f, pet.getYRot(), wanted);
                pet.setOldPosAndRot();
                pet.setPos(next);
                pet.setYRot(yawNow);
                pet.setXRot(0f);
                if (pet instanceof LivingEntity living) {
                    living.yBodyRotO = living.yBodyRot;
                    living.yHeadRotO = living.yHeadRot;
                    living.yBodyRot = yawNow;
                    living.yHeadRot = yawNow;
                }
            }
        }

        @Override
        public void onJoin() {
            pets.clear();
            spawnedIn = null;
        }

        @Override
        public void onDisable() {
            clear();
            spawnedIn = null;
        }
    }
}
