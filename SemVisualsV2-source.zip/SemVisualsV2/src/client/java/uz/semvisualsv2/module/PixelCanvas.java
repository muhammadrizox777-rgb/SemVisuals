package uz.semvisualsv2.module;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.Deque;

/** A small pixel-art canvas that is also a live texture, so the game can show your edit while you paint. */
public final class PixelCanvas {
    private static int counter;

    public final int w, h;
    public final int[] px;
    public final Identifier id;
    private final Deque<int[]> undo = new ArrayDeque<>();
    private final Deque<int[]> redo = new ArrayDeque<>();
    private DynamicTexture texture;
    private boolean dirty = true;

    public PixelCanvas(String kind, int w, int h) {
        this.w = w;
        this.h = h;
        this.px = new int[w * h];
        this.id = Identifier.fromNamespaceAndPath(Cosmetics.NAMESPACE, "studio/" + kind + "_" + (counter++));
    }

    public int get(int x, int y) {
        return inside(x, y) ? px[y * w + x] : 0;
    }

    public boolean inside(int x, int y) {
        return x >= 0 && y >= 0 && x < w && y < h;
    }

    public void set(int x, int y, int argb) {
        if (inside(x, y)) {
            px[y * w + x] = argb;
            dirty = true;
        }
    }

    // ------------------------------------------------------------------ editing

    public void beginStroke() {
        undo.push(px.clone());
        while (undo.size() > 60) {
            undo.removeLast();
        }
        redo.clear();
    }

    public boolean undo() {
        if (undo.isEmpty()) {
            return false;
        }
        redo.push(px.clone());
        System.arraycopy(undo.pop(), 0, px, 0, px.length);
        dirty = true;
        return true;
    }

    public boolean redo() {
        if (redo.isEmpty()) {
            return false;
        }
        undo.push(px.clone());
        System.arraycopy(redo.pop(), 0, px, 0, px.length);
        dirty = true;
        return true;
    }

    public void clear() {
        beginStroke();
        java.util.Arrays.fill(px, 0);
        dirty = true;
    }

    public void plot(int x, int y, int argb, int brush, boolean mirror) {
        for (int dy = 0; dy < brush; dy++) {
            for (int dx = 0; dx < brush; dx++) {
                int xx = x + dx - brush / 2, yy = y + dy - brush / 2;
                set(xx, yy, argb);
                if (mirror) {
                    set(w - 1 - xx, yy, argb);
                }
            }
        }
    }

    /** Bresenham line between two pixels. */
    public void line(int x0, int y0, int x1, int y1, int argb, int brush, boolean mirror) {
        int dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0);
        int sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1, err = dx + dy;
        while (true) {
            plot(x0, y0, argb, brush, mirror);
            if (x0 == x1 && y0 == y1) {
                break;
            }
            int e2 = 2 * err;
            if (e2 >= dy) {
                err += dy;
                x0 += sx;
            }
            if (e2 <= dx) {
                err += dx;
                y0 += sy;
            }
        }
    }

    public void fill(int x, int y, int argb, boolean mirror) {
        if (!inside(x, y)) {
            return;
        }
        int target = get(x, y);
        if (target == argb) {
            return;
        }
        Deque<int[]> stack = new ArrayDeque<>();
        stack.push(new int[]{x, y});
        while (!stack.isEmpty()) {
            int[] p = stack.pop();
            if (!inside(p[0], p[1]) || get(p[0], p[1]) != target) {
                continue;
            }
            set(p[0], p[1], argb);
            stack.push(new int[]{p[0] + 1, p[1]});
            stack.push(new int[]{p[0] - 1, p[1]});
            stack.push(new int[]{p[0], p[1] + 1});
            stack.push(new int[]{p[0], p[1] - 1});
        }
        if (mirror) {
            // flood the mirrored side too when it was a different region
            int mx = w - 1 - x;
            if (get(mx, y) == target) {
                fill(mx, y, argb, false);
            }
        }
    }

    // ------------------------------------------------------------------ texture

    /** Uploads changes to the game texture. Call before drawing the canvas or using its texture id. */
    public void sync() {
        Minecraft mc = Minecraft.getInstance();
        if (texture == null) {
            texture = new DynamicTexture(() -> "semvisualsv2 studio", new NativeImage(w, h, true));
            mc.getTextureManager().register(id, texture);
            dirty = true;
        }
        if (dirty) {
            NativeImage pixels = texture.getPixels();
            if (pixels != null) {
                for (int y = 0; y < h; y++) {
                    for (int x = 0; x < w; x++) {
                        pixels.setPixel(x, y, px[y * w + x]);
                    }
                }
                texture.upload();
            }
            dirty = false;
        }
    }

    public void dispose() {
        if (texture != null) {
            Minecraft.getInstance().getTextureManager().release(id);
            texture = null;
        }
    }

    // ------------------------------------------------------------------ files

    public BufferedImage toImage() {
        BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        img.setRGB(0, 0, w, h, px, 0, w);
        return img;
    }

    public void save(File file) throws IOException {
        file.getParentFile().mkdirs();
        ImageIO.write(toImage(), "png", file);
    }

    /** Copies an image into the canvas. A different size is resampled (averaged when shrinking, nearest when growing). */
    public void load(BufferedImage src) {
        beginStroke();
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int x0 = x * src.getWidth() / w, x1 = Math.max(x0 + 1, (x + 1) * src.getWidth() / w);
                int y0 = y * src.getHeight() / h, y1 = Math.max(y0 + 1, (y + 1) * src.getHeight() / h);
                long a = 0, r = 0, g = 0, b = 0;
                int n = 0;
                for (int yy = y0; yy < y1 && yy < src.getHeight(); yy++) {
                    for (int xx = x0; xx < x1 && xx < src.getWidth(); xx++) {
                        int p = src.getRGB(xx, yy);
                        int pa = (p >>> 24) & 0xFF;
                        a += pa;
                        r += ((p >> 16) & 0xFF) * pa;
                        g += ((p >> 8) & 0xFF) * pa;
                        b += (p & 0xFF) * pa;
                        n++;
                    }
                }
                if (n == 0 || a == 0) {
                    px[y * w + x] = 0;
                } else {
                    int aa = (int) (a / n);
                    px[y * w + x] = (aa << 24) | ((int) (r / a) << 16) | ((int) (g / a) << 8) | (int) (b / a);
                }
            }
        }
        dirty = true;
    }

    public void load(File file) throws IOException {
        BufferedImage img = ImageIO.read(file);
        if (img == null) {
            throw new IOException("unsupported image");
        }
        load(img);
    }

    public static BufferedImage readResource(Identifier id) throws IOException {
        var resource = Minecraft.getInstance().getResourceManager().getResource(id);
        if (resource.isEmpty()) {
            throw new IOException("missing " + id);
        }
        try (InputStream in = resource.get().open()) {
            BufferedImage img = ImageIO.read(in);
            if (img == null) {
                throw new IOException("unsupported image " + id);
            }
            return img;
        }
    }
}
