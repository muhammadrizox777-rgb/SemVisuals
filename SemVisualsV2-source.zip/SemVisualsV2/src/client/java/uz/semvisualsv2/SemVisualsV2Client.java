package uz.semvisualsv2;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import org.lwjgl.glfw.GLFW;
import uz.semvisualsv2.core.Friends;
import uz.semvisualsv2.core.Markers;
import uz.semvisualsv2.core.Module;
import uz.semvisualsv2.core.ModuleManager;
import uz.semvisualsv2.core.Util;
import uz.semvisualsv2.gui.ClickGui;
import uz.semvisualsv2.module.Cosmetics;
import uz.semvisualsv2.module.Extra;
import uz.semvisualsv2.module.Hud;
import uz.semvisualsv2.module.Mixed;
import uz.semvisualsv2.module.More;
import uz.semvisualsv2.module.Rest;
import uz.semvisualsv2.module.V2;
import uz.semvisualsv2.module.Utils;
import uz.semvisualsv2.module.Visuals;

public final class SemVisualsV2Client implements ClientModInitializer {
    private static KeyMapping openMenuKey;
    private boolean wasInWorld;
    private boolean configLoaded;

    @Override
    public void onInitializeClient() {
        Visuals.registerAll();
        Hud.registerAll();
        Utils.registerAll();
        Extra.registerAll();
        More.registerAll();
        Rest.registerAll();
        Mixed.registerAll();
        V2.registerAll();
        Cosmetics.registerAll();
        Friends.load();
        Markers.load();

        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath("semvisualsv2", "main")
        );
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.semvisualsv2.open_menu",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                category
        ));

        // Replace the vanilla crosshair when the Crosshair module is on.
        HudElementRegistry.replaceElement(VanillaHudElements.CROSSHAIR, original -> (graphics, delta) -> {
            Visuals.Crosshair crosshair = ModuleManager.get(Visuals.Crosshair.class);
            if (crosshair != null && crosshair.isEnabled()) {
                crosshair.draw(graphics);
            } else {
                original.render(graphics, delta);
            }
        });

        HudElementRegistry.replaceElement(VanillaHudElements.SCOREBOARD, original -> (graphics, delta) -> {
            More.ScoreboardHud m = ModuleManager.get(More.ScoreboardHud.class);
            if (m != null && m.isEnabled()) {
                graphics.pose().pushMatrix();
                graphics.pose().translate((float) m.dx, (float) m.dy);
                original.render(graphics, delta);
                graphics.pose().popMatrix();
            } else {
                original.render(graphics, delta);
            }
        });
        HudElementRegistry.replaceElement(VanillaHudElements.BOSS_BAR, original -> (graphics, delta) -> {
            More.BossbarHud m = ModuleManager.get(More.BossbarHud.class);
            if (m != null && m.isEnabled()) {
                graphics.pose().pushMatrix();
                graphics.pose().translate((float) m.dx, (float) m.dy);
                original.render(graphics, delta);
                graphics.pose().popMatrix();
            } else {
                original.render(graphics, delta);
            }
        });

        // Inventory screens: shulker preview, locked slot marks and scrolling items between inventories.
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof AbstractContainerScreen<?> container) {
                ScreenEvents.afterRender(screen).register((s, graphics, mouseX, mouseY, tickDelta) -> {
                    Mixed.ShulkerPreview.draw(container, graphics, mouseX, mouseY);
                    Mixed.LockSlot.drawLocks(container, graphics);
                });
                ScreenMouseEvents.allowMouseScroll(screen).register((s, mouseX, mouseY, horizontal, vertical) ->
                        !Mixed.ItemScroller.onScroll(container));
            }
        });

        // All module overlays are drawn after the vanilla HUD.
        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("semvisualsv2", "overlay"), (graphics, delta) -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.options.hideGui || mc.player == null) {
                return;
            }
            for (Module m : ModuleManager.MODULES) {
                if (m.isEnabled()) {
                    try {
                        m.renderHud(graphics, delta);
                    } catch (RuntimeException ignored) {
                        // a broken overlay must never crash the game
                    }
                }
            }
        });

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (Cosmetics.isCosmetic(entity)) {
                return InteractionResult.FAIL;
            }
            if (world.isClientSide()) {
                for (Module m : ModuleManager.MODULES) {
                    if (m.isEnabled() && m.blocksAttack(entity)) {
                        return InteractionResult.FAIL;
                    }
                }
            }
            if (world.isClientSide() && entity instanceof LivingEntity living) {
                Util.onAttack(living);
                for (Module m : ModuleManager.MODULES) {
                    if (m.isEnabled()) {
                        m.onAttack(living);
                    }
                }
            }
            return InteractionResult.PASS;
        });

        ClientReceiveMessageEvents.MODIFY_GAME.register((message, overlay) -> {
            Utils.ChatHelper chat = ModuleManager.get(Utils.ChatHelper.class);
            return chat != null && chat.isEnabled() && !overlay ? chat.modify(message) : message;
        });

        ClientSendMessageEvents.ALLOW_COMMAND.register(command -> {
            Utils.CommandSafe safe = ModuleManager.get(Utils.CommandSafe.class);
            return safe == null || !safe.isEnabled() || safe.allows(command);
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Load the saved config on the first tick: Minecraft's options are guaranteed to exist by then.
            if (!configLoaded) {
                configLoaded = true;
                ModuleManager.load("default");
            }
            Utils.AutoReconnect reconnect = ModuleManager.get(Utils.AutoReconnect.class);
            if (reconnect != null && reconnect.isEnabled()) {
                reconnect.tickAlways();
            }

            boolean inWorld = client.player != null && client.level != null;
            if (inWorld && !wasInWorld) {
                for (Module m : ModuleManager.MODULES) {
                    if (m.isEnabled()) {
                        m.onJoin();
                    }
                }
            }
            wasInWorld = inWorld;
            if (!inWorld) {
                return;
            }

            while (openMenuKey.consumeClick()) {
                if (client.screen == null) {
                    client.setScreen(new ClickGui());
                }
            }

            for (Module m : ModuleManager.MODULES) {
                if (client.screen == null && m.key >= 0) {
                    boolean down = InputConstants.isKeyDown(client.getWindow(), m.key);
                    if (down && !m.keyWasDownPublic()) {
                        m.toggle();
                    }
                    m.setKeyWasDown(down);
                }
                if (m.isEnabled()) {
                    try {
                        m.onTick();
                    } catch (RuntimeException ignored) {
                        // keep the game running if one module misbehaves
                    }
                }
            }
        });
    }
}
