package uz.semvisualsv2.core;

public enum Category {
    VISUALS("Visuals"),
    HUD("HUD"),
    UTILITIES("Utilities"),
    COSMETICS("Cosmetics");

    public final String title;

    Category(String title) {
        this.title = title;
    }
}
