package uz.semvisualsv2.core;

import net.minecraft.locale.Language;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.function.BooleanSupplier;

/**
 * Uzbek (Latin) interface text. The translations live in assets/semvisualsv2/lang/en_us.json (and uz_uz.json),
 * keyed by "semvisualsv2.t." + the English text in lowercase with non-alphanumerics turned into "_".
 * Internal names (config keys, module names, mode values) stay English; only what the player sees is translated.
 * A string without an entry is shown as it is.
 */
public final class Lang {
    /** Set by the ClientColor module. Null means the default, which is Uzbek. */
    public static BooleanSupplier uzbek = null;

    private static final Map<String, String> KEYS = new HashMap<>();

    private Lang() {
    }

    public static boolean on() {
        return uzbek == null || uzbek.getAsBoolean();
    }

    public static String keyFor(String s) {
        return "semvisualsv2.t." + s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "_").replaceAll("^_+|_+$", "");
    }

    public static String t(String s) {
        if (s == null || !on()) {
            return s;
        }
        String key = KEYS.computeIfAbsent(s, Lang::keyFor);
        Language language = Language.getInstance();
        return language.has(key) ? language.getOrDefault(key) : s;
    }

    public static String f(String format, Object... args) {
        return String.format(Locale.ROOT, t(format), args);
    }
}
