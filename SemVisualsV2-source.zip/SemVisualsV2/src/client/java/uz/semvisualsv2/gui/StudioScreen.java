package uz.semvisualsv2.gui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.player.Player;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.lwjgl.glfw.GLFW;
import uz.semvisualsv2.core.Events;
import uz.semvisualsv2.core.Lang;
import uz.semvisualsv2.core.ModuleManager;
import uz.semvisualsv2.core.Theme;
import uz.semvisualsv2.module.Cosmetics;
import uz.semvisualsv2.module.CustomTextures;
import uz.semvisualsv2.module.PixelCanvas;
import uz.semvisualsv2.module.Studio;

import java.awt.Color;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.DoubleConsumer;
import java.util.function.IntConsumer;

/**
 * The Studio: a pixel editor for your own cape, wings, skin or animal texture, with a live preview on the model.
 * Everything is saved as PNG files in the mod's config folder.
 */
public final class StudioScreen extends Screen {
    private static final int DW = 880, DH = 530;
    private static final int GLASS = 0xBE0E1424, GLASS_LIGHT = 0x26FFFFFF, GLASS_HOVER = 0x3AFFFFFF;
    private static final String[] KINDS = {"capes", "wings", "skins", "pets"};
    private static final String[] MODE_TITLES = {"Capes", "Wings", "Skin", "Pets"};
    private static final String[] NAMES = {"my_cape", "my_wings", "my_skin", ""};
    private static final int[] PALETTE = buildPalette();

    private enum Tool {
        PENCIL("Pencil"), ERASER("Eraser"), FILL("Fill"), PICKER("Picker");

        final String title;

        Tool(String title) {
            this.title = title;
        }
    }

    private record Hit(int x, int y, int w, int h, IntConsumer click, DoubleConsumer drag) {
        boolean contains(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }

    private static final PixelCanvas[] CANVASES = new PixelCanvas[4];
    private static final String[] FILE_NAMES = {"my_cape", "my_wings", "my_skin", ""};
    private static int mode = 0;
    private static int animal = 0;
    private static int templateIndex = 0;
    private static Tool tool = Tool.PENCIL;
    private static int brush = 1;
    private static boolean mirror, grid = true, guide = true;
    private static float hue = 0.72f, sat = 0.55f, val = 1f, alpha = 1f;

    private final Screen parent;
    private final List<Hit> hits = new ArrayList<>();
    private Entity previewEntity;
    private float previewYaw = 160f;
    private boolean previewSpin = true;
    private double lastDragX;
    private boolean stroking;
    private int lastX = -1, lastY = -1;
    private int mouseX, mouseY;
    private float s = 1f, ox, oy;
    private int cx, cy, ps, cw, ch; // canvas rect (design coordinates)
    private int scrollFiles;
    private boolean nameFocused;

    public StudioScreen(Screen parent) {
        super(Component.literal("Studio"));
        this.parent = parent;
    }

    private static int[] buildPalette() {
        int[] p = new int[36];
        int i = 0;
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 12; col++) {
                float h = col / 12f;
                p[i++] = row == 0 ? Theme.hsb(h, 0.85f, 1f) : (row == 1 ? Theme.hsb(h, 0.55f, 0.95f) : Theme.hsb(h, 0.9f, 0.55f));
            }
        }
        p[0] = 0xFFFFFFFF;
        p[1] = 0xFFC8CDD8;
        p[2] = 0xFF8791A8;
        p[3] = 0xFF4A5268;
        p[4] = 0xFF232838;
        p[5] = 0xFF000000;
        return p;
    }

    private int color() {
        return ((int) (alpha * 255) << 24) | (Theme.hsb(hue, sat, val) & 0xFFFFFF);
    }

    private void setColor(int argb) {
        float[] hsb = Color.RGBtoHSB((argb >> 16) & 0xFF, (argb >> 8) & 0xFF, argb & 0xFF, null);
        hue = hsb[0];
        sat = hsb[1];
        val = hsb[2];
        alpha = ((argb >>> 24) & 0xFF) / 255f;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        minecraft.setScreen(parent);
    }

    @Override
    public void removed() {
        Studio.clear();
        super.removed();
    }

    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float delta) {
        g.fillGradient(0, 0, width, height, 0xC004060E, 0x770A1020);
    }

    // ================================================================== canvases

    private String animalName() {
        return Cosmetics.PETS[animal];
    }

    private PixelCanvas canvas() {
        PixelCanvas c = CANVASES[mode];
        if (c == null) {
            c = create(mode);
            CANVASES[mode] = c;
        }
        return c;
    }

    private PixelCanvas create(int m) {
        try {
            switch (m) {
                case 0 -> {
                    PixelCanvas c = new PixelCanvas("cape", 64, 32);
                    c.load(PixelCanvas.readResource(Identifier.fromNamespaceAndPath(Cosmetics.NAMESPACE,
                            "textures/cape/" + Cosmetics.slug(Cosmetics.CAPES[0]) + ".png")));
                    return c;
                }
                case 1 -> {
                    PixelCanvas c = new PixelCanvas("wings", 64, 32);
                    c.load(PixelCanvas.readResource(Identifier.fromNamespaceAndPath(Cosmetics.NAMESPACE,
                            "textures/wings/" + Cosmetics.slug(Cosmetics.WINGS[0]) + ".png")));
                    return c;
                }
                case 2 -> {
                    PixelCanvas c = new PixelCanvas("skin", 64, 64);
                    c.load(PixelCanvas.readResource(Identifier.withDefaultNamespace("textures/entity/player/wide/steve.png")));
                    return c;
                }
                default -> {
                    return createPetCanvas();
                }
            }
        } catch (Exception e) {
            return new PixelCanvas(KINDS[m], m == 2 ? 64 : 64, m == 2 ? 64 : 32);
        }
    }

    private Entity makePreviewEntity() {
        if (minecraft.level == null) {
            return null;
        }
        Entity e = Cosmetics.Pet.entityType(animalName()).create(minecraft.level, EntitySpawnReason.COMMAND);
        if (e != null) {
            e.setId(Studio.PET_PREVIEW_ID);
            e.setSilent(true);
            e.setNoGravity(true);
        }
        return e;
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private PixelCanvas createPetCanvas() {
        previewEntity = makePreviewEntity();
        int w = 64, h = 32;
        java.awt.image.BufferedImage base = null;
        try {
            File saved = CustomTextures.dir("pets").resolve(Cosmetics.slug(animalName()) + ".png").toFile();
            if (saved.isFile()) {
                base = javax.imageio.ImageIO.read(saved);
            } else if (previewEntity != null) {
                EntityRenderer renderer = minecraft.getEntityRenderDispatcher().getRenderer(previewEntity);
                EntityRenderState state = renderer.createRenderState(previewEntity, 1f);
                if (renderer instanceof LivingEntityRenderer living && state instanceof LivingEntityRenderState ls) {
                    base = PixelCanvas.readResource(living.getTextureLocation(ls));
                }
            }
        } catch (Exception ignored) {
        }
        if (base != null) {
            w = base.getWidth();
            h = base.getHeight();
        }
        PixelCanvas c = new PixelCanvas("pet", w, h);
        if (base != null) {
            c.load(base);
        }
        return c;
    }

    private void setMode(int m) {
        mode = m;
        stroking = false;
        scrollFiles = 0;
        nameFocused = false;
        templateIndex = 0;
        if (m == 3 && previewEntity == null) {
            previewEntity = makePreviewEntity();
        }
    }

    private void nextAnimal(int dir) {
        animal = Math.floorMod(animal + dir, Cosmetics.PETS.length);
        if (CANVASES[3] != null) {
            CANVASES[3].dispose();
        }
        CANVASES[3] = null;
        previewEntity = null;
        CANVASES[3] = createPetCanvas();
    }

    private void nextTemplate() {
        try {
            PixelCanvas c = canvas();
            templateIndex++;
            switch (mode) {
                case 0 -> c.load(PixelCanvas.readResource(Identifier.fromNamespaceAndPath(Cosmetics.NAMESPACE,
                        "textures/cape/" + Cosmetics.slug(Cosmetics.CAPES[templateIndex % Cosmetics.CAPES.length]) + ".png")));
                case 1 -> c.load(PixelCanvas.readResource(Identifier.fromNamespaceAndPath(Cosmetics.NAMESPACE,
                        "textures/wings/" + Cosmetics.slug(Cosmetics.WINGS[templateIndex % Cosmetics.WINGS.length]) + ".png")));
                case 2 -> c.load(PixelCanvas.readResource(Identifier.withDefaultNamespace(
                        templateIndex % 2 == 0 ? "textures/entity/player/wide/steve.png" : "textures/entity/player/wide/alex.png")));
                default -> {
                    CANVASES[3].dispose();
                    CANVASES[3] = null;
                    File saved = CustomTextures.dir("pets").resolve(Cosmetics.slug(animalName()) + ".png").toFile();
                    saved.delete();
                    CANVASES[3] = createPetCanvas();
                }
            }
        } catch (Exception e) {
            Events.toast("Studio", "Could not read this image", false);
        }
    }

    // ================================================================== drawing helpers

    private void rr(GuiGraphics g, int x, int y, int w, int h, int r, int color) {
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) {
            g.fill(x, y, x + w, y + h, color);
            return;
        }
        g.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
            g.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            g.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, color);
        }
    }

    private boolean inside(int x, int y, int w, int h) {
        return mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
    }

    private void hit(int x, int y, int w, int h, IntConsumer click) {
        hits.add(new Hit(x, y, w, h, click, null));
    }

    private void hitDrag(int x, int y, int w, int h, IntConsumer click, DoubleConsumer drag) {
        hits.add(new Hit(x, y, w, h, click, drag));
    }

    private int accent() {
        return Theme.accent();
    }

    private void bigText(GuiGraphics g, String t, int x, int y, int color) {
        g.pose().pushMatrix();
        g.pose().translate((float) x, (float) y);
        g.pose().scale(1.5f, 1.5f);
        Theme.text(g, t, 0, 0, color);
        g.pose().popMatrix();
    }

    private void button(GuiGraphics g, int x, int y, int w, int h, String label, boolean active, Runnable action) {
        boolean hover = inside(x, y, w, h);
        rr(g, x, y, w, h, h / 2, active ? Theme.withAlpha(accent(), 0x77) : (hover ? GLASS_HOVER : GLASS_LIGHT));
        Theme.text(g, label, x + (w - Theme.width(label)) / 2, y + (h - 8) / 2, active ? Theme.TEXT : 0xFFC4CCDD);
        hit(x, y, w, h, b -> action.run());
    }

    private void toggle(GuiGraphics g, int x, int y, int w, String label, boolean on, Runnable action) {
        boolean hover = inside(x, y, w, 22);
        rr(g, x, y, w, 22, 11, hover ? GLASS_HOVER : GLASS_LIGHT);
        Theme.text(g, label, x + 10, y + 7, Theme.TEXT);
        rr(g, x + w - 34, y + 5, 24, 12, 6, on ? accent() : 0xFF2B3350);
        rr(g, on ? x + w - 21 : x + w - 32, y + 7, 8, 8, 4, on ? 0xFFFFFFFF : 0xFF8791A8);
        hit(x, y, w, 22, b -> action.run());
    }

    // ================================================================== frame

    @Override
    public void render(GuiGraphics g, int mxs, int mys, float delta) {
        s = Math.min(1f, Math.min((width - 16) / (float) DW, (height - 16) / (float) DH));
        ox = (width - DW * s) / 2f;
        oy = (height - DH * s) / 2f;
        mouseX = (int) ((mxs - ox) / s);
        mouseY = (int) ((mys - oy) / s);
        hits.clear();

        PixelCanvas canvas = canvas();
        canvas.sync();
        Studio.capeId = mode == 0 ? canvas.id : null;
        Studio.wingsId = mode == 1 ? canvas.id : null;
        Studio.skinId = mode == 2 ? canvas.id : null;
        Studio.petId = mode == 3 ? canvas.id : null;

        g.pose().pushMatrix();
        g.pose().translate(ox, oy);
        g.pose().scale(s, s);
        rr(g, -1, -1, DW + 2, DH + 2, 15, 0x30FFFFFF);
        rr(g, 0, 0, DW, DH, 14, GLASS);
        for (int i = 0; i < DW - 28; i += 2) {
            g.fill(14 + i, 1, 16 + i, 3, Theme.mix(accent(), Theme.hsb(0.6f, 0.5f, 1f), i / (float) DW));
        }

        // header
        button(g, 16, 14, 70, 22, Lang.t("Back"), false, this::onClose);
        bigText(g, Lang.t("Studio"), 98, 12, Theme.TEXT);
        Theme.text(g, Lang.t("Draw your own cape, wings, skin or animal pixel by pixel."), 98, 36, Theme.MUTED);
        int x = 16;
        for (int i = 0; i < 4; i++) {
            String label = Lang.t(MODE_TITLES[i]);
            int w = Theme.width(label) + 28;
            final int target = i;
            button(g, x, 60, w, 24, label, i == mode, () -> setMode(target));
            x += w + 6;
        }

        drawTools(g, canvas);
        drawCanvas(g, canvas);
        drawRight(g, canvas);
        g.pose().popMatrix();
    }

    // ------------------------------------------------------------------ left column

    private void drawTools(GuiGraphics g, PixelCanvas canvas) {
        int x = 16, y = 96, w = 136;
        for (Tool t : Tool.values()) {
            final Tool target = t;
            button(g, x, y, w, 24, Lang.t(t.title), t == tool, () -> tool = target);
            y += 28;
        }
        y += 4;
        toggle(g, x, y, w, Lang.t("Mirror"), mirror, () -> mirror = !mirror);
        y += 26;
        toggle(g, x, y, w, Lang.t("Grid"), grid, () -> grid = !grid);
        y += 26;
        toggle(g, x, y, w, Lang.t("Guide"), guide, () -> guide = !guide);
        y += 28;
        Theme.text(g, Lang.t("Brush"), x + 4, y + 7, Theme.MUTED);
        for (int i = 1; i <= 3; i++) {
            final int size = i;
            button(g, x + 52 + (i - 1) * 28, y, 24, 22, Integer.toString(i), brush == i, () -> brush = size);
        }
        y += 28;
        button(g, x, y, 66, 22, Lang.t("Undo"), false, canvas::undo);
        button(g, x + 70, y, 66, 22, Lang.t("Redo"), false, canvas::redo);
        y += 26;
        button(g, x, y, 66, 22, Lang.t("Clear"), false, canvas::clear);
        button(g, x + 70, y, 66, 22, Lang.t("Template"), false, this::nextTemplate);
        y += 26;
        if (mode == 3) {
            String label = Lang.t(animalName());
            rr(g, x, y, w, 22, 11, GLASS_LIGHT);
            Theme.text(g, "<", x + 9, y + 7, Theme.MUTED);
            Theme.text(g, ">", x + w - 15, y + 7, Theme.MUTED);
            Theme.text(g, label, x + (w - Theme.width(label)) / 2, y + 7, Theme.TEXT);
            hit(x, y, w / 2, 22, b -> nextAnimal(-1));
            hit(x + w / 2, y, w / 2, 22, b -> nextAnimal(1));
        }
        // saved files
        y = 392;
        Theme.text(g, Lang.t("Saved files"), x + 4, y, Theme.MUTED);
        List<String> files = CustomTextures.list(KINDS[mode]);
        int top = y + 14, rows = 5;
        scrollFiles = Math.max(0, Math.min(scrollFiles, Math.max(0, files.size() - rows)));
        for (int i = 0; i < rows && i + scrollFiles < files.size(); i++) {
            String name = files.get(i + scrollFiles);
            int ry = top + i * 22;
            boolean hover = inside(x, ry, w, 20);
            rr(g, x, ry, w, 20, 10, hover ? GLASS_HOVER : GLASS_LIGHT);
            Theme.text(g, ellipsize(name.replaceFirst("\\.[^.]+$", ""), w - 16), x + 8, ry + 6, Theme.TEXT);
            hit(x, ry, w, 20, b -> loadFile(name));
        }
        if (files.isEmpty()) {
            Theme.text(g, Lang.t("Nothing saved yet."), x + 4, top + 6, 0xFF5E6985);
        }
    }

    private String ellipsize(String t, int maxWidth) {
        if (Theme.width(t) <= maxWidth) {
            return t;
        }
        while (t.length() > 1 && Theme.width(t + "...") > maxWidth) {
            t = t.substring(0, t.length() - 1);
        }
        return t + "...";
    }

    private void loadFile(String name) {
        try {
            canvas().load(CustomTextures.dir(KINDS[mode]).resolve(name).toFile());
            if (mode != 3) {
                FILE_NAMES[mode] = name.replaceFirst("\\.[^.]+$", "");
            }
        } catch (Exception e) {
            Events.toast("Studio", "Could not read this image", false);
        }
    }

    // ------------------------------------------------------------------ canvas

    private List<int[]> guides() {
        List<int[]> r = new ArrayList<>();
        switch (mode) {
            case 0 -> {
                r.add(new int[]{1, 1, 10, 16, 0});   // outside of the cape
                r.add(new int[]{12, 1, 10, 16, 1});  // inside
            }
            case 1 -> {
                r.add(new int[]{24, 2, 10, 20, 0});
                r.add(new int[]{36, 2, 10, 20, 1});
            }
            case 2 -> {
                r.add(new int[]{8, 8, 8, 8, 2});     // head front
                r.add(new int[]{20, 20, 8, 12, 3});  // body front
                r.add(new int[]{44, 20, 4, 12, 4});  // right arm front
                r.add(new int[]{36, 52, 4, 12, 4});  // left arm front
                r.add(new int[]{4, 20, 4, 12, 5});   // right leg front
                r.add(new int[]{20, 52, 4, 12, 5});  // left leg front
            }
            default -> {
            }
        }
        return r;
    }

    private static final String[] GUIDE_LABELS = {"Outside", "Inside", "Head", "Body", "Arm", "Leg"};

    private void drawCanvas(GuiGraphics g, PixelCanvas canvas) {
        int ax = 164, ay = 96, aw = 416, ah = 412;
        rr(g, ax, ay, aw, ah, 12, 0x40000000);
        ps = Math.max(1, Math.min(14, Math.min((aw - 16) / canvas.w, (ah - 16) / canvas.h)));
        cw = canvas.w * ps;
        ch = canvas.h * ps;
        cx = ax + (aw - cw) / 2;
        cy = ay + (ah - ch) / 2;
        int tile = Math.max(4, ps * 2);
        for (int ty = 0; ty < ch; ty += tile) {
            for (int tx = 0; tx < cw; tx += tile) {
                int c = ((tx / tile + ty / tile) & 1) == 0 ? 0xFF2A3042 : 0xFF222838;
                g.fill(cx + tx, cy + ty, Math.min(cx + cw, cx + tx + tile), Math.min(cy + ch, cy + ty + tile), c);
            }
        }
        g.blit(RenderPipelines.GUI_TEXTURED, canvas.id, cx, cy, 0f, 0f, cw, ch, canvas.w, canvas.h, canvas.w, canvas.h);
        if (grid && ps >= 5) {
            for (int i = 0; i <= canvas.w; i++) {
                g.fill(cx + i * ps, cy, cx + i * ps + 1, cy + ch, 0x22FFFFFF);
            }
            for (int i = 0; i <= canvas.h; i++) {
                g.fill(cx, cy + i * ps, cx + cw, cy + i * ps + 1, 0x22FFFFFF);
            }
        }
        if (guide) {
            for (int[] r : guides()) {
                int gx = cx + r[0] * ps, gy = cy + r[1] * ps, gw = r[2] * ps, gh = r[3] * ps;
                int c = Theme.withAlpha(accent(), 0xCC);
                g.fill(gx, gy, gx + gw, gy + 1, c);
                g.fill(gx, gy + gh - 1, gx + gw, gy + gh, c);
                g.fill(gx, gy, gx + 1, gy + gh, c);
                g.fill(gx + gw - 1, gy, gx + gw, gy + gh, c);
                if (ps >= 5 && mode != 2) {
                    Theme.text(g, Lang.t(GUIDE_LABELS[r[4]]), gx + 3, gy + 3, 0xCCFFFFFF);
                }
            }
        }
        // hovered pixel
        int hx = Math.floorDiv(mouseX - cx, ps), hy = Math.floorDiv(mouseY - cy, ps);
        if (canvas.inside(hx, hy)) {
            int bx = cx + hx * ps, by = cy + hy * ps;
            g.fill(bx, by, bx + ps, by + 1, 0xFFFFFFFF);
            g.fill(bx, by + ps - 1, bx + ps, by + ps, 0xFFFFFFFF);
            g.fill(bx, by, bx + 1, by + ps, 0xFFFFFFFF);
            g.fill(bx + ps - 1, by, bx + ps, by + ps, 0xFFFFFFFF);
            String info = hx + ", " + hy + "   " + canvas.w + "x" + canvas.h;
            Theme.text(g, info, ax + 10, ay + ah - 14, 0xFF6F7A96);
        } else {
            Theme.text(g, Lang.t("Left click draws, right click picks a color."), ax + 10, ay + ah - 14, 0xFF6F7A96);
        }
    }

    // ------------------------------------------------------------------ right column

    private void drawRight(GuiGraphics g, PixelCanvas canvas) {
        int x = 596, w = 268;
        // live preview
        rr(g, x, 96, w, 196, 12, 0x40000000);
        rr(g, x + 1, 97, w - 2, 194, 11, 0x14FFFFFF);
        drawPreview(g, x, 96, w, 196);
        hitDrag(x, 96, w, 196, b -> {
            lastDragX = mouseX;
            previewSpin = false;
        }, dx -> {
            double nx = (dx - ox) / s;
            previewYaw += (float) (nx - lastDragX) * 1.6f;
            lastDragX = nx;
        });
        Theme.text(g, Lang.t("Drag to rotate"), x + 10, 278, 0xFF6F7A96);

        // palette
        int py = 300;
        for (int i = 0; i < PALETTE.length; i++) {
            int sx = x + (i % 12) * 22, sy = py + (i / 12) * 22;
            rr(g, sx, sy, 20, 20, 5, PALETTE[i]);
            final int c = PALETTE[i];
            hit(sx, sy, 20, 20, b -> setColor(c));
        }
        py += 70;
        rr(g, x, py, 44, 20, 6, 0xFF2A3042);
        rr(g, x + 2, py + 2, 40, 16, 5, color());
        Theme.text(g, String.format(Locale.ROOT, "#%06X  %d%%", color() & 0xFFFFFF, (int) (alpha * 100)), x + 52, py + 6, Theme.TEXT);
        py += 26;
        bar(g, x, py, w, 0, hue);
        bar(g, x, py + 14, w, 1, sat);
        bar(g, x, py + 28, w, 2, val);
        bar(g, x, py + 42, w, 3, alpha);

        // name + buttons
        int ny = 456;
        String name = mode == 3 ? Cosmetics.slug(animalName()) : FILE_NAMES[mode];
        rr(g, x, ny, w, 22, 11, nameFocused ? Theme.withAlpha(accent(), 0x55) : GLASS_LIGHT);
        String shown = mode == 3 ? name : name + (nameFocused && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
        Theme.text(g, Lang.t("File name") + ": " + ellipsize(shown, w - 90), x + 10, ny + 7, mode == 3 ? Theme.MUTED : Theme.TEXT);
        if (mode != 3) {
            hit(x, ny, w, 22, b -> nameFocused = true);
        }
        int by = 484, bw = 84;
        button(g, x, by, bw, 24, Lang.t("Save"), false, () -> save(canvas, false));
        button(g, x + bw + 8, by, bw, 24, Lang.t("Apply"), true, () -> save(canvas, true));
        button(g, x + (bw + 8) * 2, by, bw, 24, Lang.t("Open folder"), false, () -> CustomTextures.openFolder(KINDS[mode]));
    }

    private void bar(GuiGraphics g, int x, int y, int w, int which, float value) {
        int seg = 40;
        for (int i = 0; i < seg; i++) {
            float t = i / (float) (seg - 1);
            int c = switch (which) {
                case 0 -> Theme.hsb(i / (float) seg, 1f, 1f);
                case 1 -> Theme.hsb(hue, t, val);
                case 2 -> Theme.hsb(hue, sat, t);
                default -> Theme.mix(0xFF1B2030, Theme.hsb(hue, sat, val), t);
            };
            g.fill(x + w * i / seg, y, x + w * (i + 1) / seg, y + 9, c);
        }
        rr(g, x + (int) (w * Math.min(0.995f, value)) - 2, y - 2, 4, 13, 2, 0xFFFFFFFF);
        DoubleConsumer drag = px -> {
            float v = (float) Math.max(0, Math.min(1, ((px - ox) / s - x) / w));
            switch (which) {
                case 0 -> hue = Math.min(0.999f, v);
                case 1 -> sat = v;
                case 2 -> val = v;
                default -> alpha = v;
            }
        };
        hitDrag(x, y - 3, w, 15, b -> drag.accept(mouseX * s + ox), drag);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private void drawPreview(GuiGraphics g, int x, int y, int w, int h) {
        if (minecraft.player == null || minecraft.level == null) {
            return;
        }
        if (previewSpin) {
            previewYaw = (previewYaw + 0.9f) % 360f;
        }
        try {
            Entity entity = mode == 3 ? previewEntity : minecraft.player;
            if (entity == null) {
                return;
            }
            EntityRenderer renderer = minecraft.getEntityRenderDispatcher().getRenderer(entity);
            EntityRenderState state = renderer.createRenderState(entity, 1.0f);
            state.lightCoords = 15728880;
            state.shadowPieces.clear();
            state.outlineColor = 0;
            if (state instanceof LivingEntityRenderState living) {
                living.bodyRot = previewYaw;
                living.yRot = 0f;
                living.xRot = 0f;
                float size = Math.max(0.6f, Math.max(living.boundingBoxHeight, living.boundingBoxWidth));
                float scale = (h / 2.15f) * (1.8f / size) * (mode == 3 ? 0.8f : 1f);
                g.submitEntityRenderState(living, scale, new Vector3f(0f, living.boundingBoxHeight / 2f + 0.0625f, 0f),
                        new Quaternionf().rotateZ((float) Math.PI), new Quaternionf(), x, y, x + w, y + h);
            }
        } catch (RuntimeException ignored) {
            // the preview is optional
        }
    }

    // ================================================================== saving

    private void save(PixelCanvas canvas, boolean apply) {
        String name = mode == 3 ? Cosmetics.slug(animalName()) : FILE_NAMES[mode].trim().replaceAll("[^A-Za-z0-9_\\-]", "_");
        if (name.isEmpty()) {
            name = NAMES[mode].isEmpty() ? "pet" : NAMES[mode];
        }
        File file = CustomTextures.dir(KINDS[mode]).resolve(name + ".png").toFile();
        try {
            canvas.save(file);
        } catch (Exception e) {
            Events.toast("Studio", "Could not read this image", false);
            return;
        }
        Events.info("Studio", Lang.t("Saved") + ": " + name);
        if (!apply) {
            return;
        }
        switch (mode) {
            case 0 -> {
                var m = ModuleManager.get(Cosmetics.Cape.class);
                m.style.deserialize("Custom");
                m.customFile.value = name + ".png";
                m.setEnabled(true);
            }
            case 1 -> {
                var m = ModuleManager.get(Cosmetics.Wings.class);
                m.style.deserialize("Custom");
                m.customFile.value = name + ".png";
                m.setEnabled(true);
            }
            case 2 -> {
                var m = ModuleManager.get(Cosmetics.Skin.class);
                m.file.value = name + ".png";
                m.setEnabled(true);
            }
            default -> {
                var m = ModuleManager.get(Cosmetics.Pet.class);
                m.type.deserialize(animalName());
                m.setEnabled(true);
            }
        }
    }

    // ================================================================== input

    private double toDesignX(double sx) {
        return (sx - ox) / s;
    }

    private double toDesignY(double sy) {
        return (sy - oy) / s;
    }

    private boolean inCanvas(double dx, double dy) {
        return dx >= cx && dy >= cy && dx < cx + cw && dy < cy + ch;
    }

    private void applyTool(PixelCanvas c, int x, int y, boolean first) {
        int col = color();
        switch (tool) {
            case PENCIL, ERASER -> {
                int argb = tool == Tool.ERASER ? 0 : col;
                if (first || lastX < 0) {
                    c.plot(x, y, argb, brush, mirror);
                } else {
                    c.line(lastX, lastY, x, y, argb, brush, mirror);
                }
            }
            case FILL -> c.fill(x, y, col, mirror);
            case PICKER -> {
                int p = c.get(x, y);
                if ((p >>> 24) != 0) {
                    setColor(p);
                }
                tool = Tool.PENCIL;
            }
        }
        lastX = x;
        lastY = y;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        nameFocused = false;
        double dx = toDesignX(event.x()), dy = toDesignY(event.y());
        PixelCanvas c = canvas();
        if (inCanvas(dx, dy)) {
            int px = (int) ((dx - cx) / ps), py = (int) ((dy - cy) / ps);
            if (event.button() == 1) {
                int p = c.get(px, py);
                if ((p >>> 24) != 0) {
                    setColor(p);
                }
                return true;
            }
            c.beginStroke();
            stroking = true;
            lastX = -1;
            applyTool(c, px, py, true);
            return true;
        }
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (h.contains(dx, dy)) {
                mouseX = (int) dx;
                mouseY = (int) dy;
                h.click().accept(event.button());
                if (h.drag() != null) {
                    draggingHit = h;
                }
                return true;
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    private Hit draggingHit;

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double ddx, double ddy) {
        if (stroking && (tool == Tool.PENCIL || tool == Tool.ERASER)) {
            double dx = toDesignX(event.x()), dy = toDesignY(event.y());
            int px = (int) Math.floor((dx - cx) / ps), py = (int) Math.floor((dy - cy) / ps);
            applyTool(canvas(), Math.max(0, Math.min(canvas().w - 1, px)), Math.max(0, Math.min(canvas().h - 1, py)), false);
            return true;
        }
        if (draggingHit != null && draggingHit.drag() != null) {
            draggingHit.drag().accept(event.x());
            return true;
        }
        return super.mouseDragged(event, ddx, ddy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        stroking = false;
        draggingHit = null;
        lastX = -1;
        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseScrolled(double x, double y, double horizontal, double vertical) {
        double dx = toDesignX(x);
        if (dx < 160) {
            scrollFiles = Math.max(0, scrollFiles - (int) Math.signum(vertical));
        }
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (nameFocused && mode != 3) {
            String n = FILE_NAMES[mode];
            if (key == GLFW.GLFW_KEY_BACKSPACE && !n.isEmpty()) {
                FILE_NAMES[mode] = n.substring(0, n.length() - 1);
            } else if (key == GLFW.GLFW_KEY_ESCAPE || key == 257) {
                nameFocused = false;
            }
            return true;
        }
        if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            onClose();
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        if (nameFocused && mode != 3 && FILE_NAMES[mode].length() < 24 && event.codepoint() >= 32) {
            FILE_NAMES[mode] += event.codepointAsString();
            return true;
        }
        return super.charTyped(event);
    }
}
