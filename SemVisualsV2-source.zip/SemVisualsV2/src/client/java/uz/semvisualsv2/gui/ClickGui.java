package uz.semvisualsv2.gui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.lwjgl.glfw.GLFW;
import uz.semvisualsv2.core.Category;
import uz.semvisualsv2.core.Events;
import uz.semvisualsv2.core.Friends;
import uz.semvisualsv2.core.Lang;
import uz.semvisualsv2.core.Markers;
import uz.semvisualsv2.core.Module;
import uz.semvisualsv2.core.ModuleManager;
import uz.semvisualsv2.core.Setting;
import uz.semvisualsv2.core.Theme;
import uz.semvisualsv2.core.Util;
import uz.semvisualsv2.module.Cosmetics;
import uz.semvisualsv2.module.CustomTextures;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.function.DoubleConsumer;
import java.util.function.IntConsumer;

/**
 * V2 menu. Not a window in the middle of the screen: a floating navigation island at the top, one glass window per
 * category that you can drag around and collapse, and a wardrobe with a live preview of your own player for cosmetics.
 */
public final class ClickGui extends Screen {
    private enum Tab {
        MODULES("Modules"), COSMETICS("Cosmetics"), STUDIO("Studio"), CONFIGS("Configs"), FRIENDS("Friends"), MARKERS("Markers"), EVENTS("Events");

        final String title;

        Tab(String title) {
            this.title = title;
        }
    }

    private enum Sub {
        CAPES("Capes"), WINGS("Wings"), PETS("Pets"), BIRDS("Birds");

        final String title;

        Sub(String title) {
            this.title = title;
        }
    }

    /** A floating category window. Kept between openings. */
    private static final class Win {
        final Category category;
        int x, y, scroll;
        boolean collapsed;

        Win(Category category) {
            this.category = category;
        }
    }

    private record Hit(int x, int y, int w, int h, int clipTop, int clipBottom, IntConsumer click, DoubleConsumer drag) {
        boolean contains(double mx, double my) {
            return mx >= x && mx < x + w && my >= Math.max(y, clipTop) && my < Math.min(y + h, clipBottom);
        }
    }

    private static Identifier tex(String path) {
        return Identifier.fromNamespaceAndPath(Cosmetics.NAMESPACE, path);
    }

    private static final Identifier LOGO = tex("icon.png");
    private static final Identifier ICON_SEARCH = tex("textures/gui/tab_search.png");
    private static final Identifier ICON_EDITOR = tex("textures/gui/tab_editor.png");
    private static final Identifier ICON_CLOSE = tex("textures/gui/tab_close.png");
    private static final Identifier ICON_GEAR = tex("textures/gui/cat_utilities.png");

    private static final int WIN_W = 184, HEADER_H = 30, ROW_H = 24;
    private static final int GLASS = 0xBE0E1424, GLASS_LIGHT = 0x26FFFFFF, GLASS_HOVER = 0x3AFFFFFF;

    private static final List<Win> WINS = new ArrayList<>();
    private static final Set<Module> EXPANDED = new HashSet<>();
    private static Tab rememberedTab = Tab.MODULES;
    private static Sub rememberedSub = Sub.CAPES;

    private final List<Hit> hits = new ArrayList<>();
    private final long openedAt = System.currentTimeMillis();
    private Hit dragging;
    private Win dragWin;
    private int grabX, grabY;
    private Tab tab = rememberedTab;
    private Sub sub = rememberedSub;
    private int mouseX, mouseY;
    private int scrollList, scrollGrid, scrollSettings;
    private Module listeningModule;
    private Setting.Key listeningSetting;
    private String input = "";
    private boolean inputFocused;
    private String search = "";
    private boolean searchFocused;
    private List<String> customFiles = new ArrayList<>();
    private float previewYaw = 160f;
    private double previewLastX;
    private boolean previewSpin = true;
    private int mx0, my0, mw, mh; // modal panel

    public ClickGui() {
        super(Component.literal("Sem Visuals V2"));
        refreshCustom();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        rememberedTab = tab;
        rememberedSub = sub;
        ModuleManager.save(ModuleManager.currentConfig);
        super.onClose();
    }

    // ================================================================== helpers

    private float ease(long delayMs) {
        float t = Math.max(0f, Math.min(1f, (System.currentTimeMillis() - openedAt - delayMs) / 260f));
        return 1f - (1f - t) * (1f - t) * (1f - t);
    }

    private int accent() {
        return Theme.accent();
    }

    private int accent2() {
        int a = accent();
        float[] hsb = java.awt.Color.RGBtoHSB((a >> 16) & 0xFF, (a >> 8) & 0xFF, a & 0xFF, null);
        return Theme.hsb((hsb[0] + 0.14f) % 1f, Math.min(1f, hsb[1] * 0.85f + 0.1f), 1f);
    }

    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float delta) {
        float e = ease(0);
        g.fillGradient(0, 0, width, height, Theme.withAlpha(0x04060E, (int) (0xB0 * e)), Theme.withAlpha(0x0A1020, (int) (0x55 * e)));
    }

    private void rr(GuiGraphics g, int x, int y, int w, int h, int r, int color) {
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) {
            g.fill(x, y, x + w, y + h, color);
            return;
        }
        g.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
            g.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            g.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, color);
        }
    }

    /** A translucent glass panel with a light border and a highlight on top. */
    private void glass(GuiGraphics g, int x, int y, int w, int h, int r) {
        rr(g, x - 1, y - 1, w + 2, h + 2, r + 1, 0x30FFFFFF);
        rr(g, x, y, w, h, r, GLASS);
        g.fill(x + r, y + 1, x + w - r, y + 2, 0x24FFFFFF);
    }

    private void gradBar(GuiGraphics g, int x, int y, int w, int h) {
        int a = accent(), b = accent2();
        for (int i = 0; i < w; i += 2) {
            g.fill(x + i, y, Math.min(x + w, x + i + 2), y + h, Theme.mix(a, b, i / (float) Math.max(1, w)));
        }
    }

    private boolean inside(int x, int y, int w, int h) {
        return mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
    }

    private void hit(int x, int y, int w, int h, IntConsumer click) {
        hits.add(new Hit(x, y, w, h, Integer.MIN_VALUE, Integer.MAX_VALUE, click, null));
    }

    private void hitClipped(int x, int y, int w, int h, int top, int bottom, IntConsumer click, DoubleConsumer drag) {
        hits.add(new Hit(x, y, w, h, top, bottom, click, drag));
    }

    private void icon(GuiGraphics g, Identifier id, int x, int y, int size) {
        g.blit(RenderPipelines.GUI_TEXTURED, id, x, y, 0f, 0f, size, size, 64, 64, 64, 64);
    }

    private void toggle(GuiGraphics g, int x, int y, boolean on) {
        if (on) {
            rr(g, x, y, 24, 12, 6, accent());
            rr(g, x + 13, y + 2, 8, 8, 4, 0xFFFFFFFF);
        } else {
            rr(g, x, y, 24, 12, 6, 0xFF2B3350);
            rr(g, x + 2, y + 2, 8, 8, 4, 0xFF8791A8);
        }
    }

    private String ellipsize(String s, int maxWidth) {
        if (Theme.width(s) <= maxWidth) {
            return s;
        }
        while (s.length() > 1 && Theme.width(s + "...") > maxWidth) {
            s = s.substring(0, s.length() - 1);
        }
        return s + "...";
    }

    private void bigText(GuiGraphics g, String s, int x, int y, int color, float scale) {
        g.pose().pushMatrix();
        g.pose().translate((float) x, (float) y);
        g.pose().scale(scale, scale);
        Theme.text(g, s, 0, 0, color);
        g.pose().popMatrix();
    }

    private void pill(GuiGraphics g, int x, int y, int w, int h, String label, boolean active, Runnable action) {
        boolean hover = inside(x, y, w, h);
        if (active) {
            rr(g, x, y, w, h, h / 2, Theme.withAlpha(accent(), 0x55));
            gradBar(g, x + 8, y + h - 3, w - 16, 2);
        } else if (hover) {
            rr(g, x, y, w, h, h / 2, GLASS_LIGHT);
        }
        Theme.text(g, label, x + (w - Theme.width(label)) / 2, y + (h - 8) / 2 - (active ? 1 : 0), active ? Theme.TEXT : Theme.MUTED);
        hit(x, y, w, h, b -> action.run());
    }

    private void button(GuiGraphics g, int x, int y, int w, int h, String label, Runnable action) {
        boolean hover = inside(x, y, w, h);
        rr(g, x, y, w, h, h / 2, hover ? Theme.withAlpha(accent(), 0x66) : GLASS_LIGHT);
        Theme.text(g, label, x + (w - Theme.width(label)) / 2, y + (h - 8) / 2, Theme.TEXT);
        hit(x, y, w, h, b -> action.run());
    }

    private void smallButton(GuiGraphics g, int x, int y, int w, int h, String label, int top, int bottom, Runnable action) {
        boolean hover = inside(x, y, w, h) && mouseY >= top && mouseY < bottom;
        rr(g, x, y, w, h, h / 2, hover ? Theme.withAlpha(accent(), 0x66) : GLASS_LIGHT);
        Theme.text(g, label, x + (w - Theme.width(label)) / 2, y + (h - 8) / 2, Theme.TEXT);
        hitClipped(x, y, w, h, top, bottom, b -> action.run(), null);
    }

    // ================================================================== frame

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        mouseX = mx;
        mouseY = my;
        hits.clear();
        if (WINS.isEmpty()) {
            for (Category c : Category.values()) {
                WINS.add(new Win(c));
            }
            placeWindows();
        }
        if (tab == Tab.MODULES) {
            int i = 0;
            for (Win w : WINS) {
                drawWindow(g, w, i++);
            }
        } else {
            drawModal(g);
        }
        drawIsland(g);
        if (tab == Tab.MODULES && WINS.isEmpty()) {
            return;
        }
    }

    private void placeWindows() {
        int perRow = Math.max(1, (width - 16) / (WIN_W + 12));
        int i = 0;
        for (Win w : WINS) {
            w.x = 16 + (i % perRow) * (WIN_W + 12);
            w.y = 66 + (i / perRow) * 200;
            i++;
        }
    }

    // ------------------------------------------------------------------ top island

    private void drawIsland(GuiGraphics g) {
        float e = ease(0);
        int slide = (int) ((1f - e) * -30);
        Tab[] tabs = Tab.values();
        int tabsW = 0;
        for (Tab t : tabs) {
            tabsW += Theme.width(Lang.t(t.title)) + 22;
        }
        int searchW = 130;
        int total = 12 + 28 + 10 + tabsW + 10 + searchW + 8 + 26 + 4 + 26 + 10;
        int ix = (width - total) / 2, iy = 10 + slide, ih = 34;
        glass(g, ix, iy, total, ih, 17);
        int x = ix + 12;
        g.blit(RenderPipelines.GUI_TEXTURED, LOGO, x, iy + 4, 0f, 0f, 26, 26, 128, 128, 128, 128);
        x += 38;
        for (Tab t : tabs) {
            String label = Lang.t(t.title);
            int w = Theme.width(label) + 22;
            final Tab target = t;
            pill(g, x, iy + 5, w, 24, label, t == tab, () -> switchTab(target));
            x += w;
        }
        x += 10;
        rr(g, x, iy + 6, searchW, 22, 11, searchFocused ? Theme.withAlpha(accent(), 0x55) : GLASS_LIGHT);
        icon(g, ICON_SEARCH, x + 8, iy + 11, 12);
        boolean empty = search.isEmpty();
        String shown = empty && !searchFocused ? Lang.t("Search...") : search + (searchFocused && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
        Theme.text(g, ellipsize(shown, searchW - 34), x + 24, iy + 13, empty && !searchFocused ? Theme.MUTED : Theme.TEXT);
        final int sx = x;
        hit(sx, iy + 6, searchW, 22, b -> {
            tab = Tab.MODULES;
            searchFocused = true;
        });
        x += searchW + 8;
        iconCircle(g, ICON_EDITOR, x, iy + 4, "HUD Editor", () -> minecraft.setScreen(new HudEditor(this)));
        x += 30;
        iconCircle(g, ICON_CLOSE, x, iy + 4, "Close", this::onClose);
    }

    private void iconCircle(GuiGraphics g, Identifier ic, int x, int y, String tip, Runnable action) {
        boolean hover = inside(x, y, 26, 26);
        rr(g, x, y, 26, 26, 13, hover ? Theme.withAlpha(accent(), 0x66) : GLASS_LIGHT);
        icon(g, ic, x + 5, y + 5, 16);
        hit(x, y, 26, 26, b -> action.run());
        if (hover) {
            String label = Lang.t(tip);
            int w = Theme.width(label) + 14;
            rr(g, x + 13 - w / 2, y + 32, w, 18, 6, 0xF0141B33);
            Theme.text(g, label, x + 13 - w / 2 + 7, y + 37, Theme.TEXT);
        }
    }

    private void switchTab(Tab t) {
        if (t == Tab.STUDIO) {
            minecraft.setScreen(new StudioScreen(this));
            return;
        }
        tab = t;
        scrollList = scrollGrid = scrollSettings = 0;
        input = "";
        inputFocused = false;
        searchFocused = false;
        listeningModule = null;
        listeningSetting = null;
        if (t == Tab.COSMETICS) {
            refreshCustom();
        }
    }

    // ================================================================== category windows

    private boolean matches(Module m) {
        String q = search.trim().toLowerCase(Locale.ROOT);
        return q.isEmpty() || m.name.toLowerCase(Locale.ROOT).contains(q)
                || Lang.t(m.description).toLowerCase(Locale.ROOT).contains(q);
    }

    private int moduleHeight(Module m) {
        int h = ROW_H;
        if (EXPANDED.contains(m)) {
            h += settingsHeight(m);
        }
        return h;
    }

    private int settingsHeight(Module m) {
        int h = 30 + 6; // keybind row + padding
        for (Setting<?> s : m.settings) {
            if (s.visible.getAsBoolean()) {
                h += rowHeight(s);
            }
        }
        return h;
    }

    private void drawWindow(GuiGraphics g, Win w, int index) {
        List<Module> list = new ArrayList<>();
        for (Module m : ModuleManager.in(w.category)) {
            if (matches(m)) {
                list.add(m);
            }
        }
        if (!search.isBlank() && list.isEmpty()) {
            return;
        }
        float e = ease(index * 70L);
        int off = (int) ((1f - e) * -26);
        int content = 0;
        for (Module m : list) {
            content += moduleHeight(m);
        }
        int maxBody = Math.max(60, Math.min(380, height - w.y - 24 - HEADER_H));
        boolean open = !w.collapsed || !search.isBlank();
        int bodyH = open ? Math.min(content, maxBody) : 0;
        w.scroll = Math.max(0, Math.min(w.scroll, Math.max(0, content - bodyH)));
        int x = w.x, y = w.y + off, totalH = HEADER_H + (open ? bodyH + 6 : 0);
        glass(g, x, y, WIN_W, totalH, 10);
        gradBar(g, x + 10, y + 1, WIN_W - 20, 2);

        // header: drag to move, click the arrow to collapse
        Identifier ic = tex("textures/gui/" + (w.category == Category.VISUALS ? "cat_visuals" : w.category == Category.HUD ? "cat_hud"
                : w.category == Category.UTILITIES ? "cat_utilities" : "tab_cosmetics") + ".png");
        icon(g, ic, x + 10, y + 8, 14);
        Theme.text(g, Lang.t(w.category.title), x + 30, y + 11, Theme.TEXT);
        String count = Integer.toString(list.size());
        Theme.text(g, count, x + WIN_W - 34 - Theme.width(count), y + 11, Theme.MUTED);
        Theme.text(g, open ? "-" : "+", x + WIN_W - 20, y + 11, Theme.MUTED);
        final Win win = w;
        hit(x, y, WIN_W - 28, HEADER_H, b -> {
            dragWin = win;
            grabX = mouseX - win.x;
            grabY = mouseY - win.y;
        });
        hit(x + WIN_W - 28, y, 28, HEADER_H, b -> win.collapsed = !win.collapsed);

        if (!open) {
            return;
        }
        int top = y + HEADER_H, bottom = top + bodyH;
        g.enableScissor(x, top, x + WIN_W, bottom);
        int yy = top - w.scroll;
        for (Module m : list) {
            drawRow(g, m, x, yy, top, bottom);
            yy += moduleHeight(m);
        }
        g.disableScissor();
        if (content > bodyH) {
            int barH = Math.max(14, bodyH * bodyH / content);
            int barY = top + (int) ((bodyH - barH) * (w.scroll / (double) (content - bodyH)));
            rr(g, x + WIN_W - 4, barY, 2, barH, 1, 0x55FFFFFF);
        }
    }

    private void drawRow(GuiGraphics g, Module m, int x, int y, int top, int bottom) {
        boolean hover = inside(x, y, WIN_W, ROW_H) && mouseY >= top && mouseY < bottom;
        boolean expanded = EXPANDED.contains(m);
        if (hover || expanded) {
            rr(g, x + 4, y + 1, WIN_W - 8, ROW_H - 2, 6, hover ? GLASS_HOVER : GLASS_LIGHT);
        }
        int dot = m.isEnabled() ? accent() : 0xFF3A4360;
        rr(g, x + 11, y + 9, 6, 6, 3, dot);
        Theme.text(g, ellipsize(m.name, WIN_W - 84), x + 24, y + 8, m.isEnabled() ? Theme.TEXT : 0xFF9AA5BD);
        if (m.key >= 0) {
            String k = Util.keyName(m.key);
            Theme.text(g, k, x + WIN_W - 70 - Theme.width(k), y + 8, 0xFF5E6985);
        }
        icon(g, ICON_GEAR, x + WIN_W - 56, y + 7, 10);
        toggle(g, x + WIN_W - 38, y + 6, m.isEnabled());
        hitClipped(x + WIN_W - 60, y, 20, ROW_H, top, bottom, b -> {
            if (!EXPANDED.remove(m)) {
                EXPANDED.add(m);
            }
        }, null);
        hitClipped(x + WIN_W - 40, y, 36, ROW_H, top, bottom, b -> m.toggle(), null);
        hitClipped(x, y, WIN_W - 60, ROW_H, top, bottom, b -> {
            if (b == 1) {
                if (!EXPANDED.remove(m)) {
                    EXPANDED.add(m);
                }
            } else {
                m.toggle();
            }
        }, null);
        if (expanded) {
            drawSettings(g, m, x + 8, y + ROW_H, WIN_W - 16, top, bottom);
        }
    }

    // ------------------------------------------------------------------ settings widgets

    private int rowHeight(Setting<?> s) {
        if (s instanceof Setting.Num) {
            return 34;
        }
        if (s instanceof Setting.Color) {
            return 66;
        }
        return 26;
    }

    /** Keybind row plus all visible settings of a module. */
    private void drawSettings(GuiGraphics g, Module m, int x, int y, int w, int top, int bottom) {
        int yy = y + 2;
        rr(g, x, yy, w, 22, 6, GLASS_LIGHT);
        Theme.text(g, Lang.t("Keybind"), x + 9, yy + 7, Theme.TEXT);
        String key = listeningModule == m ? Lang.t("press a key...") : Util.keyName(m.key);
        Theme.text(g, key, x + w - Theme.width(key) - 9, yy + 7, listeningModule == m ? accent() : Theme.MUTED);
        hitClipped(x, yy, w, 22, top, bottom, b -> {
            if (b == 1) {
                m.key = -1;
            } else {
                listeningModule = m;
                listeningSetting = null;
            }
        }, null);
        yy += 28;
        for (Setting<?> s : m.settings) {
            if (!s.visible.getAsBoolean()) {
                continue;
            }
            int rh = rowHeight(s);
            drawSetting(g, s, x, yy, w, rh, top, bottom);
            yy += rh;
        }
    }

    private void drawSetting(GuiGraphics g, Setting<?> s, int x, int y, int w, int h, int top, int bottom) {
        int accent = accent();
        rr(g, x, y, w, h - 4, 6, GLASS_LIGHT);
        if (s instanceof Setting.Bool b) {
            Theme.text(g, ellipsize(Lang.t(b.name), w - 54), x + 9, y + 7, Theme.TEXT);
            toggle(g, x + w - 34, y + 5, b.get());
            hitClipped(x, y, w, h - 4, top, bottom, btn -> b.value = !b.value, null);
        } else if (s instanceof Setting.Num n) {
            String val = n.step >= 1 ? Integer.toString(n.asInt()) : String.format(Locale.ROOT, "%.2f", n.get());
            Theme.text(g, ellipsize(Lang.t(n.name), w - 60), x + 9, y + 6, Theme.TEXT);
            Theme.text(g, val, x + w - Theme.width(val) - 9, y + 6, Theme.MUTED);
            int bx = x + 9, bw = w - 18, by = y + 21;
            rr(g, bx, by, bw, 4, 2, 0xFF2B3350);
            double frac = (n.get() - n.min) / (n.max - n.min);
            int fill = Math.max(4, (int) (bw * frac));
            for (int i = 0; i < fill; i += 2) {
                g.fill(bx + i, by, Math.min(bx + fill, bx + i + 2), by + 4, Theme.mix(accent, accent2(), i / (float) Math.max(1, bw)));
            }
            rr(g, bx + (int) (bw * frac) - 4, by - 2, 8, 8, 4, 0xFFFFFFFF);
            DoubleConsumer drag = mx -> n.set(n.min + Math.max(0, Math.min(1, (mx - bx) / (double) bw)) * (n.max - n.min));
            hitClipped(bx - 3, y + 14, bw + 6, 16, top, bottom, btn -> drag.accept(mouseX), drag);
        } else if (s instanceof Setting.Mode mode) {
            Theme.text(g, ellipsize(Lang.t(mode.name), w / 2 - 6), x + 9, y + 7, Theme.TEXT);
            String v = ellipsize(Lang.t(mode.get()), w / 2 - 14);
            int vw = Theme.width(v) + 16;
            rr(g, x + w - vw - 5, y + 3, vw, 16, 8, Theme.withAlpha(accent, 0x44));
            Theme.text(g, v, x + w - vw + 3, y + 7, Theme.TEXT);
            hitClipped(x, y, w, h - 4, top, bottom, btn -> mode.cycle(btn == 1 ? -1 : 1), null);
        } else if (s instanceof Setting.Key k) {
            Theme.text(g, ellipsize(Lang.t(k.name), w - 80), x + 9, y + 7, Theme.TEXT);
            String label = listeningSetting == k ? Lang.t("press a key...") : Util.keyName(k.get());
            Theme.text(g, label, x + w - Theme.width(label) - 9, y + 7, listeningSetting == k ? accent : Theme.MUTED);
            hitClipped(x, y, w, h - 4, top, bottom, btn -> {
                if (btn == 1) {
                    k.value = -1;
                } else {
                    listeningSetting = k;
                    listeningModule = null;
                }
            }, null);
        } else if (s instanceof Setting.Color c) {
            drawColor(g, c, x, y, w, top, bottom);
        }
    }

    private void drawColor(GuiGraphics g, Setting.Color c, int x, int y, int w, int top, int bottom) {
        Theme.text(g, Lang.t(c.name), x + 9, y + 6, Theme.TEXT);
        rr(g, x + w - 34, y + 4, 26, 12, 6, c.get() | 0xFF000000);
        float[] hsb = java.awt.Color.RGBtoHSB((c.get() >> 16) & 0xFF, (c.get() >> 8) & 0xFF, c.get() & 0xFF, null);
        int bx = x + 9, bw = w - 18, seg = 24;
        int[] ys = {y + 22, y + 34, y + 46};
        for (int row = 0; row < 3; row++) {
            for (int i = 0; i < seg; i++) {
                float t = i / (float) (seg - 1);
                int col = row == 0 ? Theme.hsb(i / (float) seg, 1f, 1f) : (row == 1 ? Theme.hsb(hsb[0], t, hsb[2]) : Theme.hsb(hsb[0], hsb[1], t));
                g.fill(bx + bw * i / seg, ys[row], bx + bw * (i + 1) / seg, ys[row] + 8, col);
            }
            float pos = row == 0 ? hsb[0] : (row == 1 ? hsb[1] : hsb[2]);
            rr(g, bx + (int) (bw * pos) - 2, ys[row] - 2, 4, 12, 2, 0xFFFFFFFF);
        }
        DoubleConsumer hue = mx -> c.value = Theme.hsb((float) Math.max(0, Math.min(0.999, (mx - bx) / (double) bw)), hsb[1], hsb[2]);
        DoubleConsumer sat = mx -> c.value = Theme.hsb(hsb[0], (float) Math.max(0, Math.min(1, (mx - bx) / (double) bw)), hsb[2]);
        DoubleConsumer val = mx -> c.value = Theme.hsb(hsb[0], hsb[1], (float) Math.max(0, Math.min(1, (mx - bx) / (double) bw)));
        DoubleConsumer[] drags = {hue, sat, val};
        for (int row = 0; row < 3; row++) {
            final DoubleConsumer d = drags[row];
            hitClipped(bx, ys[row] - 2, bw, 12, top, bottom, b -> d.accept(mouseX), d);
        }
    }

    // ================================================================== modal views

    private void drawModal(GuiGraphics g) {
        float e = ease(0);
        mw = Math.min(740, width - 24);
        mh = Math.min(410, height - 74);
        mx0 = (width - mw) / 2;
        my0 = 58 + (int) ((1f - e) * 16);
        glass(g, mx0, my0, mw, mh, 14);
        gradBar(g, mx0 + 14, my0 + 1, mw - 28, 2);
        switch (tab) {
            case COSMETICS -> drawWardrobe(g);
            case CONFIGS -> drawConfigs(g);
            case FRIENDS -> drawFriends(g);
            case MARKERS -> drawMarkers(g);
            case EVENTS -> drawEvents(g);
            default -> {
            }
        }
        Theme.text(g, Lang.t("Right Shift: close  |  Config: ") + ModuleManager.currentConfig, mx0 + 16, my0 + mh - 14, 0xFF5E6985);
    }

    private void modalHeader(GuiGraphics g, String title, String subtitle) {
        bigText(g, Lang.t(title), mx0 + 18, my0 + 14, Theme.TEXT, 1.5f);
        Theme.text(g, subtitle, mx0 + 18, my0 + 36, Theme.MUTED);
    }

    // ------------------------------------------------------------------ wardrobe (cosmetics)

    private static Item eggFor(String animal) {
        return switch (animal) {
            case "Wolf" -> Items.WOLF_SPAWN_EGG;
            case "Fox" -> Items.FOX_SPAWN_EGG;
            case "Rabbit" -> Items.RABBIT_SPAWN_EGG;
            case "Chicken" -> Items.CHICKEN_SPAWN_EGG;
            case "Pig" -> Items.PIG_SPAWN_EGG;
            case "Sheep" -> Items.SHEEP_SPAWN_EGG;
            case "Cow" -> Items.COW_SPAWN_EGG;
            case "Horse" -> Items.HORSE_SPAWN_EGG;
            case "Goat" -> Items.GOAT_SPAWN_EGG;
            case "Llama" -> Items.LLAMA_SPAWN_EGG;
            case "Polar Bear" -> Items.POLAR_BEAR_SPAWN_EGG;
            case "Armadillo" -> Items.ARMADILLO_SPAWN_EGG;
            case "Axolotl" -> Items.AXOLOTL_SPAWN_EGG;
            case "Frog" -> Items.FROG_SPAWN_EGG;
            case "Panda" -> Items.PANDA_SPAWN_EGG;
            case "Turtle" -> Items.TURTLE_SPAWN_EGG;
            case "Bee" -> Items.BEE_SPAWN_EGG;
            case "Allay" -> Items.ALLAY_SPAWN_EGG;
            case "Parrot" -> Items.PARROT_SPAWN_EGG;
            default -> Items.CAT_SPAWN_EGG;
        };
    }

    private static int birdColor(String name) {
        return switch (name) {
            case "Blue" -> 0xFF3A6FE0;
            case "Green" -> 0xFF40B050;
            case "Yellow-blue" -> 0xFFE6C84A;
            case "Gray" -> 0xFF9AA0A8;
            default -> 0xFFE04040;
        };
    }

    private String customKind() {
        return sub == Sub.CAPES ? "capes" : "wings";
    }

    private void refreshCustom() {
        customFiles = sub == Sub.CAPES || sub == Sub.WINGS ? CustomTextures.list(customKind()) : new ArrayList<>();
    }

    private void drawWardrobe(GuiGraphics g) {
        boolean imageSub = sub == Sub.CAPES || sub == Sub.WINGS;
        modalHeader(g, "Cosmetics", Lang.t(imageSub ? "Your own image: open the folder, drop a PNG in, press Refresh."
                : "Only you can see cosmetics."));
        int pad = 18, top = my0 + 58, bottom = my0 + mh - 26;
        int previewW = 190, settingsW = 176;
        int gridX = mx0 + pad + previewW + 14;
        int gridW = mw - pad * 2 - previewW - settingsW - 28;

        // ---- live preview of your own player
        int px0 = mx0 + pad, py0 = top;
        rr(g, px0, py0, previewW, bottom - py0, 12, 0x40000000);
        rr(g, px0 + 1, py0 + 1, previewW - 2, bottom - py0 - 2, 11, 0x14FFFFFF);
        drawPlayerPreview(g, px0, py0, previewW, bottom - py0 - 22);
        Theme.text(g, Lang.t("Drag to rotate"), px0 + 10, bottom - 15, 0xFF6F7A96);
        hitClipped(px0, py0, previewW, bottom - py0 - 22, py0, bottom, b -> {
            previewLastX = mouseX;
            previewSpin = false;
        }, x -> {
            previewYaw += (float) (x - previewLastX) * 1.6f;
            previewLastX = x;
        });
        String reset = Lang.t("Reset view");
        smallButton(g, px0 + previewW - Theme.width(reset) - 24, bottom - 20, Theme.width(reset) + 16, 16, reset, py0, bottom + 4, () -> {
            previewYaw = 160f;
            previewSpin = true;
        });

        // ---- sub tabs + custom image buttons
        int x = gridX;
        for (Sub s : Sub.values()) {
            String label = Lang.t(s.title);
            int w = Theme.width(label) + 22;
            final Sub target = s;
            pill(g, x, top - 2, w, 22, label, s == sub, () -> {
                sub = target;
                scrollGrid = 0;
                scrollSettings = 0;
                refreshCustom();
            });
            x += w + 2;
        }
        if (imageSub) {
            int b2 = Theme.width(Lang.t("Refresh")) + 18, b1 = Theme.width(Lang.t("Open folder")) + 18;
            int bx = gridX + gridW - b1 - b2 - 6;
            button(g, bx, top - 2, b1, 22, Lang.t("Open folder"), () -> CustomTextures.openFolder(customKind()));
            button(g, bx + b1 + 6, top - 2, b2, 22, Lang.t("Refresh"), () -> {
                CustomTextures.refresh();
                refreshCustom();
            });
        }

        Module module = switch (sub) {
            case CAPES -> ModuleManager.get(Cosmetics.Cape.class);
            case WINGS -> ModuleManager.get(Cosmetics.Wings.class);
            case PETS -> ModuleManager.get(Cosmetics.Pet.class);
            case BIRDS -> ModuleManager.get(Cosmetics.ShoulderBird.class);
        };
        Setting.Mode style = (Setting.Mode) module.settings.get(0);
        Setting.Text customFile = module instanceof Cosmetics.Cape c ? c.customFile
                : (module instanceof Cosmetics.Wings w ? w.customFile : null);
        String[] options = switch (sub) {
            case CAPES -> Cosmetics.CAPES;
            case WINGS -> Cosmetics.WINGS;
            case PETS -> Cosmetics.PETS;
            case BIRDS -> Cosmetics.BIRDS;
        };

        // ---- option grid
        int gTop = top + 28, cardW = 90, cardH = 104, gap = 8;
        int cols = Math.max(1, (gridW + gap) / (cardW + gap));
        int count = 1 + options.length + customFiles.size();
        int rows = (count + cols - 1) / cols;
        scrollGrid = Math.max(0, Math.min(scrollGrid, Math.max(0, rows * (cardH + gap) - (bottom - gTop))));
        g.enableScissor(gridX - 2, gTop, gridX + gridW + 2, bottom);
        for (int n = 0; n < count; n++) {
            int x0 = gridX + (n % cols) * (cardW + gap), y0 = gTop + (n / cols) * (cardH + gap) - scrollGrid;
            if (y0 + cardH < gTop || y0 > bottom) {
                continue;
            }
            boolean none = n == 0;
            boolean custom = n > options.length;
            String name = none ? "None" : (custom ? customFiles.get(n - 1 - options.length) : options[n - 1]);
            boolean selected = none ? !module.isEnabled()
                    : module.isEnabled() && (custom ? style.is("Custom") && customFile != null && name.equals(customFile.get())
                    : style.get().equals(name));
            boolean hover = inside(x0, y0, cardW, cardH) && mouseY >= gTop && mouseY < bottom;
            rr(g, x0 - (selected ? 1 : 0), y0 - (selected ? 1 : 0), cardW + (selected ? 2 : 0), cardH + (selected ? 2 : 0), 10,
                    selected ? Theme.withAlpha(accent(), 0xCC) : 0x00000000);
            rr(g, x0, y0, cardW, cardH, 10, hover ? GLASS_HOVER : (selected ? 0xFF17203D : GLASS_LIGHT));
            drawPreview(g, none, custom, name, x0, y0, cardW);
            String label = custom ? ellipsize(name.replaceFirst("\\.[^.]+$", ""), cardW - 10) : Lang.t(name);
            Theme.text(g, label, x0 + (cardW - Theme.width(label)) / 2, y0 + cardH - 15, selected ? Theme.TEXT : Theme.MUTED);
            if (selected && !none) {
                rr(g, x0 + cardW - 19, y0 + 5, 14, 14, 7, accent());
                int[][] tick = {{4, 7}, {5, 8}, {6, 9}, {7, 8}, {8, 7}, {9, 6}, {10, 5}};
                for (int[] t : tick) {
                    g.fill(x0 + cardW - 19 + t[0], y0 + 5 + t[1] - 1, x0 + cardW - 19 + t[0] + 2, y0 + 5 + t[1] + 1, 0xFF0F1527);
                }
            }
            final String chosen = name;
            final boolean isCustom = custom;
            hitClipped(x0, y0, cardW, cardH, gTop, bottom, b -> {
                if (chosen.equals("None") && !isCustom) {
                    module.setEnabled(false);
                } else {
                    if (isCustom) {
                        style.deserialize("Custom");
                        customFile.value = chosen;
                    } else {
                        style.deserialize(chosen);
                    }
                    module.setEnabled(true);
                }
            }, null);
        }
        g.disableScissor();

        // ---- settings of the selected cosmetic
        int sx = mx0 + mw - pad - settingsW;
        rr(g, sx, top - 2, settingsW, bottom - top + 2, 12, 0x30000000);
        Theme.text(g, module.name, sx + 12, top + 6, Theme.TEXT);
        rr(g, sx + 8, top + 22, settingsW - 16, 22, 6, GLASS_LIGHT);
        Theme.text(g, Lang.t("Enabled"), sx + 17, top + 29, Theme.TEXT);
        toggle(g, sx + settingsW - 42, top + 27, module.isEnabled());
        hit(sx + 8, top + 22, settingsW - 16, 22, b -> module.toggle());
        int sTop = top + 50;
        int total = settingsHeight(module);
        scrollSettings = Math.max(0, Math.min(scrollSettings, Math.max(0, total - (bottom - sTop))));
        g.enableScissor(sx, sTop, sx + settingsW, bottom);
        drawSettings(g, module, sx + 8, sTop - scrollSettings, settingsW - 16, sTop, bottom);
        g.disableScissor();
    }

    private void drawPlayerPreview(GuiGraphics g, int x, int y, int w, int h) {
        if (minecraft.player == null) {
            return;
        }
        if (previewSpin) {
            previewYaw = (previewYaw + 0.9f) % 360f;
        }
        try {
            Player player = minecraft.player;
            EntityRenderState state = minecraft.getEntityRenderDispatcher().getRenderer(player).createRenderState(player, 1.0f);
            state.lightCoords = 15728880;
            state.shadowPieces.clear();
            state.outlineColor = 0;
            if (state instanceof LivingEntityRenderState living) {
                living.bodyRot = previewYaw;
                living.yRot = 0f;
                living.xRot = 0f;
                g.submitEntityRenderState(living, h / 2.15f, new Vector3f(0f, living.boundingBoxHeight / 2f + 0.0625f, 0f),
                        new Quaternionf().rotateZ((float) Math.PI), new Quaternionf(), x, y, x + w, y + h);
            }
        } catch (RuntimeException ignored) {
            // the preview is optional: never let it break the menu
        }
    }

    private void drawPreview(GuiGraphics g, boolean none, boolean custom, String name, int x, int y, int w) {
        if (none) {
            rr(g, x + w / 2 - 15, y + 28, 30, 30, 15, 0x33FFFFFF);
            icon(g, ICON_CLOSE, x + w / 2 - 9, y + 34, 18);
            return;
        }
        if (custom) {
            Identifier id = CustomTextures.texture(customKind(), name);
            if (id == null) {
                Theme.text(g, "?", x + w / 2 - 3, y + 38, Theme.MUTED);
            } else if (sub == Sub.CAPES) {
                g.blit(RenderPipelines.GUI_TEXTURED, id, x + w / 2 - 20, y + 10, 16f, 16f, 40, 64, 160, 256,
                        CustomTextures.CANVAS_W, CustomTextures.CANVAS_H);
            } else {
                g.blit(RenderPipelines.GUI_TEXTURED, id, x + w / 2 - 20, y + 8, 384f, 32f, 40, 80, 160, 320,
                        CustomTextures.CANVAS_W, CustomTextures.CANVAS_H);
            }
            return;
        }
        switch (sub) {
            case CAPES -> g.blit(RenderPipelines.GUI_TEXTURED, tex("textures/cape/" + Cosmetics.slug(name) + ".png"),
                    x + w / 2 - 20, y + 10, 4f, 4f, 40, 64, 40, 64, 256, 128);
            case WINGS -> g.blit(RenderPipelines.GUI_TEXTURED, tex("textures/gui/wing_" + Cosmetics.slug(name) + ".png"),
                    x + 5, y + 14, 0f, 0f, 80, 64, 80, 64, 80, 64);
            case PETS, BIRDS -> {
                g.pose().pushMatrix();
                g.pose().translate((float) (x + w / 2 - 24), (float) (y + 20));
                g.pose().scale(3f, 3f);
                g.renderItem(new ItemStack(sub == Sub.BIRDS ? Items.PARROT_SPAWN_EGG : eggFor(name)), 0, 0);
                g.pose().popMatrix();
                if (sub == Sub.BIRDS) {
                    rr(g, x + w / 2 - 6, y + 74, 12, 6, 3, birdColor(name));
                }
            }
        }
    }

    // ------------------------------------------------------------------ lists

    private void inputRow(GuiGraphics g, int x, int y, int w, String placeholder, String buttonLabel, Runnable submit) {
        int bw = Theme.width(Lang.t(buttonLabel)) + 24;
        int fw = w - bw - 8;
        rr(g, x, y, fw, 24, 12, inputFocused ? Theme.withAlpha(accent(), 0x55) : GLASS_LIGHT);
        String shown = input.isEmpty() && !inputFocused ? Lang.t(placeholder)
                : input + (inputFocused && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
        Theme.text(g, ellipsize(shown, fw - 24), x + 12, y + 8, input.isEmpty() && !inputFocused ? Theme.MUTED : Theme.TEXT);
        hit(x, y, fw, 24, b -> inputFocused = true);
        button(g, x + fw + 8, y, bw, 24, Lang.t(buttonLabel), submit);
    }

    private interface RowDrawer {
        void draw(int index, int y);
    }

    private void list(GuiGraphics g, int x, int w, int top, int bottom, int count, int rowH, RowDrawer drawer) {
        int content = count * rowH;
        scrollList = Math.max(0, Math.min(scrollList, Math.max(0, content - (bottom - top))));
        g.enableScissor(x - 2, top, x + w + 2, bottom);
        for (int i = 0; i < count; i++) {
            int y = top + i * rowH - scrollList;
            if (y + rowH >= top && y <= bottom) {
                drawer.draw(i, y);
            }
        }
        g.disableScissor();
    }

    private void drawConfigs(GuiGraphics g) {
        modalHeader(g, "Configs", Lang.t("Save and load your settings."));
        int x = mx0 + 18, w = mw - 36;
        inputRow(g, x, my0 + 58, w, "New config name", "Save", this::saveNew);
        List<String> names = ModuleManager.configNames();
        int top = my0 + 94, bottom = my0 + mh - 26;
        list(g, x, w, top, bottom, names.size(), 32, (i, y) -> {
            String name = names.get(i);
            boolean current = name.equals(ModuleManager.currentConfig);
            rr(g, x, y, w, 28, 10, current ? Theme.withAlpha(accent(), 0x33) : GLASS_LIGHT);
            Theme.text(g, name + (current ? "  " + Lang.t("(active)") : ""), x + 14, y + 10, Theme.TEXT);
            int bx = x + w - 8;
            bx -= 62;
            smallButton(g, bx, y + 6, 58, 16, Lang.t("Delete"), top, bottom, () -> ModuleManager.delete(name));
            bx -= 62;
            smallButton(g, bx, y + 6, 58, 16, Lang.t("Save"), top, bottom, () -> {
                ModuleManager.save(name);
                ModuleManager.currentConfig = name;
                Events.info("Config", Lang.t("Saved") + ": " + name);
            });
            bx -= 62;
            smallButton(g, bx, y + 6, 58, 16, Lang.t("Load"), top, bottom, () -> {
                if (ModuleManager.load(name)) {
                    Events.info("Config", Lang.t("Loaded") + ": " + name);
                }
            });
        });
        if (names.isEmpty()) {
            Theme.text(g, Lang.t("No saved configs yet. Type a name and press Save."), x, top + 6, Theme.MUTED);
        }
    }

    private void saveNew() {
        if (!input.isBlank()) {
            String name = ModuleManager.sanitize(input);
            ModuleManager.save(name);
            ModuleManager.currentConfig = name;
            Events.info("Config", Lang.t("Saved") + ": " + name);
            input = "";
        }
    }

    private void drawEvents(GuiGraphics g) {
        modalHeader(g, "Events", Lang.t("Toggles, alerts and pickups."));
        int x = mx0 + 18, w = mw - 36;
        List<String> log = Events.LOG;
        int top = my0 + 58, bottom = my0 + mh - 26;
        if (log.isEmpty()) {
            Theme.text(g, Lang.t("No events yet. Toggles, alerts and pickups show up here."), x, top + 6, Theme.MUTED);
            return;
        }
        list(g, x, w, top, bottom, log.size(), 18, (i, y) -> {
            if (i % 2 == 0) {
                rr(g, x, y, w, 16, 6, 0x14FFFFFF);
            }
            Theme.text(g, ellipsize(log.get(log.size() - 1 - i), w - 20), x + 10, y + 4, i == 0 ? Theme.TEXT : Theme.MUTED);
        });
    }

    private void drawFriends(GuiGraphics g) {
        modalHeader(g, "Friends", Lang.t("Friends are highlighted green by ArrowNametag."));
        int x = mx0 + 18, w = mw - 36;
        inputRow(g, x, my0 + 58, w, "Player name", "Add", () -> {
            Friends.add(input);
            input = "";
        });
        button(g, x, my0 + 90, Theme.width(Lang.t("Add player I'm looking at")) + 24, 20, Lang.t("Add player I'm looking at"), () -> {
            if (Util.target() instanceof Player p) {
                Friends.add(p.getName().getString());
                Events.info("Friends", Lang.t("Added") + ": " + p.getName().getString());
            }
        });
        List<String> names = new ArrayList<>(Friends.all());
        int top = my0 + 120, bottom = my0 + mh - 26;
        list(g, x, w, top, bottom, names.size(), 32, (i, y) -> {
            String name = names.get(i);
            rr(g, x, y, w, 28, 10, GLASS_LIGHT);
            rr(g, x + 11, y + 9, 10, 10, 5, Theme.GOOD);
            Theme.text(g, name, x + 30, y + 10, Theme.TEXT);
            smallButton(g, x + w - 82, y + 6, 74, 16, Lang.t("Remove"), top, bottom, () -> Friends.remove(name));
        });
    }

    private void drawMarkers(GuiGraphics g) {
        modalHeader(g, "Markers", Lang.t("Enable MarkerOverlay (HUD) to see markers in the world."));
        int x = mx0 + 18, w = mw - 36;
        inputRow(g, x, my0 + 58, w, "Marker name (saved at your position)", "Add here", this::addMarker);
        List<Markers.Marker> list = new ArrayList<>(Markers.LIST);
        int top = my0 + 94, bottom = my0 + mh - 26;
        list(g, x, w, top, bottom, list.size(), 32, (i, y) -> {
            Markers.Marker m = list.get(i);
            rr(g, x, y, w, 28, 10, GLASS_LIGHT);
            Theme.text(g, m.name(), x + 14, y + 10, Theme.TEXT);
            String pos = String.format(Locale.ROOT, "%.0f %.0f %.0f  %s", m.x(), m.y(), m.z(), Lang.t(m.dimension().replace("minecraft:", "")));
            Theme.text(g, ellipsize(pos, w - 230), x + 150, y + 10, Theme.MUTED);
            smallButton(g, x + w - 82, y + 6, 74, 16, Lang.t("Remove"), top, bottom, () -> Markers.remove(m));
        });
    }

    private void addMarker() {
        if (minecraft.player != null && !input.isBlank()) {
            Markers.add(input.trim(), minecraft.player.getX(), minecraft.player.getY(), minecraft.player.getZ(), Util.dimensionName());
            input = "";
        }
    }

    // ================================================================== input

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        inputFocused = false;
        searchFocused = false;
        double mx = event.x(), my = event.y();
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (h.contains(mx, my)) {
                mouseX = (int) mx;
                mouseY = (int) my;
                h.click().accept(event.button());
                if (h.drag() != null) {
                    dragging = h;
                }
                return true;
            }
        }
        listeningModule = null;
        listeningSetting = null;
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (dragWin != null) {
            dragWin.x = Math.max(0, Math.min(width - WIN_W, (int) event.x() - grabX));
            dragWin.y = Math.max(0, Math.min(height - HEADER_H, (int) event.y() - grabY));
            return true;
        }
        if (dragging != null && dragging.drag() != null) {
            dragging.drag().accept(event.x());
            return true;
        }
        return super.mouseDragged(event, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        dragging = null;
        dragWin = null;
        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseScrolled(double x, double y, double horizontal, double vertical) {
        int amount = (int) (-vertical * 24);
        if (tab == Tab.MODULES) {
            for (int i = WINS.size() - 1; i >= 0; i--) {
                Win w = WINS.get(i);
                if (x >= w.x && x < w.x + WIN_W && y >= w.y && y < w.y + HEADER_H + 400) {
                    w.scroll = Math.max(0, w.scroll + amount);
                    return true;
                }
            }
        } else if (tab == Tab.COSMETICS) {
            if (x >= mx0 + mw - 18 - 176) {
                scrollSettings = Math.max(0, scrollSettings + amount);
            } else {
                scrollGrid = Math.max(0, scrollGrid + amount);
            }
        } else {
            scrollList = Math.max(0, scrollList + amount);
        }
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (listeningModule != null || listeningSetting != null) {
            int value = key == GLFW.GLFW_KEY_ESCAPE ? -1 : key;
            if (listeningModule != null) {
                listeningModule.key = value;
            } else {
                listeningSetting.value = value;
            }
            listeningModule = null;
            listeningSetting = null;
            return true;
        }
        if (searchFocused) {
            if (key == GLFW.GLFW_KEY_BACKSPACE && !search.isEmpty()) {
                search = search.substring(0, search.length() - 1);
            } else if (key == GLFW.GLFW_KEY_ESCAPE || key == 257) {
                searchFocused = false;
            }
            return true;
        }
        if (inputFocused) {
            if (key == GLFW.GLFW_KEY_BACKSPACE && !input.isEmpty()) {
                input = input.substring(0, input.length() - 1);
            } else if (key == GLFW.GLFW_KEY_ESCAPE) {
                inputFocused = false;
            } else if (key == 257 || key == 335) {
                submitInput();
            }
            return true;
        }
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            onClose();
            return true;
        }
        return super.keyPressed(event);
    }

    private void submitInput() {
        switch (tab) {
            case CONFIGS -> saveNew();
            case FRIENDS -> {
                Friends.add(input);
                input = "";
            }
            case MARKERS -> addMarker();
            default -> {
            }
        }
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        if (event.codepoint() < 32 || event.codepoint() == 127) {
            return super.charTyped(event);
        }
        if (searchFocused && search.length() < 24) {
            search += event.codepointAsString();
            return true;
        }
        if (inputFocused && input.length() < 32) {
            input += event.codepointAsString();
            return true;
        }
        return super.charTyped(event);
    }
}
