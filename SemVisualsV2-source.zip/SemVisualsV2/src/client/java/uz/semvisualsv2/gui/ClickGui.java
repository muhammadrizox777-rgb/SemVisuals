package uz.semvisualsv2.gui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.lwjgl.glfw.GLFW;
import uz.semvisualsv2.core.Category;
import uz.semvisualsv2.core.Events;
import uz.semvisualsv2.core.Friends;
import uz.semvisualsv2.core.Lang;
import uz.semvisualsv2.core.Markers;
import uz.semvisualsv2.core.Module;
import uz.semvisualsv2.core.ModuleManager;
import uz.semvisualsv2.core.Setting;
import uz.semvisualsv2.core.Theme;
import uz.semvisualsv2.core.Util;
import uz.semvisualsv2.module.Cosmetics;
import uz.semvisualsv2.module.CustomTextures;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.DoubleConsumer;
import java.util.function.IntConsumer;

/**
 * The V2 menu (Right Shift): an icon rail on the left, a card grid for modules, a settings drawer that slides in
 * from the right and a Cosmetics tab with previews.
 */
public final class ClickGui extends Screen {
    private enum Tab {
        MODULES("Modules", "tab_modules"), COSMETICS("Cosmetics", "tab_cosmetics"), CONFIGS("Configs", "tab_configs"),
        EVENTS("Events", "tab_events"), FRIENDS("Friends", "tab_friends"), MARKERS("Markers", "tab_markers");

        final String title;
        final Identifier icon;

        Tab(String title, String icon) {
            this.title = title;
            this.icon = tex("textures/gui/" + icon + ".png");
        }
    }

    private enum Sub {
        CAPES("Capes"), WINGS("Wings"), PETS("Pets"), BIRDS("Birds");

        final String title;

        Sub(String title) {
            this.title = title;
        }
    }

    private record Hit(int x, int y, int w, int h, int clipTop, int clipBottom, IntConsumer click, DoubleConsumer drag) {
        boolean contains(double mx, double my) {
            return mx >= x && mx < x + w && my >= Math.max(y, clipTop) && my < Math.min(y + h, clipBottom);
        }
    }

    private static Identifier tex(String path) {
        return Identifier.fromNamespaceAndPath(Cosmetics.NAMESPACE, path);
    }

    private static final Identifier LOGO = tex("icon.png");
    private static final Identifier ICON_SEARCH = tex("textures/gui/tab_search.png");
    private static final Identifier ICON_EDITOR = tex("textures/gui/tab_editor.png");
    private static final Identifier ICON_CLOSE = tex("textures/gui/tab_close.png");
    private static final Identifier ICON_GEAR = tex("textures/gui/cat_utilities.png");

    private static Tab rememberedTab = Tab.MODULES;
    private static Category rememberedCategory = Category.VISUALS;
    private static Module rememberedModule;
    private static Sub rememberedSub = Sub.CAPES;

    private final List<Hit> hits = new ArrayList<>();
    private final long openedAt = System.currentTimeMillis();
    private Hit dragging;
    private Tab tab = rememberedTab;
    private Category category = rememberedCategory;
    private Sub sub = rememberedSub;
    private Module drawerModule = rememberedModule;
    private float drawerAnim;
    private int scrollGrid, scrollDrawer, scrollList, scrollCosmetics;
    private int mouseX, mouseY;
    private int px, py, pw, ph;
    private Module listeningModule;
    private Setting.Key listeningSetting;
    private String input = "";
    private boolean inputFocused;
    private String search = "";
    private boolean searchFocused;

    public ClickGui() {
        super(Component.literal("Sem Visuals V2"));
        refreshCustom();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        rememberedTab = tab;
        rememberedCategory = category;
        rememberedModule = drawerModule;
        rememberedSub = sub;
        ModuleManager.save(ModuleManager.currentConfig);
        super.onClose();
    }

    private float ease() {
        float t = Math.min(1f, (System.currentTimeMillis() - openedAt) / 240f);
        return 1f - (1f - t) * (1f - t) * (1f - t);
    }

    private int animOffset() {
        return (int) ((1f - ease()) * 18f);
    }

    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float delta) {
        g.fill(0, 0, width, height, Theme.withAlpha(0x05080F, (int) (0x88 * ease())));
    }

    // ================================================================== drawing helpers

    private void rr(GuiGraphics g, int x, int y, int w, int h, int r, int color) {
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) {
            g.fill(x, y, x + w, y + h, color);
            return;
        }
        g.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
            g.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            g.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, color);
        }
    }

    private void outline(GuiGraphics g, int x, int y, int w, int h, int r, int border, int fill) {
        rr(g, x, y, w, h, r, border);
        rr(g, x + 1, y + 1, w - 2, h - 2, Math.max(0, r - 1), fill);
    }

    private boolean inside(int x, int y, int w, int h) {
        return mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
    }

    private void hit(int x, int y, int w, int h, IntConsumer click) {
        hits.add(new Hit(x, y, w, h, Integer.MIN_VALUE, Integer.MAX_VALUE, click, null));
    }

    private void hitClipped(int x, int y, int w, int h, int top, int bottom, IntConsumer click, DoubleConsumer drag) {
        hits.add(new Hit(x, y, w, h, top, bottom, click, drag));
    }

    private void icon(GuiGraphics g, Identifier id, int x, int y, int size) {
        g.blit(RenderPipelines.GUI_TEXTURED, id, x, y, 0f, 0f, size, size, 64, 64, 64, 64);
    }

    private void toggle(GuiGraphics g, int x, int y, boolean on) {
        rr(g, x, y, 26, 14, 7, on ? Theme.accent() : 0xFF2A3350);
        rr(g, on ? x + 14 : x + 2, y + 2, 10, 10, 5, 0xFFFFFFFF);
    }

    private String ellipsize(String s, int maxWidth) {
        if (Theme.width(s) <= maxWidth) {
            return s;
        }
        while (s.length() > 1 && Theme.width(s + "...") > maxWidth) {
            s = s.substring(0, s.length() - 1);
        }
        return s + "...";
    }

    private void bigText(GuiGraphics g, String s, int x, int y, int color) {
        g.pose().pushMatrix();
        g.pose().translate((float) x, (float) y);
        g.pose().scale(1.5f, 1.5f);
        Theme.text(g, s, 0, 0, color);
        g.pose().popMatrix();
    }

    private void chip(GuiGraphics g, int x, int y, int w, String label, Identifier ic, boolean active, Runnable action) {
        boolean hover = inside(x, y, w, 22);
        int accent = Theme.accent();
        if (active) {
            outline(g, x, y, w, 22, 6, Theme.withAlpha(accent, 0xCC), Theme.withAlpha(0x1A2240, 0xFF));
        } else {
            rr(g, x, y, w, 22, 6, hover ? 0xFF1B2440 : 0xFF141B30);
        }
        int tx = x + 10;
        if (ic != null) {
            icon(g, ic, x + 8, y + 5, 12);
            tx = x + 25;
        }
        Theme.text(g, label, tx, y + 7, active ? Theme.TEXT : Theme.MUTED);
        hit(x, y, w, 22, b -> action.run());
    }

    private void button(GuiGraphics g, int x, int y, int w, int h, String label, Runnable action) {
        boolean hover = inside(x, y, w, h);
        rr(g, x, y, w, h, 5, hover ? 0xFF28345A : 0xFF1B2440);
        Theme.text(g, label, x + (w - Theme.width(label)) / 2, y + (h - 8) / 2, Theme.TEXT);
        hit(x, y, w, h, b -> action.run());
    }

    private void smallButton(GuiGraphics g, int x, int y, int w, int h, String label, int top, int bottom, Runnable action) {
        boolean hover = inside(x, y, w, h) && mouseY >= top && mouseY < bottom;
        rr(g, x, y, w, h, 4, hover ? 0xFF2D3A63 : 0xFF222B48);
        Theme.text(g, label, x + (w - Theme.width(label)) / 2, y + (h - 8) / 2, Theme.TEXT);
        hitClipped(x, y, w, h, top, bottom, b -> action.run(), null);
    }

    // ================================================================== frame

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        int off = animOffset();
        mouseX = mx;
        mouseY = my - off;
        hits.clear();
        pw = Math.min(700, width - 12);
        ph = Math.min(420, height - 12);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        int accent = Theme.accent();

        g.pose().pushMatrix();
        g.pose().translate(0f, (float) off);

        rr(g, px - 1, py - 1, pw + 2, ph + 2, 11, Theme.withAlpha(accent, 0x66));
        rr(g, px, py, pw, ph, 10, 0xFF0F1527);
        g.fillGradient(px + 6, py + 4, px + pw - 6, py + 60, Theme.withAlpha(accent, 0x22), 0x000F1527);

        drawRail(g);
        int cx = px + 72, cw = pw - 72 - 14;
        switch (tab) {
            case MODULES -> drawModules(g, cx, cw);
            case COSMETICS -> drawCosmetics(g, cx, cw);
            case CONFIGS -> drawConfigs(g, cx, cw);
            case EVENTS -> drawEvents(g, cx, cw);
            case FRIENDS -> drawFriends(g, cx, cw);
            case MARKERS -> drawMarkers(g, cx, cw);
        }
        Theme.text(g, Lang.t("Right Shift: close  |  Config: ") + ModuleManager.currentConfig,
                px + 72, py + ph - 12, 0xFF55607A);
        g.pose().popMatrix();
    }

    private void drawRail(GuiGraphics g) {
        int accent = Theme.accent();
        rr(g, px + 6, py + 6, 54, ph - 12, 8, 0xFF0B1020);
        g.blit(RenderPipelines.GUI_TEXTURED, LOGO, px + 12, py + 12, 0f, 0f, 42, 42, 128, 128, 128, 128);
        int y = py + 66;
        for (Tab t : Tab.values()) {
            boolean active = t == tab;
            boolean hover = inside(px + 10, y, 46, 40);
            if (active) {
                rr(g, px + 10, y, 46, 40, 8, Theme.withAlpha(accent, 0x30));
                rr(g, px + 6, y + 10, 3, 20, 1, accent);
            } else if (hover) {
                rr(g, px + 10, y, 46, 40, 8, 0xFF151C32);
            }
            icon(g, t.icon, px + 21, y + 9, 24);
            final Tab target = t;
            hit(px + 10, y, 46, 40, b -> switchTab(target));
            if (hover) {
                String label = Lang.t(t.title);
                int w = Theme.width(label) + 14;
                rr(g, px + 64, y + 10, w, 20, 5, 0xFF1D2745);
                Theme.text(g, label, px + 71, y + 16, Theme.TEXT);
            }
            y += 46;
        }
        iconButton(g, ICON_EDITOR, px + 10, py + ph - 100, "HUD Editor", () -> minecraft.setScreen(new HudEditor(this)));
        iconButton(g, ICON_CLOSE, px + 10, py + ph - 54, "Close", this::onClose);
    }

    private void iconButton(GuiGraphics g, Identifier ic, int x, int y, String tip, Runnable action) {
        boolean hover = inside(x, y, 46, 40);
        rr(g, x, y, 46, 40, 8, hover ? 0xFF151C32 : 0xFF0B1020);
        icon(g, ic, x + 11, y + 9, 24);
        hit(x, y, 46, 40, b -> action.run());
        if (hover) {
            String label = Lang.t(tip);
            rr(g, x + 54, y + 10, Theme.width(label) + 14, 20, 5, 0xFF1D2745);
            Theme.text(g, label, x + 61, y + 16, Theme.TEXT);
        }
    }

    private void switchTab(Tab t) {
        tab = t;
        scrollGrid = scrollList = scrollCosmetics = 0;
        input = "";
        inputFocused = false;
        searchFocused = false;
        listeningModule = null;
        listeningSetting = null;
        if (t == Tab.COSMETICS) {
            refreshCustom();
        }
        if (t != Tab.MODULES && t != Tab.COSMETICS) {
            drawerModule = null;
        }
    }

    private void header(GuiGraphics g, int cx, int cw, String title, String subtitle) {
        bigText(g, Lang.t(title), cx, py + 16, Theme.TEXT);
        Theme.text(g, subtitle, cx, py + 36, Theme.MUTED);
    }

    // ================================================================== modules

    private List<Module> visibleModules() {
        List<Module> list = new ArrayList<>();
        String q = search.trim().toLowerCase(Locale.ROOT);
        for (Module m : ModuleManager.MODULES) {
            if (q.isEmpty() ? m.category == category : (m.name.toLowerCase(Locale.ROOT).contains(q)
                    || Lang.t(m.description).toLowerCase(Locale.ROOT).contains(q))) {
                if (m.category != Category.COSMETICS) {
                    list.add(m);
                }
            }
        }
        return list;
    }

    private void drawModules(GuiGraphics g, int cx, int cw) {
        header(g, cx, cw, "Modules", Lang.f("%d modules", ModuleManager.MODULES.size()));
        // search box
        int sw = 180, sx = cx + cw - sw;
        outline(g, sx, py + 16, sw, 22, 6, searchFocused ? Theme.accent() : 0xFF222B48, 0xFF141B30);
        icon(g, ICON_SEARCH, sx + 7, py + 21, 12);
        boolean empty = search.isEmpty();
        String shown = empty && !searchFocused ? Lang.t("Search...") : search + (searchFocused && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
        Theme.text(g, ellipsize(shown, sw - 34), sx + 24, py + 23, empty && !searchFocused ? Theme.MUTED : Theme.TEXT);
        hit(sx, py + 16, sw, 22, b -> searchFocused = true);

        // category chips
        int y = py + 50;
        int x = cx;
        Identifier[] icons = {tex("textures/gui/cat_visuals.png"), tex("textures/gui/cat_hud.png"), tex("textures/gui/cat_utilities.png")};
        int i = 0;
        for (Category c : new Category[]{Category.VISUALS, Category.HUD, Category.UTILITIES}) {
            String label = Lang.t(c.title) + "  " + ModuleManager.in(c).size();
            int w = Theme.width(label) + 36;
            final Category target = c;
            chip(g, x, y, w, label, icons[i++], search.isEmpty() && c == category, () -> {
                category = target;
                search = "";
                scrollGrid = 0;
            });
            x += w + 6;
        }

        // card grid
        int top = py + 82, bottom = py + ph - 22;
        List<Module> list = visibleModules();
        int cols = 3, gap = 8;
        int cardW = (cw - gap * (cols - 1)) / cols, cardH = 54;
        int rows = (list.size() + cols - 1) / cols;
        int content = rows * (cardH + gap);
        scrollGrid = Math.max(0, Math.min(scrollGrid, Math.max(0, content - (bottom - top))));
        g.enableScissor(cx - 2, top, cx + cw + 2, bottom);
        for (int n = 0; n < list.size(); n++) {
            Module m = list.get(n);
            int x0 = cx + (n % cols) * (cardW + gap), y0 = top + (n / cols) * (cardH + gap) - scrollGrid;
            if (y0 + cardH < top || y0 > bottom) {
                continue;
            }
            drawCard(g, m, x0, y0, cardW, cardH, top, bottom);
        }
        g.disableScissor();
        if (list.isEmpty()) {
            Theme.text(g, Lang.t("Nothing found."), cx, top + 6, Theme.MUTED);
        }

        // settings drawer
        float target = drawerModule != null ? 1f : 0f;
        drawerAnim += (target - drawerAnim) * 0.3f;
        if (Math.abs(target - drawerAnim) < 0.01f) {
            drawerAnim = target;
        }
        if (drawerAnim > 0.02f && drawerModule != null) {
            int dw = 250;
            int dx = px + pw - 14 - dw + (int) ((1f - drawerAnim) * (dw + 20));
            drawDrawer(g, drawerModule, dx, py + 48, dw, ph - 48 - 22, true);
        }
    }

    private void drawCard(GuiGraphics g, Module m, int x, int y, int w, int h, int top, int bottom) {
        boolean hover = inside(x, y, w, h) && mouseY >= top && mouseY < bottom;
        boolean sel = m == drawerModule;
        int accent = Theme.accent();
        if (m.isEnabled()) {
            outline(g, x, y, w, h, 8, Theme.withAlpha(accent, 0xAA), hover ? 0xFF1B2440 : 0xFF161E37);
            rr(g, x + 1, y + 10, 3, h - 20, 1, accent);
        } else if (sel) {
            outline(g, x, y, w, h, 8, 0xFF39466F, 0xFF161E37);
        } else {
            rr(g, x, y, w, h, 8, hover ? 0xFF1B2440 : 0xFF141B30);
        }
        Theme.text(g, ellipsize(m.name, w - 78), x + 12, y + 9, m.isEnabled() ? Theme.TEXT : 0xFFB4BED3);
        Theme.text(g, ellipsize(Lang.t(m.description), w - 24), x + 12, y + 24, Theme.MUTED);
        if (m.key >= 0) {
            String k = Util.keyName(m.key);
            int kw = Theme.width(k) + 10;
            rr(g, x + 12, y + h - 17, kw, 12, 4, 0xFF222B48);
            Theme.text(g, k, x + 17, y + h - 15, Theme.MUTED);
        }
        toggle(g, x + w - 38, y + 7, m.isEnabled());
        icon(g, ICON_GEAR, x + w - 56, y + 9, 10);
        hitClipped(x + w - 40, y, 40, 24, top, bottom, b -> m.toggle(), null);
        hitClipped(x, y, w, h, top, bottom, b -> {
            if (b == 1) {
                m.toggle();
            } else {
                drawerModule = m;
                scrollDrawer = 0;
            }
        }, null);
    }

    // ------------------------------------------------------------------ settings drawer

    private void drawDrawer(GuiGraphics g, Module m, int x, int y, int w, int h, boolean closable) {
        int accent = Theme.accent();
        rr(g, x - 1, y - 1, w + 2, h + 2, 9, Theme.withAlpha(accent, 0x55));
        rr(g, x, y, w, h, 8, 0xFF0D1325);
        Theme.text(g, m.name, x + 12, y + 11, Theme.TEXT);
        if (closable) {
            icon(g, ICON_CLOSE, x + w - 26, y + 8, 14);
            hit(x + w - 30, y + 4, 24, 22, b -> drawerModule = null);
        }
        int ty = y + 28;
        for (String line : wrap(Lang.t(m.description), w - 24)) {
            Theme.text(g, line, x + 12, ty, Theme.MUTED);
            ty += 10;
        }
        int areaTop = ty + 6, bottom = y + h - 6;
        g.fill(x + 10, areaTop - 3, x + w - 10, areaTop - 2, 0xFF1D2745);

        int total = 56;
        for (Setting<?> s : m.settings) {
            if (s.visible.getAsBoolean()) {
                total += rowHeight(s);
            }
        }
        scrollDrawer = Math.max(0, Math.min(scrollDrawer, Math.max(0, total - (bottom - areaTop))));
        g.enableScissor(x, areaTop, x + w, bottom);
        int yy = areaTop - scrollDrawer;
        int rx = x + 10, rw = w - 20;

        rr(g, rx, yy, rw, 22, 6, 0xFF141B30);
        Theme.text(g, Lang.t("Enabled"), rx + 9, yy + 7, Theme.TEXT);
        toggle(g, rx + rw - 36, yy + 4, m.isEnabled());
        hitClipped(rx, yy, rw, 22, areaTop, bottom, b -> m.toggle(), null);
        yy += 26;

        rr(g, rx, yy, rw, 22, 6, 0xFF141B30);
        Theme.text(g, Lang.t("Keybind"), rx + 9, yy + 7, Theme.TEXT);
        String key = listeningModule == m ? Lang.t("press a key...") : Util.keyName(m.key);
        Theme.text(g, key, rx + rw - Theme.width(key) - 9, yy + 7, listeningModule == m ? accent : Theme.MUTED);
        hitClipped(rx, yy, rw, 22, areaTop, bottom, b -> {
            if (b == 1) {
                m.key = -1;
            } else {
                listeningModule = m;
                listeningSetting = null;
            }
        }, null);
        yy += 26;

        for (Setting<?> s : m.settings) {
            if (!s.visible.getAsBoolean()) {
                continue;
            }
            int rh = rowHeight(s);
            drawSetting(g, s, rx, yy, rw, rh, areaTop, bottom);
            yy += rh;
        }
        g.disableScissor();
    }

    private int rowHeight(Setting<?> s) {
        if (s instanceof Setting.Num) {
            return 34;
        }
        if (s instanceof Setting.Color) {
            return 66;
        }
        return 26;
    }

    private void drawSetting(GuiGraphics g, Setting<?> s, int x, int y, int w, int h, int top, int bottom) {
        int accent = Theme.accent();
        rr(g, x, y, w, h - 4, 6, 0xFF141B30);
        if (s instanceof Setting.Bool b) {
            Theme.text(g, ellipsize(Lang.t(b.name), w - 54), x + 9, y + 7, Theme.TEXT);
            toggle(g, x + w - 36, y + 4, b.get());
            hitClipped(x, y, w, h - 4, top, bottom, btn -> b.value = !b.value, null);
        } else if (s instanceof Setting.Num n) {
            String val = n.step >= 1 ? Integer.toString(n.asInt()) : String.format(Locale.ROOT, "%.2f", n.get());
            Theme.text(g, ellipsize(Lang.t(n.name), w - 60), x + 9, y + 6, Theme.TEXT);
            Theme.text(g, val, x + w - Theme.width(val) - 9, y + 6, Theme.MUTED);
            int bx = x + 9, bw = w - 18, by = y + 21;
            rr(g, bx, by, bw, 5, 2, 0xFF2A3350);
            double frac = (n.get() - n.min) / (n.max - n.min);
            rr(g, bx, by, Math.max(4, (int) (bw * frac)), 5, 2, accent);
            rr(g, bx + (int) (bw * frac) - 4, by - 2, 9, 9, 4, 0xFFFFFFFF);
            DoubleConsumer drag = mx -> n.set(n.min + Math.max(0, Math.min(1, (mx - bx) / (double) bw)) * (n.max - n.min));
            hitClipped(bx - 3, y + 14, bw + 6, 16, top, bottom, btn -> drag.accept(mouseX), drag);
        } else if (s instanceof Setting.Mode mode) {
            Theme.text(g, ellipsize(Lang.t(mode.name), w / 2 - 6), x + 9, y + 7, Theme.TEXT);
            String v = Lang.t(mode.get());
            int vw = Theme.width(v) + 16;
            rr(g, x + w - vw - 6, y + 3, vw, 16, 5, Theme.withAlpha(accent, 0x30));
            Theme.text(g, v, x + w - vw + 2, y + 7, accent);
            hitClipped(x, y, w, h - 4, top, bottom, btn -> mode.cycle(btn == 1 ? -1 : 1), null);
        } else if (s instanceof Setting.Key k) {
            Theme.text(g, ellipsize(Lang.t(k.name), w - 80), x + 9, y + 7, Theme.TEXT);
            String label = listeningSetting == k ? Lang.t("press a key...") : Util.keyName(k.get());
            Theme.text(g, label, x + w - Theme.width(label) - 9, y + 7, listeningSetting == k ? accent : Theme.MUTED);
            hitClipped(x, y, w, h - 4, top, bottom, btn -> {
                if (btn == 1) {
                    k.value = -1;
                } else {
                    listeningSetting = k;
                    listeningModule = null;
                }
            }, null);
        } else if (s instanceof Setting.Color c) {
            drawColor(g, c, x, y, w, top, bottom);
        }
    }

    private void drawColor(GuiGraphics g, Setting.Color c, int x, int y, int w, int top, int bottom) {
        Theme.text(g, Lang.t(c.name), x + 9, y + 6, Theme.TEXT);
        rr(g, x + w - 34, y + 4, 26, 12, 5, c.get() | 0xFF000000);
        float[] hsb = java.awt.Color.RGBtoHSB((c.get() >> 16) & 0xFF, (c.get() >> 8) & 0xFF, c.get() & 0xFF, null);
        int bx = x + 9, bw = w - 18, seg = 24;
        int[] ys = {y + 22, y + 34, y + 46};
        for (int row = 0; row < 3; row++) {
            for (int i = 0; i < seg; i++) {
                float t = i / (float) (seg - 1);
                int col = row == 0 ? Theme.hsb(i / (float) seg, 1f, 1f) : (row == 1 ? Theme.hsb(hsb[0], t, hsb[2]) : Theme.hsb(hsb[0], hsb[1], t));
                g.fill(bx + bw * i / seg, ys[row], bx + bw * (i + 1) / seg, ys[row] + 8, col);
            }
            float pos = row == 0 ? hsb[0] : (row == 1 ? hsb[1] : hsb[2]);
            rr(g, bx + (int) (bw * pos) - 2, ys[row] - 2, 4, 12, 2, 0xFFFFFFFF);
        }
        DoubleConsumer hue = mx -> c.value = Theme.hsb((float) Math.max(0, Math.min(0.999, (mx - bx) / (double) bw)), hsb[1], hsb[2]);
        DoubleConsumer sat = mx -> c.value = Theme.hsb(hsb[0], (float) Math.max(0, Math.min(1, (mx - bx) / (double) bw)), hsb[2]);
        DoubleConsumer val = mx -> c.value = Theme.hsb(hsb[0], hsb[1], (float) Math.max(0, Math.min(1, (mx - bx) / (double) bw)));
        DoubleConsumer[] drags = {hue, sat, val};
        for (int row = 0; row < 3; row++) {
            final DoubleConsumer d = drags[row];
            hitClipped(bx, ys[row] - 2, bw, 12, top, bottom, b -> d.accept(mouseX), d);
        }
    }

    private List<String> wrap(String text, int width) {
        List<String> lines = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String word : text.split(" ")) {
            if (Theme.width(line + word) > width && line.length() > 0) {
                lines.add(line.toString().trim());
                line.setLength(0);
            }
            line.append(word).append(' ');
        }
        if (line.length() > 0) {
            lines.add(line.toString().trim());
        }
        return lines;
    }

    // ================================================================== cosmetics

    private static Item eggFor(String animal) {
        return switch (animal) {
            case "Wolf" -> Items.WOLF_SPAWN_EGG;
            case "Fox" -> Items.FOX_SPAWN_EGG;
            case "Rabbit" -> Items.RABBIT_SPAWN_EGG;
            case "Chicken" -> Items.CHICKEN_SPAWN_EGG;
            case "Pig" -> Items.PIG_SPAWN_EGG;
            case "Sheep" -> Items.SHEEP_SPAWN_EGG;
            case "Cow" -> Items.COW_SPAWN_EGG;
            case "Horse" -> Items.HORSE_SPAWN_EGG;
            case "Goat" -> Items.GOAT_SPAWN_EGG;
            case "Llama" -> Items.LLAMA_SPAWN_EGG;
            case "Polar Bear" -> Items.POLAR_BEAR_SPAWN_EGG;
            case "Armadillo" -> Items.ARMADILLO_SPAWN_EGG;
            case "Axolotl" -> Items.AXOLOTL_SPAWN_EGG;
            case "Frog" -> Items.FROG_SPAWN_EGG;
            case "Panda" -> Items.PANDA_SPAWN_EGG;
            case "Turtle" -> Items.TURTLE_SPAWN_EGG;
            case "Bee" -> Items.BEE_SPAWN_EGG;
            case "Allay" -> Items.ALLAY_SPAWN_EGG;
            case "Parrot" -> Items.PARROT_SPAWN_EGG;
            default -> Items.CAT_SPAWN_EGG;
        };
    }

    private static int birdColor(String name) {
        return switch (name) {
            case "Blue" -> 0xFF3A6FE0;
            case "Green" -> 0xFF40B050;
            case "Yellow-blue" -> 0xFFE6C84A;
            case "Gray" -> 0xFF9AA0A8;
            default -> 0xFFE04040;
        };
    }

    private List<String> customFiles = new ArrayList<>();

    private String customKind() {
        return sub == Sub.CAPES ? "capes" : "wings";
    }

    private void refreshCustom() {
        customFiles = sub == Sub.CAPES || sub == Sub.WINGS ? CustomTextures.list(customKind()) : new ArrayList<>();
    }

    private void drawCosmetics(GuiGraphics g, int cx, int cw) {
        boolean imageSub = sub == Sub.CAPES || sub == Sub.WINGS;
        header(g, cx, cw, "Cosmetics", Lang.t(imageSub ? "Your own image: open the folder, drop a PNG in, press Refresh."
                : "Only you can see cosmetics."));
        int dw = 220, gridW = cw - dw - 10;
        int x = cx, y = py + 50;
        for (Sub s : Sub.values()) {
            String label = Lang.t(s.title);
            int w = Theme.width(label) + 24;
            final Sub target = s;
            chip(g, x, y, w, label, null, s == sub, () -> {
                sub = target;
                scrollCosmetics = 0;
                scrollDrawer = 0;
                refreshCustom();
            });
            x += w + 6;
        }
        if (imageSub) {
            int bw2 = Theme.width(Lang.t("Refresh")) + 20, bw1 = Theme.width(Lang.t("Open folder")) + 20;
            int bx = cx + gridW - bw1 - bw2 - 6;
            button(g, bx, y, bw1, 22, Lang.t("Open folder"), () -> CustomTextures.openFolder(customKind()));
            button(g, bx + bw1 + 6, y, bw2, 22, Lang.t("Refresh"), () -> {
                CustomTextures.refresh();
                refreshCustom();
            });
        }
        Module module = switch (sub) {
            case CAPES -> ModuleManager.get(Cosmetics.Cape.class);
            case WINGS -> ModuleManager.get(Cosmetics.Wings.class);
            case PETS -> ModuleManager.get(Cosmetics.Pet.class);
            case BIRDS -> ModuleManager.get(Cosmetics.ShoulderBird.class);
        };
        Setting.Mode style = (Setting.Mode) module.settings.get(0);
        Setting.Text customFile = module instanceof Cosmetics.Cape c ? c.customFile
                : (module instanceof Cosmetics.Wings w ? w.customFile : null);
        String[] options = switch (sub) {
            case CAPES -> Cosmetics.CAPES;
            case WINGS -> Cosmetics.WINGS;
            case PETS -> Cosmetics.PETS;
            case BIRDS -> Cosmetics.BIRDS;
        };

        int top = py + 82, bottom = py + ph - 22;
        int cardW = 96, cardH = 112, gap = 8;
        int cols = Math.max(1, (gridW + gap) / (cardW + gap));
        int count = 1 + options.length + customFiles.size();
        int rows = (count + cols - 1) / cols;
        scrollCosmetics = Math.max(0, Math.min(scrollCosmetics, Math.max(0, rows * (cardH + gap) - (bottom - top))));
        g.enableScissor(cx - 2, top, cx + gridW + 2, bottom);
        for (int n = 0; n < count; n++) {
            int x0 = cx + (n % cols) * (cardW + gap), y0 = top + (n / cols) * (cardH + gap) - scrollCosmetics;
            if (y0 + cardH < top || y0 > bottom) {
                continue;
            }
            boolean none = n == 0;
            boolean custom = n > options.length;
            String name = none ? "None" : (custom ? customFiles.get(n - 1 - options.length) : options[n - 1]);
            boolean selected = none ? !module.isEnabled()
                    : module.isEnabled() && (custom ? style.is("Custom") && customFile != null && name.equals(customFile.get())
                    : style.get().equals(name));
            boolean hover = inside(x0, y0, cardW, cardH) && mouseY >= top && mouseY < bottom;
            if (selected) {
                outline(g, x0, y0, cardW, cardH, 8, Theme.accent(), 0xFF181F3A);
            } else {
                rr(g, x0, y0, cardW, cardH, 8, hover ? 0xFF1B2440 : 0xFF141B30);
            }
            drawPreview(g, none, custom, name, x0, y0, cardW);
            String label = custom ? ellipsize(name.replaceFirst("\\.[^.]+$", ""), cardW - 10) : Lang.t(name);
            Theme.text(g, label, x0 + (cardW - Theme.width(label)) / 2, y0 + cardH - 16, selected ? Theme.TEXT : Theme.MUTED);
            if (selected && !none) {
                rr(g, x0 + cardW - 20, y0 + 6, 14, 14, 7, Theme.accent());
                Theme.text(g, "v", x0 + cardW - 16, y0 + 9, 0xFF0F1527);
            }
            final String chosen = name;
            final boolean isCustom = custom;
            hitClipped(x0, y0, cardW, cardH, top, bottom, b -> {
                if (chosen.equals("None") && !isCustom) {
                    module.setEnabled(false);
                } else {
                    if (isCustom) {
                        style.deserialize("Custom");
                        customFile.value = chosen;
                    } else {
                        style.deserialize(chosen);
                    }
                    module.setEnabled(true);
                }
            }, null);
        }
        g.disableScissor();
        drawerModule = null;
        drawDrawer(g, module, cx + cw - dw, py + 48, dw, ph - 48 - 22, false);
    }

    private void drawPreview(GuiGraphics g, boolean none, boolean custom, String name, int x, int y, int w) {
        if (none) {
            rr(g, x + w / 2 - 16, y + 30, 32, 32, 16, 0xFF222B48);
            icon(g, ICON_CLOSE, x + w / 2 - 10, y + 36, 20);
            return;
        }
        if (custom) {
            Identifier id = CustomTextures.texture(customKind(), name);
            if (id == null) {
                Theme.text(g, "?", x + w / 2 - 3, y + 40, Theme.MUTED);
            } else if (sub == Sub.CAPES) {
                g.blit(RenderPipelines.GUI_TEXTURED, id, x + w / 2 - 20, y + 10, 16f, 16f, 40, 64, 160, 256,
                        CustomTextures.CANVAS_W, CustomTextures.CANVAS_H);
            } else {
                g.blit(RenderPipelines.GUI_TEXTURED, id, x + w / 2 - 20, y + 10, 384f, 32f, 40, 80, 160, 320,
                        CustomTextures.CANVAS_W, CustomTextures.CANVAS_H);
            }
            return;
        }
        switch (sub) {
            case CAPES -> {
                Identifier id = tex("textures/cape/" + Cosmetics.slug(name) + ".png");
                g.blit(RenderPipelines.GUI_TEXTURED, id, x + w / 2 - 20, y + 10, 4f, 4f, 40, 64, 40, 64, 256, 128);
            }
            case WINGS -> {
                Identifier id = tex("textures/gui/wing_" + Cosmetics.slug(name) + ".png");
                g.blit(RenderPipelines.GUI_TEXTURED, id, x + 8, y + 14, 0f, 0f, 80, 64, 80, 64, 80, 64);
            }
            case PETS, BIRDS -> {
                g.pose().pushMatrix();
                g.pose().translate((float) (x + w / 2 - 24), (float) (y + 22));
                g.pose().scale(3f, 3f);
                g.renderItem(new ItemStack(sub == Sub.BIRDS ? Items.PARROT_SPAWN_EGG : eggFor(name)), 0, 0);
                g.pose().popMatrix();
                if (sub == Sub.BIRDS) {
                    rr(g, x + w / 2 - 6, y + 76, 12, 6, 3, birdColor(name));
                }
            }
        }
    }

    // ================================================================== lists (configs, events, friends, markers)

    private void inputRow(GuiGraphics g, int cx, int cw, int y, String placeholder, String buttonLabel, Runnable submit) {
        int bw = Theme.width(Lang.t(buttonLabel)) + 22;
        int fw = cw - bw - 8;
        outline(g, cx, y, fw, 24, 6, inputFocused ? Theme.accent() : 0xFF222B48, 0xFF141B30);
        String shown = input.isEmpty() && !inputFocused ? Lang.t(placeholder)
                : input + (inputFocused && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
        Theme.text(g, ellipsize(shown, fw - 18), cx + 9, y + 8, input.isEmpty() && !inputFocused ? Theme.MUTED : Theme.TEXT);
        hit(cx, y, fw, 24, b -> inputFocused = true);
        button(g, cx + fw + 8, y, bw, 24, Lang.t(buttonLabel), submit);
    }

    private interface RowDrawer {
        void draw(int index, int y);
    }

    private void list(GuiGraphics g, int cx, int cw, int top, int bottom, int count, int rowH, RowDrawer drawer) {
        int content = count * rowH;
        scrollList = Math.max(0, Math.min(scrollList, Math.max(0, content - (bottom - top))));
        g.enableScissor(cx - 2, top, cx + cw + 2, bottom);
        for (int i = 0; i < count; i++) {
            int y = top + i * rowH - scrollList;
            if (y + rowH >= top && y <= bottom) {
                drawer.draw(i, y);
            }
        }
        g.disableScissor();
    }

    private void drawConfigs(GuiGraphics g, int cx, int cw) {
        header(g, cx, cw, "Configs", Lang.t("Save and load your settings."));
        inputRow(g, cx, cw, py + 52, "New config name", "Save", this::saveNew);
        List<String> names = ModuleManager.configNames();
        int top = py + 88, bottom = py + ph - 22;
        list(g, cx, cw, top, bottom, names.size(), 30, (i, y) -> {
            String name = names.get(i);
            boolean current = name.equals(ModuleManager.currentConfig);
            rr(g, cx, y, cw, 26, 7, current ? 0xFF1A2342 : 0xFF141B30);
            if (current) {
                rr(g, cx, y + 6, 3, 14, 1, Theme.accent());
            }
            Theme.text(g, name + (current ? "  " + Lang.t("(active)") : ""), cx + 12, y + 9, Theme.TEXT);
            int bx = cx + cw - 8;
            bx -= 58;
            smallButton(g, bx, y + 5, 54, 16, Lang.t("Delete"), top, bottom, () -> ModuleManager.delete(name));
            bx -= 58;
            smallButton(g, bx, y + 5, 54, 16, Lang.t("Save"), top, bottom, () -> {
                ModuleManager.save(name);
                ModuleManager.currentConfig = name;
                Events.info("Config", Lang.t("Saved") + ": " + name);
            });
            bx -= 58;
            smallButton(g, bx, y + 5, 54, 16, Lang.t("Load"), top, bottom, () -> {
                if (ModuleManager.load(name)) {
                    Events.info("Config", Lang.t("Loaded") + ": " + name);
                }
            });
        });
        if (names.isEmpty()) {
            Theme.text(g, Lang.t("No saved configs yet. Type a name and press Save."), cx, top + 6, Theme.MUTED);
        }
    }

    private void saveNew() {
        if (!input.isBlank()) {
            String name = ModuleManager.sanitize(input);
            ModuleManager.save(name);
            ModuleManager.currentConfig = name;
            Events.info("Config", Lang.t("Saved") + ": " + name);
            input = "";
        }
    }

    private void drawEvents(GuiGraphics g, int cx, int cw) {
        header(g, cx, cw, "Events", Lang.t("Toggles, alerts and pickups."));
        List<String> log = Events.LOG;
        int top = py + 56, bottom = py + ph - 22;
        if (log.isEmpty()) {
            Theme.text(g, Lang.t("No events yet. Toggles, alerts and pickups show up here."), cx, top + 6, Theme.MUTED);
            return;
        }
        list(g, cx, cw, top, bottom, log.size(), 16, (i, y) -> {
            String line = log.get(log.size() - 1 - i);
            if (i % 2 == 0) {
                rr(g, cx, y, cw, 15, 4, 0xFF121930);
            }
            Theme.text(g, ellipsize(line, cw - 16), cx + 8, y + 4, i == 0 ? Theme.TEXT : Theme.MUTED);
        });
    }

    private void drawFriends(GuiGraphics g, int cx, int cw) {
        header(g, cx, cw, "Friends", Lang.t("Friends are highlighted green by ArrowNametag."));
        inputRow(g, cx, cw, py + 52, "Player name", "Add", () -> {
            Friends.add(input);
            input = "";
        });
        button(g, cx, py + 84, 190, 20, Lang.t("Add player I'm looking at"), () -> {
            if (Util.target() instanceof Player p) {
                Friends.add(p.getName().getString());
                Events.info("Friends", Lang.t("Added") + ": " + p.getName().getString());
            }
        });
        List<String> names = new ArrayList<>(Friends.all());
        int top = py + 112, bottom = py + ph - 22;
        list(g, cx, cw, top, bottom, names.size(), 30, (i, y) -> {
            String name = names.get(i);
            rr(g, cx, y, cw, 26, 7, 0xFF141B30);
            rr(g, cx + 9, y + 8, 10, 10, 5, Theme.GOOD);
            Theme.text(g, name, cx + 26, y + 9, Theme.TEXT);
            smallButton(g, cx + cw - 78, y + 5, 70, 16, Lang.t("Remove"), top, bottom, () -> Friends.remove(name));
        });
    }

    private void drawMarkers(GuiGraphics g, int cx, int cw) {
        header(g, cx, cw, "Markers", Lang.t("Enable MarkerOverlay (HUD) to see markers in the world."));
        inputRow(g, cx, cw, py + 52, "Marker name (saved at your position)", "Add here", this::addMarker);
        List<Markers.Marker> list = new ArrayList<>(Markers.LIST);
        int top = py + 88, bottom = py + ph - 22;
        list(g, cx, cw, top, bottom, list.size(), 30, (i, y) -> {
            Markers.Marker m = list.get(i);
            rr(g, cx, y, cw, 26, 7, 0xFF141B30);
            Theme.text(g, m.name(), cx + 12, y + 9, Theme.TEXT);
            String pos = String.format(Locale.ROOT, "%.0f %.0f %.0f  %s", m.x(), m.y(), m.z(), Lang.t(m.dimension().replace("minecraft:", "")));
            Theme.text(g, ellipsize(pos, cw - 200), cx + 140, y + 9, Theme.MUTED);
            smallButton(g, cx + cw - 78, y + 5, 70, 16, Lang.t("Remove"), top, bottom, () -> Markers.remove(m));
        });
    }

    private void addMarker() {
        if (minecraft.player != null && !input.isBlank()) {
            Markers.add(input.trim(), minecraft.player.getX(), minecraft.player.getY(), minecraft.player.getZ(), Util.dimensionName());
            input = "";
        }
    }

    // ================================================================== input

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        inputFocused = false;
        searchFocused = false;
        double mx = event.x(), my = event.y() - animOffset();
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (h.contains(mx, my)) {
                mouseX = (int) mx;
                mouseY = (int) my;
                h.click().accept(event.button());
                if (h.drag() != null) {
                    dragging = h;
                }
                return true;
            }
        }
        listeningModule = null;
        listeningSetting = null;
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (dragging != null && dragging.drag() != null) {
            dragging.drag().accept(event.x());
            return true;
        }
        return super.mouseDragged(event, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        dragging = null;
        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseScrolled(double x, double y, double horizontal, double vertical) {
        int amount = (int) (-vertical * 24);
        if (tab == Tab.MODULES) {
            if (drawerModule != null && x >= px + pw - 14 - 250) {
                scrollDrawer = Math.max(0, scrollDrawer + amount);
            } else {
                scrollGrid = Math.max(0, scrollGrid + amount);
            }
        } else if (tab == Tab.COSMETICS) {
            if (x >= px + pw - 14 - 220) {
                scrollDrawer = Math.max(0, scrollDrawer + amount);
            } else {
                scrollCosmetics = Math.max(0, scrollCosmetics + amount);
            }
        } else {
            scrollList = Math.max(0, scrollList + amount);
        }
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (listeningModule != null || listeningSetting != null) {
            int value = key == GLFW.GLFW_KEY_ESCAPE ? -1 : key;
            if (listeningModule != null) {
                listeningModule.key = value;
            } else {
                listeningSetting.value = value;
            }
            listeningModule = null;
            listeningSetting = null;
            return true;
        }
        if (searchFocused) {
            if (key == GLFW.GLFW_KEY_BACKSPACE && !search.isEmpty()) {
                search = search.substring(0, search.length() - 1);
            } else if (key == GLFW.GLFW_KEY_ESCAPE || key == 257) {
                searchFocused = false;
            }
            return true;
        }
        if (inputFocused) {
            if (key == GLFW.GLFW_KEY_BACKSPACE && !input.isEmpty()) {
                input = input.substring(0, input.length() - 1);
            } else if (key == GLFW.GLFW_KEY_ESCAPE) {
                inputFocused = false;
            } else if (key == 257 || key == 335) {
                submitInput();
            }
            return true;
        }
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            onClose();
            return true;
        }
        return super.keyPressed(event);
    }

    private void submitInput() {
        switch (tab) {
            case CONFIGS -> saveNew();
            case FRIENDS -> {
                Friends.add(input);
                input = "";
            }
            case MARKERS -> addMarker();
            default -> {
            }
        }
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        if (event.codepoint() < 32 || event.codepoint() == 127) {
            return super.charTyped(event);
        }
        if (searchFocused && search.length() < 24) {
            search += event.codepointAsString();
            scrollGrid = 0;
            return true;
        }
        if (inputFocused && input.length() < 32) {
            input += event.codepointAsString();
            return true;
        }
        return super.charTyped(event);
    }
}
