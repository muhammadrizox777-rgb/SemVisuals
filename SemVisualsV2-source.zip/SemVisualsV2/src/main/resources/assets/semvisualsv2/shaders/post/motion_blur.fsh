#version 330

uniform sampler2D InSampler;
uniform sampler2D PrevSampler;

layout(std140) uniform MotionBlurConfig {
    float Strength;
};

in vec2 texCoord;

out vec4 fragColor;

void main() {
    vec4 current = texture(InSampler, texCoord);
    vec4 previous = texture(PrevSampler, texCoord);
    // An empty history has alpha 0, so the first frame (or a history that is not kept) passes through unchanged.
    float amount = previous.a > 0.5 ? Strength : 0.0;
    fragColor = vec4(mix(current.rgb, previous.rgb, amount), 1.0);
}
