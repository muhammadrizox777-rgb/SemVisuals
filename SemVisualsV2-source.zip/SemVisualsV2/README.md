# Sem Visuals V2 (Fabric, Minecraft 1.21.11)

Right Shift opens the menu: a floating island at the top, one draggable glass window per category, and modal views for
Cosmetics, Studio, Configs, Friends, Markers and Events.

Build: `./gradlew build` -> `build/libs/SemVisualsV2-1.0.0.jar` (use the one without `-sources`/`-dev`).

## Modules (87)
- Visuals (32), HUD (17), Utilities (23): everything from Sem Visuals 1.
- New (10): OptimalAim, HitMarker, DamageNumbers, CpsCounter, KeyStrokes, Speedometer, ComboCounter, ReachDisplay, Compass, FpsGraph.
- Cosmetics (5): Cape (20 + yours), Wings (20 + yours), Pet (20 animals), ShoulderBird (5 parrots), Skin (yours).

## Studio (pixel editor)
Draw your own cape, wings, skin or animal texture pixel by pixel, with a live preview on your model:
pencil, eraser, fill, color picker, mirror, grid, UV guides, brush size, undo/redo, 36-color palette + HSB/alpha sliders,
templates (every built-in cape/wing, Steve/Alex, the vanilla texture of the animal), save as PNG and Apply.
Files live in `config/semvisualsv2/{capes,wings,skins,pets}`. You can also drop your own PNG/JPG there.

Cosmetics are drawn only on your own screen: nothing is sent to the server, other players do not see them.

Mixins: `src/client/java/uz/semvisualsv2/mixin/client`, config `semvisualsv2.client.mixins.json` (`required: false`).
Fonts: 39 OFL fonts incl. Japanese, Korean, Arabic, Thai, Devanagari and Hebrew (`LICENSES-FONTS/`). UI text is Uzbek.
All artwork was created for this mod.
