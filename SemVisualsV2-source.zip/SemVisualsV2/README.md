# Sem Visuals V2 (Fabric, Minecraft 1.21.11)

Right Shift opens the V2 menu: icon rail, module cards, a settings drawer and a Cosmetics tab.

Build: `./gradlew build` -> `build/libs/SemVisualsV2-1.0.0.jar` (use the one without `-sources`/`-dev`).

## Modules (86)
- Visuals (32), HUD (17), Utilities (23): everything from Sem Visuals 1.
- New (10): OptimalAim, HitMarker, DamageNumbers, CpsCounter, KeyStrokes, Speedometer, ComboCounter, ReachDisplay, Compass, FpsGraph.
- Cosmetics (4): Cape (20 + your own images), Wings (20 + your own images), Pet (20 animals), ShoulderBird (5 parrots).

Cosmetics are drawn only on your own screen: nothing is sent to the server, other players do not see them.
Your own images: Cosmetics tab > Capes or Wings > Open folder, drop a PNG/JPG in, press Refresh.
A normal 2:1 cape/elytra texture is used as it is; any other picture is fitted onto the cape or wing.

Mixins: `src/client/java/uz/semvisualsv2/mixin/client`, config `semvisualsv2.client.mixins.json` (`required: false`).
Fonts: 33 OFL fonts, licenses in `LICENSES-FONTS/`. UI text is Uzbek (`assets/semvisualsv2/lang/en_us.json`).
All artwork was created for this mod.
