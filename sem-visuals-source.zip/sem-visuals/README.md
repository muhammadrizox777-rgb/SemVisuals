# Sem Visuals (Fabric, Minecraft 1.21.11)

Client-side Fabric mod: Click GUI (Right Shift), HUD editor, configs, friends, markers, event log.

Build: `./gradlew build` -> `build/libs/`.

## Modules (59)
- Visuals (22): FullBright, Zoom, Crosshair, TargetEsp, ArrowNametag, SelfNametag, Trails, JumpCircles, KillEffect, Halo, ChinaHat, Nimb, BodyGlow, HitBubble, HitSounds, HitRange, Particles, WorldParticles, WorldCustomizer, BlockOverlay, HitboxCustomizer, Atmosphere
- HUD (17): ClientColor, Watermark, Notifications, ArmorHud, PotionsHud, SaturationHud, TotemsHud, CooldownsHud, InventoryHud, HotkeysHud, TargetHud, Coordinates, TntTimer, MarkerOverlay, EffectNotify, ScoreboardHud, BossbarHud
- Utilities (20): Sprint, AutoRespawn, AutoReconnect, ArmorNotifier, DeathMarker, ChatHelper, CommandSafe, ItemPickupLogger, AutoEat, StreamerMode, MaceHelper, Optimization, SoundController, GpsCommand, PvpSafe, Predictions, ItemHighlighter, HealingHelper, ElytraSwap (bind a key), ChestSorter (R in an open chest)

Not included: modules that need mixins (Animations, AspectRatio, CustomHand, HitColor, ItemPhysics, MotionBlur, NoFluid, RenderTweaks, TabCustomizer, ShulkerPreview, FreeLook, ItemScroller, LockSlot), combat/server automation (AutoPotion, AutoDuel, ShiftTab, TapeMouse, FastEXP, ItemSwap, FastSwap, AutoLeave) and server-specific helpers (AucHelper, AutoInvest, AutoReissue, FcHelper, FtHelper, HwHelper, RwHelper, RwJoiner).

Written independently. All artwork (icon, logo, category icons) was created for Sem Visuals.

## Fonts
33 bundled OFL fonts (see `LICENSES-FONTS/`). Pick one in ClientColor > "Interface font"; it is applied to the menu and HUD.

## Til / Language
Interfeys matnlari o'zbekcha (lotin yozuvida). Tarjimalar `src/main/resources/assets/semvisuals/lang/en_us.json` (va bir xil `uz_uz.json`) ichida turadi.
Inglizchaga o'tish: ClientColor > Til > English. Modul nomlari (FullBright, Zoom va h.k.) inglizcha qoladi.
