package uz.semvisuals.core;

import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public final class Util {
    private static LivingEntity lastTarget;
    private static long lastTargetTime;

    private Util() {
    }

    public static void onAttack(LivingEntity target) {
        lastTarget = target;
        lastTargetTime = System.currentTimeMillis();
    }

    /** The entity under the crosshair, or the last one attacked in the past few seconds. */
    public static LivingEntity target() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.hitResult instanceof EntityHitResult hit && hit.getType() == HitResult.Type.ENTITY
                && hit.getEntity() instanceof LivingEntity living && living.isAlive()) {
            return living;
        }
        if (lastTarget != null && lastTarget.isAlive() && System.currentTimeMillis() - lastTargetTime < 4000) {
            return lastTarget;
        }
        return null;
    }

    public static LivingEntity lastAttacked() {
        return lastTarget;
    }

    /**
     * Projects a world position to GUI-scaled screen coordinates.
     * Returns {x, y, depth, camRight, camUp}; depth <= 0 means behind the camera.
     * Uses the player's FOV option, so it ignores temporary FOV effects.
     */
    public static double[] project(Vec3 world) {
        Minecraft mc = Minecraft.getInstance();
        Camera cam = mc.gameRenderer.getMainCamera();
        Vec3 rel = world.subtract(cam.position());
        double yaw = Math.toRadians(cam.yRot());
        double pitch = Math.toRadians(cam.xRot());
        double fx = -Math.sin(yaw) * Math.cos(pitch), fy = -Math.sin(pitch), fz = Math.cos(yaw) * Math.cos(pitch);
        double rx = -Math.cos(yaw), ry = 0, rz = -Math.sin(yaw);
        double ux = ry * fz - rz * fy, uy = rz * fx - rx * fz, uz = rx * fy - ry * fx;

        double depth = rel.x * fx + rel.y * fy + rel.z * fz;
        double right = rel.x * rx + rel.y * ry + rel.z * rz;
        double up = rel.x * ux + rel.y * uy + rel.z * uz;

        int w = mc.getWindow().getGuiScaledWidth();
        int h = mc.getWindow().getGuiScaledHeight();
        double tan = Math.tan(Math.toRadians(mc.options.fov().get()) / 2.0);
        double aspect = (double) w / h;
        double d = Math.max(depth, 0.001);
        double sx = w / 2.0 + (right / d) / (tan * aspect) * (w / 2.0);
        double sy = h / 2.0 - (up / d) / tan * (h / 2.0);
        return new double[]{sx, sy, depth, right, up};
    }

    public static String dimensionName() {
        Minecraft mc = Minecraft.getInstance();
        return mc.level == null ? "" : mc.level.dimension().identifier().toString();
    }

    public static String formatTicks(int ticks) {
        int seconds = ticks / 20;
        return String.format("%d:%02d", seconds / 60, seconds % 60);
    }

    public static String keyName(int key) {
        if (key < 0) {
            return "None";
        }
        String name = com.mojang.blaze3d.platform.InputConstants.Type.KEYSYM.getOrCreate(key).getDisplayName().getString();
        return name.length() > 9 ? name.substring(0, 9) : name;
    }

    /** Draws the 12 edges of a box as dotted lines using screen projection. */
    public static void drawBox(net.minecraft.client.gui.GuiGraphics g, net.minecraft.world.phys.AABB b, int color) {
        double[][] c = {
                {b.minX, b.minY, b.minZ}, {b.maxX, b.minY, b.minZ}, {b.maxX, b.minY, b.maxZ}, {b.minX, b.minY, b.maxZ},
                {b.minX, b.maxY, b.minZ}, {b.maxX, b.maxY, b.minZ}, {b.maxX, b.maxY, b.maxZ}, {b.minX, b.maxY, b.maxZ}};
        int[][] edges = {{0, 1}, {1, 2}, {2, 3}, {3, 0}, {4, 5}, {5, 6}, {6, 7}, {7, 4}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
        for (int[] e : edges) {
            for (int i = 0; i <= 14; i++) {
                double t = i / 14.0;
                Vec3 p = new Vec3(c[e[0]][0] + (c[e[1]][0] - c[e[0]][0]) * t,
                        c[e[0]][1] + (c[e[1]][1] - c[e[0]][1]) * t,
                        c[e[0]][2] + (c[e[1]][2] - c[e[0]][2]) * t);
                double[] s = project(p);
                if (s[2] > 0.05) {
                    g.fill((int) s[0], (int) s[1], (int) s[0] + 2, (int) s[1] + 2, color | 0xFF000000);
                }
            }
        }
    }
}
