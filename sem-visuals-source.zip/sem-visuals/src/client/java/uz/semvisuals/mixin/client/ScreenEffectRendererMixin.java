package uz.semvisuals.mixin.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.ScreenEffectRenderer;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import uz.semvisuals.module.Mixed;

@Mixin(ScreenEffectRenderer.class)
public abstract class ScreenEffectRendererMixin {
    @Inject(method = "renderFire", at = @At("HEAD"), cancellable = true)
    private static void sem$noFire(PoseStack poseStack, MultiBufferSource buffer, TextureAtlasSprite sprite, CallbackInfo ci) {
        if (Mixed.RenderTweaks.noFireOverlay()) {
            ci.cancel();
        }
    }

    @Inject(method = "renderWater", at = @At("HEAD"), cancellable = true)
    private static void sem$noWater(Minecraft minecraft, PoseStack poseStack, MultiBufferSource buffer, CallbackInfo ci) {
        if (Mixed.NoFluid.active()) {
            ci.cancel();
        }
    }
}
