package uz.semvisuals.mixin.client;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import uz.semvisuals.module.Mixed;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    @Inject(method = "getCurrentSwingDuration", at = @At("RETURN"), cancellable = true)
    private void sem$swingDuration(CallbackInfoReturnable<Integer> cir) {
        if ((Object) this == Minecraft.getInstance().player) {
            cir.setReturnValue(Mixed.Animations.scale(cir.getReturnValue()));
        }
    }
}
