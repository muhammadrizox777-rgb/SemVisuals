package uz.semvisuals.mixin.client;

import net.minecraft.client.player.LocalPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import uz.semvisuals.module.Mixed;

@Mixin(LocalPlayer.class)
public abstract class LocalPlayerMixin {
    @Inject(method = "drop", at = @At("HEAD"), cancellable = true)
    private void sem$lockedDrop(boolean all, CallbackInfoReturnable<Boolean> cir) {
        if (Mixed.LockSlot.blocksDrop()) {
            cir.setReturnValue(false);
        }
    }
}
