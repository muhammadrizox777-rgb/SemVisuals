package uz.semvisuals.mixin.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.GameRenderer;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import uz.semvisuals.module.Mixed;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "bobHurt", at = @At("HEAD"), cancellable = true)
    private void sem$noHurtCam(PoseStack poseStack, float partialTick, CallbackInfo ci) {
        if (Mixed.RenderTweaks.noHurtCam()) {
            ci.cancel();
        }
    }

    @Inject(method = "bobView", at = @At("HEAD"), cancellable = true)
    private void sem$noViewBob(PoseStack poseStack, float partialTick, CallbackInfo ci) {
        if (Mixed.RenderTweaks.noViewBob()) {
            ci.cancel();
        }
    }

    @Inject(method = "getProjectionMatrix", at = @At("RETURN"), cancellable = true)
    private void sem$aspect(float fov, CallbackInfoReturnable<Matrix4f> cir) {
        cir.setReturnValue(Mixed.AspectRatio.scaled(cir.getReturnValue()));
    }

    @Inject(method = "getProjectionMatrixForCulling", at = @At("RETURN"), cancellable = true)
    private void sem$aspectCulling(float fov, CallbackInfoReturnable<Matrix4f> cir) {
        cir.setReturnValue(Mixed.AspectRatio.scaled(cir.getReturnValue()));
    }
}
