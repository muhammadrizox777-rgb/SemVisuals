package uz.semvisuals.module;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.CameraType;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.renderer.entity.state.ItemEntityRenderState;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.core.NonNullList;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemContainerContents;
import org.joml.Matrix4f;
import uz.semvisuals.core.Category;
import uz.semvisuals.core.Events;
import uz.semvisuals.core.Friends;
import uz.semvisuals.core.Module;
import uz.semvisuals.core.ModuleManager;
import uz.semvisuals.core.Setting;
import uz.semvisuals.core.Theme;
import uz.semvisuals.mixin.client.AbstractContainerScreenAccessor;
import uz.semvisuals.mixin.client.GameRendererInvoker;
import uz.semvisuals.mixin.client.OverlayTextureAccessor;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

/**
 * Modules that need game-code hooks (mixins). The hooks live in uz.semvisuals.mixin.client and only call the
 * static helpers below; each helper does nothing unless its module is enabled.
 */
public final class Mixed {
    private Mixed() {
    }

    public static void registerAll() {
        ModuleManager.register(new Animations());
        ModuleManager.register(new AspectRatio());
        ModuleManager.register(new CustomHand());
        ModuleManager.register(new HitColor());
        ModuleManager.register(new ItemPhysics());
        ModuleManager.register(new MotionBlur());
        ModuleManager.register(new NoFluid());
        ModuleManager.register(new RenderTweaks());
        ModuleManager.register(new ShulkerPreview());
        ModuleManager.register(new TabCustomizer());
        ModuleManager.register(new FreeLook());
        ModuleManager.register(new ItemScroller());
        ModuleManager.register(new LockSlot());
    }

    private static boolean isOn(Class<? extends Module> type) {
        return ModuleManager.on(type);
    }

    // ------------------------------------------------------------------ Animations

    public static final class Animations extends Module {
        private final Setting.Num speed = add(new Setting.Num("Swing speed %", 100, 30, 300, 5));

        public Animations() {
            super("Animations", "Changes how fast your hand swings", Category.VISUALS);
        }

        public static int scale(int duration) {
            Animations m = ModuleManager.get(Animations.class);
            if (m == null || !m.isEnabled()) {
                return duration;
            }
            return Math.max(1, Math.round(duration * 100f / m.speed.asFloat()));
        }
    }

    // ------------------------------------------------------------------ AspectRatio

    public static final class AspectRatio extends Module {
        private final Setting.Mode preset = add(new Setting.Mode("Preset", "16:9", "Custom", "4:3", "5:4", "16:9", "21:9", "32:9", "1:1"));
        private final Setting.Num ratio = add(new Setting.Num("Ratio", 1.33, 0.5, 3.5, 0.01).showIf(() -> preset.is("Custom")));

        public AspectRatio() {
            super("AspectRatio", "Changes the aspect ratio of the 3D view", Category.VISUALS);
        }

        private float target() {
            return switch (preset.get()) {
                case "4:3" -> 4f / 3f;
                case "5:4" -> 5f / 4f;
                case "16:9" -> 16f / 9f;
                case "21:9" -> 21f / 9f;
                case "32:9" -> 32f / 9f;
                case "1:1" -> 1f;
                default -> ratio.asFloat();
            };
        }

        /** Returns a copy of the projection matrix stretched to the chosen ratio. */
        public static Matrix4f scaled(Matrix4f original) {
            AspectRatio m = ModuleManager.get(AspectRatio.class);
            if (m == null || !m.isEnabled() || mc.getWindow().getHeight() == 0) {
                return original;
            }
            float window = (float) mc.getWindow().getWidth() / (float) mc.getWindow().getHeight();
            Matrix4f copy = new Matrix4f(original);
            copy.m00(copy.m00() * window / m.target());
            return copy;
        }
    }

    // ------------------------------------------------------------------ CustomHand

    public static final class CustomHand extends Module {
        private static boolean pushed;
        private final Setting.Num x = add(new Setting.Num("Offset X", 0, -0.6, 0.6, 0.01));
        private final Setting.Num y = add(new Setting.Num("Offset Y", 0, -0.6, 0.6, 0.01));
        private final Setting.Num z = add(new Setting.Num("Offset Z", 0, -0.6, 0.6, 0.01));
        private final Setting.Num scale = add(new Setting.Num("Scale %", 100, 50, 150, 1));
        private final Setting.Bool mainHand = add(new Setting.Bool("Main hand", true));
        private final Setting.Bool offHand = add(new Setting.Bool("Off hand", true));

        public CustomHand() {
            super("CustomHand", "Moves and scales your hands and held items", Category.VISUALS);
        }

        public static void pre(PoseStack poseStack, InteractionHand hand) {
            CustomHand m = ModuleManager.get(CustomHand.class);
            if (m == null || !m.isEnabled() || !(hand == InteractionHand.MAIN_HAND ? m.mainHand.get() : m.offHand.get())) {
                return;
            }
            poseStack.pushPose();
            pushed = true;
            poseStack.translate(m.x.asFloat(), m.y.asFloat(), m.z.asFloat());
            float s = m.scale.asFloat() / 100f;
            poseStack.scale(s, s, s);
        }

        public static void post(PoseStack poseStack) {
            if (pushed) {
                pushed = false;
                poseStack.popPose();
            }
        }
    }

    // ------------------------------------------------------------------ HitColor

    public static final class HitColor extends Module {
        private static final int VANILLA = 0xB2FF0000;
        private final Setting.Color color = add(new Setting.Color("Color", 0xFFFF3050));
        private final Setting.Num opacity = add(new Setting.Num("Opacity %", 70, 10, 100, 5));
        private int applied;

        public HitColor() {
            super("HitColor", "Changes the color of the red hurt flash on entities", Category.VISUALS);
        }

        private void fill(int argb) {
            DynamicTexture texture = ((OverlayTextureAccessor) mc.gameRenderer.overlayTexture()).sem$texture();
            NativeImage pixels = texture == null ? null : texture.getPixels();
            if (pixels == null) {
                return;
            }
            for (int yy = 0; yy < 8; yy++) {
                for (int xx = 0; xx < 16; xx++) {
                    pixels.setPixel(xx, yy, argb);
                }
            }
            texture.upload();
            applied = argb;
        }

        @Override
        public void onEnable() {
            applied = 0;
        }

        @Override
        public void onTick() {
            int argb = ((int) (opacity.get() * 2.55) << 24) | (color.get() & 0xFFFFFF);
            if (argb != applied) {
                fill(argb);
            }
        }

        @Override
        public void onDisable() {
            if (mc.gameRenderer != null) {
                fill(VANILLA);
            }
        }
    }

    // ------------------------------------------------------------------ ItemPhysics

    public static final class ItemPhysics extends Module {
        private static boolean pushed;
        private final Setting.Bool layFlat = add(new Setting.Bool("Lay flat", true));
        private final Setting.Bool freeze = add(new Setting.Bool("Freeze bobbing", true));

        public ItemPhysics() {
            super("ItemPhysics", "Dropped items lie flat and stay still", Category.VISUALS);
        }

        public static void pre(PoseStack poseStack) {
            ItemPhysics m = ModuleManager.get(ItemPhysics.class);
            if (m != null && m.isEnabled() && m.layFlat.get()) {
                poseStack.pushPose();
                pushed = true;
                poseStack.mulPose(Axis.XP.rotationDegrees(-90f));
            }
        }

        public static void post(PoseStack poseStack) {
            if (pushed) {
                pushed = false;
                poseStack.popPose();
            }
        }

        public static void freeze(ItemEntityRenderState state) {
            ItemPhysics m = ModuleManager.get(ItemPhysics.class);
            if (m != null && m.isEnabled() && m.freeze.get()) {
                state.ageInTicks = 0f;
            }
        }
    }

    // ------------------------------------------------------------------ MotionBlur

    public static final class MotionBlur extends Module {
        private final Setting.Mode strength = add(new Setting.Mode("Blur strength", "Medium", "Low", "Medium", "High"));

        public MotionBlur() {
            super("MotionBlur", "Blends the previous frame into the current one", Category.VISUALS);
        }

        private Identifier id() {
            return Identifier.fromNamespaceAndPath("semvisuals", "motion_blur_" + strength.get().toLowerCase());
        }

        @Override
        public void onTick() {
            Identifier wanted = id();
            if (!wanted.equals(mc.gameRenderer.currentPostEffect())) {
                ((GameRendererInvoker) mc.gameRenderer).sem$setPostEffect(wanted);
            }
        }

        @Override
        public void onDisable() {
            Identifier current = mc.gameRenderer == null ? null : mc.gameRenderer.currentPostEffect();
            if (current != null && "semvisuals".equals(current.getNamespace())) {
                mc.gameRenderer.clearPostEffect();
            }
        }
    }

    // ------------------------------------------------------------------ NoFluid

    public static final class NoFluid extends Module {
        public NoFluid() {
            super("NoFluid", "Removes the underwater screen overlay", Category.VISUALS);
        }

        public static boolean active() {
            return isOn(NoFluid.class);
        }
    }

    // ------------------------------------------------------------------ RenderTweaks

    public static final class RenderTweaks extends Module {
        private final Setting.Bool hurt = add(new Setting.Bool("No hurt camera", true));
        private final Setting.Bool bob = add(new Setting.Bool("No view bobbing", false));
        private final Setting.Bool fire = add(new Setting.Bool("No fire overlay", true));

        public RenderTweaks() {
            super("RenderTweaks", "Turns off hurt shake, view bobbing and the fire overlay", Category.VISUALS);
        }

        public static boolean noHurtCam() {
            RenderTweaks m = ModuleManager.get(RenderTweaks.class);
            return m != null && m.isEnabled() && m.hurt.get();
        }

        public static boolean noViewBob() {
            RenderTweaks m = ModuleManager.get(RenderTweaks.class);
            return m != null && m.isEnabled() && m.bob.get();
        }

        public static boolean noFireOverlay() {
            RenderTweaks m = ModuleManager.get(RenderTweaks.class);
            return m != null && m.isEnabled() && m.fire.get();
        }
    }

    // ------------------------------------------------------------------ ShulkerPreview

    public static final class ShulkerPreview extends Module {
        private final Setting.Bool empty = add(new Setting.Bool("Show empty slots", true));

        public ShulkerPreview() {
            super("ShulkerPreview", "Shows what is inside a shulker box you hover over", Category.VISUALS);
        }

        /** Called after a container screen has rendered. */
        public static void draw(AbstractContainerScreen<?> screen, GuiGraphics g, int mouseX, int mouseY) {
            ShulkerPreview m = ModuleManager.get(ShulkerPreview.class);
            if (m == null || !m.isEnabled()) {
                return;
            }
            Slot slot = ((AbstractContainerScreenAccessor) screen).sem$hoveredSlot();
            if (slot == null || !slot.hasItem()) {
                return;
            }
            ItemStack stack = slot.getItem();
            if (!stack.is(ItemTags.SHULKER_BOXES)) {
                return;
            }
            ItemContainerContents contents = stack.get(DataComponents.CONTAINER);
            if (contents == null) {
                return;
            }
            NonNullList<ItemStack> items = NonNullList.withSize(27, ItemStack.EMPTY);
            contents.copyInto(items);

            int w = 9 * 18 + 8, h = 3 * 18 + 8;
            int x = mouseX - w - 8;
            if (x < 2) {
                x = mouseX + 14;
            }
            int y = Math.max(2, Math.min(mc.getWindow().getGuiScaledHeight() - h - 2, mouseY - h / 2));
            g.fill(x, y, x + w, y + h, 0xE60D1220);
            g.fill(x, y, x + w, y + 2, Theme.accent());
            for (int i = 0; i < 27; i++) {
                int sx = x + 4 + (i % 9) * 18, sy = y + 5 + (i / 9) * 18;
                ItemStack item = items.get(i);
                if (item.isEmpty() && !m.empty.get()) {
                    continue;
                }
                g.fill(sx, sy, sx + 17, sy + 17, 0x55000000);
                if (!item.isEmpty()) {
                    g.renderItem(item, sx + 1, sy + 1);
                    g.renderItemDecorations(mc.font, item, sx + 1, sy + 1);
                }
            }
        }
    }

    // ------------------------------------------------------------------ TabCustomizer

    public static final class TabCustomizer extends Module {
        private final Setting.Bool friends = add(new Setting.Bool("Highlight friends", true));
        private final Setting.Color friendColor = add(new Setting.Color("Friend color", 0xFF6FD98A));
        private final Setting.Bool ping = add(new Setting.Bool("Show ping", true));

        public TabCustomizer() {
            super("TabCustomizer", "Highlights friends and shows ping in the tab list", Category.VISUALS);
        }

        public static Component modify(PlayerInfo info, Component name) {
            TabCustomizer m = ModuleManager.get(TabCustomizer.class);
            if (m == null || !m.isEnabled() || name == null) {
                return name;
            }
            Component result = name;
            if (m.friends.get()) {
                String plain = name.getString().toLowerCase();
                for (String friend : Friends.all()) {
                    if (plain.contains(friend)) {
                        int rgb = m.friendColor.get() & 0xFFFFFF;
                        result = result.copy().withStyle(style -> style.withColor(rgb));
                        break;
                    }
                }
            }
            if (m.ping.get() && info != null) {
                result = Component.empty().append(result)
                        .append(Component.literal(" " + info.getLatency() + "ms").withStyle(net.minecraft.ChatFormatting.GRAY));
            }
            return result;
        }
    }

    // ------------------------------------------------------------------ FreeLook

    public static final class FreeLook extends Module {
        private static boolean active;
        private static float yaw, pitch;
        private static float savedYaw, savedPitch, savedYawO, savedPitchO;
        private static CameraType previousCamera;
        private final Setting.Key hold = add(new Setting.Key("Hold key", 342));
        private final Setting.Bool thirdPerson = add(new Setting.Bool("Third person while active", true));

        public FreeLook() {
            super("FreeLook", "Hold a key to look around without turning", Category.UTILITIES);
        }

        @Override
        public void onTick() {
            if (mc.player == null) {
                return;
            }
            boolean down = mc.screen == null && hold.get() > 0 && InputConstants.isKeyDown(mc.getWindow(), hold.get());
            if (down && !active) {
                active = true;
                yaw = mc.player.getYRot();
                pitch = mc.player.getXRot();
                previousCamera = mc.options.getCameraType();
                if (thirdPerson.get()) {
                    mc.options.setCameraType(CameraType.THIRD_PERSON_BACK);
                }
            } else if (!down && active) {
                stop();
            }
        }

        private static void stop() {
            active = false;
            if (previousCamera != null) {
                mc.options.setCameraType(previousCamera);
                previousCamera = null;
            }
        }

        @Override
        public void onDisable() {
            if (active) {
                stop();
            }
        }

        /** Returns true when the mouse movement was used for the free camera instead of the player. */
        public static boolean turn(double yRot, double xRot) {
            if (!active || !isOn(FreeLook.class)) {
                return false;
            }
            yaw += (float) yRot * 0.15f;
            pitch = Math.max(-90f, Math.min(90f, pitch + (float) xRot * 0.15f));
            return true;
        }

        public static void cameraPre(Entity entity) {
            if (active && entity == mc.player && isOn(FreeLook.class)) {
                savedYaw = entity.getYRot();
                savedPitch = entity.getXRot();
                savedYawO = entity.yRotO;
                savedPitchO = entity.xRotO;
                entity.setYRot(yaw);
                entity.setXRot(pitch);
                entity.yRotO = yaw;
                entity.xRotO = pitch;
                swapped = true;
            }
        }

        private static boolean swapped;

        public static void cameraPost(Entity entity) {
            if (swapped && entity != null) {
                swapped = false;
                entity.setYRot(savedYaw);
                entity.setXRot(savedPitch);
                entity.yRotO = savedYawO;
                entity.xRotO = savedPitchO;
            }
        }
    }

    // ------------------------------------------------------------------ ItemScroller

    public static final class ItemScroller extends Module {
        private final Setting.Bool needShift = add(new Setting.Bool("Hold Shift", false));

        public ItemScroller() {
            super("ItemScroller", "Scroll over a slot to move one item to the other inventory", Category.UTILITIES);
        }

        /** Returns true if the scroll was used (so the vanilla scroll should be skipped). */
        public static boolean onScroll(AbstractContainerScreen<?> screen) {
            ItemScroller m = ModuleManager.get(ItemScroller.class);
            if (m == null || !m.isEnabled() || mc.player == null || mc.gameMode == null) {
                return false;
            }
            if (m.needShift.get() && !InputConstants.isKeyDown(mc.getWindow(), 340)) {
                return false;
            }
            Slot from = ((AbstractContainerScreenAccessor) screen).sem$hoveredSlot();
            if (from == null || !from.hasItem() || !mc.player.containerMenu.getCarried().isEmpty()) {
                return false;
            }
            ItemStack stack = from.getItem();
            AbstractContainerMenu menu = screen.getMenu();
            Slot target = null;
            for (Slot s : menu.slots) {
                if (s.container == from.container || !s.mayPlace(stack)) {
                    continue;
                }
                ItemStack there = s.getItem();
                if (there.isEmpty() || (ItemStack.isSameItemSameComponents(there, stack) && there.getCount() < s.getMaxStackSize(stack))) {
                    target = s;
                    break;
                }
            }
            if (target == null) {
                return false;
            }
            mc.gameMode.handleInventoryMouseClick(menu.containerId, from.index, 0, ClickType.PICKUP, mc.player);
            mc.gameMode.handleInventoryMouseClick(menu.containerId, target.index, 1, ClickType.PICKUP, mc.player);
            mc.gameMode.handleInventoryMouseClick(menu.containerId, from.index, 0, ClickType.PICKUP, mc.player);
            return true;
        }
    }

    // ------------------------------------------------------------------ LockSlot

    public static final class LockSlot extends Module {
        private static final TreeSet<Integer> LOCKED = new TreeSet<>();
        private final Setting.Key lockKey = add(new Setting.Key("Lock key", 76));
        private boolean wasDown;
        private boolean loaded;

        public LockSlot() {
            super("LockSlot", "Protect slots from being moved or dropped (press the key over a slot)", Category.UTILITIES);
        }

        private static Path file() {
            return ModuleManager.dir().resolve("lockedslots.txt");
        }

        private static void load() {
            LOCKED.clear();
            try {
                if (Files.exists(file())) {
                    for (String line : Files.readAllLines(file())) {
                        if (!line.isBlank()) {
                            LOCKED.add(Integer.parseInt(line.trim()));
                        }
                    }
                }
            } catch (IOException | NumberFormatException ignored) {
            }
        }

        private static void save() {
            List<String> lines = new ArrayList<>();
            for (int i : LOCKED) {
                lines.add(Integer.toString(i));
            }
            try {
                Files.createDirectories(file().getParent());
                Files.write(file(), lines);
            } catch (IOException ignored) {
            }
        }

        @Override
        public void onTick() {
            if (!loaded) {
                loaded = true;
                load();
            }
            boolean inContainer = mc.screen instanceof AbstractContainerScreen<?>;
            boolean down = inContainer && lockKey.get() > 0 && InputConstants.isKeyDown(mc.getWindow(), lockKey.get());
            if (down && !wasDown) {
                Slot hovered = ((AbstractContainerScreenAccessor) mc.screen).sem$hoveredSlot();
                if (hovered != null && hovered.container instanceof Inventory) {
                    int index = hovered.getContainerSlot();
                    if (!LOCKED.remove(index)) {
                        LOCKED.add(index);
                        Events.toast("LockSlot", "Slot locked", true);
                    } else {
                        Events.toast("LockSlot", "Slot unlocked", false);
                    }
                    save();
                }
            }
            wasDown = down;
        }

        private static boolean enabled() {
            return isOn(LockSlot.class);
        }

        public static boolean blocks(Slot slot, int button, ClickType type) {
            if (!enabled() || LOCKED.isEmpty()) {
                return false;
            }
            if (type == ClickType.SWAP && LOCKED.contains(button == 40 ? 40 : button)) {
                return true;
            }
            return slot != null && slot.container instanceof Inventory && LOCKED.contains(slot.getContainerSlot());
        }

        public static boolean blocksDrop() {
            return enabled() && mc.player != null && mc.screen == null
                    && LOCKED.contains(mc.player.getInventory().getSelectedSlot());
        }

        /** Red marks over locked slots. Called after a container screen has rendered. */
        public static void drawLocks(AbstractContainerScreen<?> screen, GuiGraphics g) {
            if (!enabled() || LOCKED.isEmpty()) {
                return;
            }
            AbstractContainerScreenAccessor acc = (AbstractContainerScreenAccessor) screen;
            for (Slot s : screen.getMenu().slots) {
                if (s.container instanceof Inventory && LOCKED.contains(s.getContainerSlot())) {
                    int x = acc.sem$leftPos() + s.x, y = acc.sem$topPos() + s.y;
                    g.fill(x, y, x + 16, y + 16, 0x66E86A6A);
                    g.fill(x, y, x + 16, y + 1, 0xFFE86A6A);
                    g.fill(x, y + 15, x + 16, y + 16, 0xFFE86A6A);
                }
            }
        }
    }
}
